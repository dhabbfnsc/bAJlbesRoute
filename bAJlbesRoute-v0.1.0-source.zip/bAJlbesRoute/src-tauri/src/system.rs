//! Системные команды: окружение, настройки, вложения, уведомления, модели.
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use tauri::{AppHandle, Manager, WebviewWindow};

use crate::imagine;
use crate::tools;
use crate::util;

pub struct Prefs {
    pub close_to_tray: AtomicBool,
}

impl Default for Prefs {
    fn default() -> Self {
        Self {
            close_to_tray: AtomicBool::new(cfg!(not(any(target_os = "android", target_os = "ios")))),
        }
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BootInfo {
    pub platform: String,
    pub platform_label: String,
    pub arch: String,
    pub os_version: String,
    pub app_version: String,
    pub data_dir: String,
    pub media_dir: String,
    pub is_mobile: bool,
    pub device_name: String,
    pub webview: String,
    pub locale: String,
}

fn platform_id() -> String {
    if cfg!(target_os = "windows") {
        "windows".into()
    } else if cfg!(target_os = "macos") {
        "macos".into()
    } else if cfg!(target_os = "ios") {
        "ios".into()
    } else if cfg!(target_os = "android") {
        "android".into()
    } else if cfg!(target_os = "linux") {
        "linux".into()
    } else {
        std::env::consts::OS.to_string()
    }
}

fn platform_label() -> String {
    if cfg!(target_os = "windows") {
        "Windows".into()
    } else if cfg!(target_os = "macos") {
        "macOS".into()
    } else if cfg!(target_os = "ios") {
        "iOS".into()
    } else if cfg!(target_os = "android") {
        "Android".into()
    } else if cfg!(target_os = "linux") {
        "Linux".into()
    } else {
        std::env::consts::OS.to_string()
    }
}

fn os_version() -> String {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        if let Ok(out) = std::process::Command::new("cmd")
            .args(["/C", "ver"])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout).trim().to_string();
            if !text.is_empty() {
                return text;
            }
        }
        String::new()
    }
    #[cfg(target_os = "macos")]
    {
        if let Ok(out) = std::process::Command::new("sw_vers")
            .arg("-productVersion")
            .output()
        {
            return String::from_utf8_lossy(&out.stdout).trim().to_string();
        }
        String::new()
    }
    #[cfg(target_os = "linux")]
    {
        if let Ok(text) = std::fs::read_to_string("/etc/os-release") {
            for line in text.lines() {
                if let Some(rest) = line.strip_prefix("PRETTY_NAME=") {
                    return rest.trim_matches('"').to_string();
                }
            }
        }
        String::new()
    }
    #[cfg(any(target_os = "android", target_os = "ios"))]
    {
        String::new()
    }
}

fn device_name() -> String {
    for key in ["COMPUTERNAME", "HOSTNAME", "DEVICE_NAME"] {
        if let Ok(value) = std::env::var(key) {
            if !value.trim().is_empty() {
                return value;
            }
        }
    }
    if cfg!(any(target_os = "android", target_os = "ios")) {
        "Мобильное устройство".into()
    } else {
        "Компьютер".into()
    }
}

#[tauri::command]
pub fn boot_info(app: AppHandle) -> BootInfo {
    let data_dir = app
        .path()
        .app_local_data_dir()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_default();
    let media_dir = imagine::media_dir_path(app.clone());
    BootInfo {
        platform: platform_id(),
        platform_label: platform_label(),
        arch: std::env::consts::ARCH.to_string(),
        os_version: os_version(),
        app_version: app.package_info().version.to_string(),
        data_dir,
        media_dir,
        is_mobile: cfg!(any(target_os = "android", target_os = "ios")),
        device_name: device_name(),
        webview: if cfg!(target_os = "windows") {
            "WebView2".into()
        } else if cfg!(any(target_os = "macos", target_os = "ios")) {
            "WKWebView".into()
        } else if cfg!(target_os = "android") {
            "Android WebView".into()
        } else {
            "WebKit".into()
        },
        locale: String::new(),
    }
}

fn state_path(app: &AppHandle) -> Result<std::path::PathBuf, String> {
    let dir = app
        .path()
        .app_local_data_dir()
        .map_err(|e| format!("Нет доступа к папке данных: {e}"))?;
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir.join("state.json"))
}

#[tauri::command]
pub fn load_state(app: AppHandle) -> Option<Value> {
    let path = state_path(&app).ok()?;
    let text = std::fs::read_to_string(path).ok()?;
    serde_json::from_str(&text).ok()
}

#[tauri::command]
pub fn save_state(app: AppHandle, data: Value) -> Result<(), String> {
    let path = state_path(&app)?;
    let tmp = path.with_extension("json.tmp");
    let text = serde_json::to_string(&data).map_err(|e| e.to_string())?;
    std::fs::write(&tmp, text).map_err(|e| format!("Ошибка записи: {e}"))?;
    std::fs::rename(&tmp, &path).map_err(|e| format!("Ошибка сохранения: {e}"))?;
    Ok(())
}

#[tauri::command]
pub fn set_close_to_tray(app: AppHandle, enabled: bool) {
    if let Some(prefs) = app.try_state::<Prefs>() {
        prefs.close_to_tray.store(enabled, Ordering::Relaxed);
    }
}

#[tauri::command]
pub fn notify(app: AppHandle, title: String, body: String) -> Result<(), String> {
    use tauri_plugin_notification::NotificationExt;
    app.notification()
        .builder()
        .title(title)
        .body(body)
        .show()
        .map_err(|e| e.to_string())
}

#[tauri::command]
pub fn hide_window(window: WebviewWindow) -> Result<(), String> {
    window.hide().map_err(|e| e.to_string())
}

#[tauri::command]
pub fn show_window(window: WebviewWindow) -> Result<(), String> {
    window.show().map_err(|e| e.to_string())?;
    let _ = window.set_focus();
    Ok(())
}

#[tauri::command]
pub fn app_quit(app: AppHandle) {
    app.exit(0);
}

#[tauri::command]
pub fn reveal_path(app: AppHandle, path: String) -> Result<(), String> {
    use tauri_plugin_opener::OpenerExt;
    app.opener()
        .open_path(path, None::<&str>)
        .map_err(|e| e.to_string())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AttachmentPayload {
    pub name: String,
    pub mime: String,
    pub size: u64,
    pub data_url: Option<String>,
    pub text: Option<String>,
}

#[tauri::command]
pub fn read_attachment(path: String) -> Result<AttachmentPayload, String> {
    let p = std::path::PathBuf::from(&path);
    let meta = std::fs::metadata(&p).map_err(|e| format!("Не удалось открыть файл: {e}"))?;
    if meta.is_dir() {
        return Err("Это папка, а не файл".to_string());
    }
    if meta.len() > 24_000_000 {
        return Err("Файл больше 24 МБ — прикрепите файл меньшего размера".to_string());
    }
    let name = p
        .file_name()
        .map(|f| f.to_string_lossy().to_string())
        .unwrap_or_else(|| "file".to_string());
    let mime = util::guess_mime(&p);
    let bytes = std::fs::read(&p).map_err(|e| format!("Ошибка чтения: {e}"))?;
    let is_text = mime.starts_with("text/")
        || mime.contains("json")
        || mime.contains("xml")
        || mime.contains("javascript")
        || mime.contains("typescript")
        || mime.contains("x-sh")
        || mime.contains("toml")
        || mime.contains("yaml");
    if mime.starts_with("image/") || mime.starts_with("audio/") || mime.starts_with("video/") {
        return Ok(AttachmentPayload {
            name,
            mime: mime.clone(),
            size: meta.len(),
            data_url: Some(util::data_url(&mime, &bytes)),
            text: None,
        });
    }
    if is_text && bytes.len() <= 600_000 {
        return Ok(AttachmentPayload {
            name,
            mime,
            size: meta.len(),
            data_url: None,
            text: Some(String::from_utf8_lossy(&bytes).to_string()),
        });
    }
    if !bytes.iter().take(4096).any(|b| *b == 0) && bytes.len() <= 600_000 {
        return Ok(AttachmentPayload {
            name,
            mime,
            size: meta.len(),
            data_url: None,
            text: Some(String::from_utf8_lossy(&bytes).to_string()),
        });
    }
    Err("Бинарные файлы нельзя прикрепить напрямую — положите их в рабочую папку и попросите модель прочитать.".to_string())
}

// ---------------------------------------------------------------------------
// Работа с провайдерами
// ---------------------------------------------------------------------------

#[derive(Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct ProviderIn {
    pub kind: String,
    pub base_url: String,
    #[serde(default)]
    pub api_key: String,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct ListedModel {
    pub id: String,
    pub label: Option<String>,
    pub context: Option<u64>,
}

#[tauri::command]
pub async fn list_models(provider: ProviderIn) -> Result<Vec<ListedModel>, String> {
    let client = util::client();
    if provider.base_url.trim().is_empty() {
        return Err("Не задан Base URL".to_string());
    }
    if provider.kind.eq_ignore_ascii_case("anthropic") {
        let url = util::join_url(&provider.base_url, "models");
        let mut rb = client
            .get(&url)
            .header("anthropic-version", "2023-06-01")
            .timeout(Duration::from_secs(30));
        if !provider.api_key.trim().is_empty() {
            rb = rb.header("x-api-key", provider.api_key.trim());
        }
        let resp = rb.send().await.map_err(|e| format!("Сеть: {e}"))?;
        let status = resp.status();
        let text = resp.text().await.unwrap_or_default();
        if !status.is_success() {
            return Err(util::friendly_status(status.as_u16(), &text));
        }
        let value: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
        let mut out = Vec::new();
        if let Some(items) = value.get("data").and_then(|d| d.as_array()) {
            for item in items {
                if let Some(id) = item.get("id").and_then(|v| v.as_str()) {
                    out.push(ListedModel {
                        id: id.to_string(),
                        label: item
                            .get("display_name")
                            .and_then(|v| v.as_str())
                            .map(|s| s.to_string()),
                        context: item.get("context_window").and_then(|v| v.as_u64()),
                    });
                }
            }
        }
        out.sort_by(|a, b| b.id.cmp(&a.id));
        return Ok(out);
    }

    let url = util::join_url(&provider.base_url, "models");
    let mut rb = client.get(&url).timeout(Duration::from_secs(30));
    if !provider.api_key.trim().is_empty() {
        rb = rb.bearer_auth(provider.api_key.trim());
    }
    if provider.base_url.contains("openrouter.ai") {
        rb = rb
            .header("HTTP-Referer", "https://bajlbesroute.app")
            .header("X-Title", "bAJlbesRoute");
    }
    let resp = rb.send().await.map_err(|e| format!("Сеть: {e}"))?;
    let status = resp.status();
    let text = resp.text().await.unwrap_or_default();
    if !status.is_success() {
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let value: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    if let Some(items) = value.get("data").and_then(|d| d.as_array()) {
        for item in items {
            let id = match item.get("id").and_then(|v| v.as_str()) {
                Some(id) => id.to_string(),
                None => continue,
            };
            let context = item
                .get("context_length")
                .and_then(|v| v.as_u64())
                .or_else(|| item.get("context_window").and_then(|v| v.as_u64()))
                .or_else(|| {
                    item.get("top_provider")
                        .and_then(|t| t.get("context_length"))
                        .and_then(|v| v.as_u64())
                });
            let label = item
                .get("name")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string());
            out.push(ListedModel { id, label, context });
        }
    }
    out.sort_by(|a, b| a.id.cmp(&b.id));
    Ok(out)
}

#[tauri::command]
pub async fn test_provider(provider: ProviderIn) -> Result<String, String> {
    let started = std::time::Instant::now();
    let models = list_models(provider).await?;
    Ok(format!(
        "Соединение успешно · моделей: {} · {} мс",
        models.len(),
        started.elapsed().as_millis()
    ))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceOverview {
    pub exists: bool,
    pub files: u64,
    pub size: u64,
    pub entries: Vec<String>,
}

#[tauri::command]
pub fn workspace_overview(app: AppHandle, path: String) -> WorkspaceOverview {
    let root = std::path::PathBuf::from(&path);
    if !root.is_dir() {
        return WorkspaceOverview {
            exists: false,
            files: 0,
            size: 0,
            entries: Vec::new(),
        };
    }
    imagine::scope_for_workspace(&app, &path);
    let (files, size, entries) = tools::overview(&root);
    WorkspaceOverview {
        exists: true,
        files,
        size,
        entries,
    }
}
