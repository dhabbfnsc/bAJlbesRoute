//! Общие утилиты: HTTP-клиент, разбор SSE, кодирование данных, ошибки.
use base64::Engine;
use serde_json::Value;
use std::time::Duration;

pub fn client() -> reqwest::Client {
    reqwest::Client::builder()
        .connect_timeout(Duration::from_secs(25))
        .pool_idle_timeout(Duration::from_secs(90))
        .user_agent(concat!("bAJlbesRoute/", env!("CARGO_PKG_VERSION")))
        .build()
        .unwrap_or_else(|_| reqwest::Client::new())
}

/// Аккуратно склеивает базовый URL и путь, не дублируя уже указанный путь.
pub fn join_url(base: &str, path: &str) -> String {
    let mut b = base.trim().trim_end_matches('/').to_string();
    let p = path.trim_start_matches('/');
    if b.is_empty() {
        return p.to_string();
    }
    // Пользователь мог вставить полный URL вместе с путём.
    let bl = b.to_lowercase();
    let pl = p.to_lowercase();
    if bl.ends_with(&format!("/{}", pl)) {
        return b;
    }
    if bl.ends_with("/chat/completions") && pl == "chat/completions" {
        return b;
    }
    if bl.ends_with("/messages") && pl == "messages" {
        return b;
    }
    b.push('/');
    b.push_str(p);
    b
}

pub fn friendly_status(status: u16, body: &str) -> String {
    let snippet = body.trim();
    let snippet = if snippet.chars().count() > 600 {
        let s: String = snippet.chars().take(600).collect();
        format!("{s}…")
    } else {
        snippet.to_string()
    };
    let hint = match status {
        400 => "Неверный запрос — проверьте имя модели и параметры",
        401 => "Неверный API-ключ",
        402 => "Нужна оплата / закончились средства на счёте",
        403 => "Доступ запрещён (ключ, регион или права)",
        404 => "Endpoint или модель не найдены — проверьте Base URL",
        408 => "Таймаут запроса",
        413 => "Слишком большой запрос",
        422 => "Провайдер отклонил параметры запроса",
        429 => "Слишком много запросов / лимит",
        500..=599 => "Ошибка на стороне провайдера",
        _ => "Запрос отклонён",
    };
    if snippet.is_empty() {
        format!("{hint} (HTTP {status})")
    } else {
        format!("{hint} (HTTP {status}): {snippet}")
    }
}

pub fn b64_decode(data: &str) -> Result<Vec<u8>, String> {
    let cleaned: String = data
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect::<String>();
    base64::engine::general_purpose::STANDARD
        .decode(cleaned.as_bytes())
        .map_err(|e| format!("Ошибка декодирования base64: {e}"))
}

pub fn b64_encode(data: &[u8]) -> String {
    base64::engine::general_purpose::STANDARD.encode(data)
}

/// Разбирает data-url (`data:image/png;base64,....`).
pub fn parse_data_url(input: &str) -> Option<(String, Vec<u8>)> {
    let rest = input.trim().strip_prefix("data:")?;
    let (meta, payload) = rest.split_once(',')?;
    let mime = meta.split(';').next().unwrap_or("application/octet-stream").to_string();
    if meta.contains(";base64") {
        b64_decode(payload).ok().map(|b| (mime, b))
    } else {
        percent_decode(payload).map(|b| (mime, b))
    }
}

fn percent_decode(s: &str) -> Option<Vec<u8>> {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).ok()?;
            out.push(u8::from_str_radix(hex, 16).ok()?);
            i += 3;
        } else {
            out.push(bytes[i]);
            i += 1;
        }
    }
    Some(out)
}

pub fn data_url(mime: &str, bytes: &[u8]) -> String {
    format!("data:{mime};base64,{}", b64_encode(bytes))
}

pub fn guess_mime(path: &std::path::Path) -> String {
    mime_guess::from_path(path)
        .first_or_octet_stream()
        .essence_str()
        .to_string()
}

pub fn now_ms() -> i64 {
    chrono::Utc::now().timestamp_millis()
}

pub fn slug(input: &str, max: usize) -> String {
    let mut out = String::new();
    for ch in input.chars() {
        if ch.is_alphanumeric() {
            out.push(ch.to_lowercase().next().unwrap_or(ch));
        } else if (ch.is_whitespace() || ch == '-' || ch == '_') && !out.ends_with('-') {
            out.push('-');
        }
        if out.chars().count() >= max {
            break;
        }
    }
    let trimmed = out.trim_matches('-').to_string();
    if trimmed.is_empty() {
        "media".to_string()
    } else {
        trimmed
    }
}

pub fn truncate_chars(s: &str, max: usize) -> String {
    if s.chars().count() <= max {
        s.to_string()
    } else {
        let mut out: String = s.chars().take(max).collect();
        out.push('…');
        out
    }
}

/// Достаёт base64/URL изображения из произвольного JSON-ответа провайдера.
pub fn find_string_deep(value: &Value, keys: &[&str]) -> Option<String> {
    match value {
        Value::Object(map) => {
            for (k, v) in map {
                if keys.iter().any(|want| want.eq_ignore_ascii_case(k)) {
                    if let Value::String(s) = v {
                        if !s.is_empty() {
                            return Some(s.clone());
                        }
                    }
                }
            }
            for v in map.values() {
                if let Some(found) = find_string_deep(v, keys) {
                    return Some(found);
                }
            }
            None
        }
        Value::Array(items) => items.iter().find_map(|v| find_string_deep(v, keys)),
        _ => None,
    }
}

// ---------------------------------------------------------------------------
// SSE
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Default)]
pub struct SseEvent {
    pub event: Option<String>,
    pub data: String,
}

/// Инкрементальный разбор server-sent events.
#[derive(Default)]
pub struct SseBuffer {
    buf: String,
}

impl SseBuffer {
    pub fn push(&mut self, chunk: &[u8]) -> Vec<SseEvent> {
        self.buf.push_str(&String::from_utf8_lossy(chunk));
        let mut events = Vec::new();
        loop {
            let split_at = find_separator(&self.buf);
            let Some((idx, sep_len)) = split_at else { break };
            let block: String = self.buf.drain(..idx + sep_len).collect();
            let block = &block[..block.len().saturating_sub(sep_len)];
            if let Some(ev) = parse_block(block) {
                events.push(ev);
            }
        }
        events
    }

    /// Забирает остаток буфера (если поток закончился без пустой строки).
    pub fn flush(&mut self) -> Option<SseEvent> {
        if self.buf.trim().is_empty() {
            return None;
        }
        let block = std::mem::take(&mut self.buf);
        parse_block(&block)
    }
}

fn find_separator(buf: &str) -> Option<(usize, usize)> {
    let crlf = buf.find("\r\n\r\n").map(|i| (i, 4usize));
    let lf = buf.find("\n\n").map(|i| (i, 2usize));
    match (crlf, lf) {
        (Some(a), Some(b)) => Some(if a.0 <= b.0 { a } else { b }),
        (Some(a), None) => Some(a),
        (None, Some(b)) => Some(b),
        (None, None) => None,
    }
}

fn parse_block(block: &str) -> Option<SseEvent> {
    let mut event = None;
    let mut data_lines: Vec<String> = Vec::new();
    for raw in block.split('\n') {
        let line = raw.trim_end_matches('\r');
        if line.is_empty() || line.starts_with(':') {
            continue;
        }
        if let Some(rest) = line.strip_prefix("event:") {
            event = Some(rest.trim().to_string());
        } else if let Some(rest) = line.strip_prefix("data:") {
            data_lines.push(rest.strip_prefix(' ').unwrap_or(rest).to_string());
        }
    }
    if event.is_none() && data_lines.is_empty() {
        return None;
    }
    Some(SseEvent {
        event,
        data: data_lines.join("\n"),
    })
}

pub fn urlencode(input: &str) -> String {
    let mut out = String::with_capacity(input.len() * 3);
    for byte in input.as_bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(*byte as char)
            }
            _ => out.push_str(&format!("%{byte:02X}")),
        }
    }
    out
}
