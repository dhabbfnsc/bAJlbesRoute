//! Модуль «Imagine»: генерация изображений и видео.
//! Принцип: запускаем всех доступных провайдеров параллельно и берём первый
//! успешный ответ. Все попытки логируются в события `imagine:event`.
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use futures_util::future::{BoxFuture, Future};
use futures_util::stream::{FuturesUnordered, StreamExt};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tauri::{AppHandle, Emitter, Manager, State};
use tokio_util::sync::CancellationToken;

use crate::util;

#[derive(Default)]
pub struct ImagineState {
    pub jobs: Mutex<HashMap<String, CancellationToken>>,
}

#[derive(Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct ImagineRequest {
    pub id: String,
    /// "image" | "video"
    pub mode: String,
    pub prompt: String,
    #[serde(default)]
    pub image: Option<String>,
    #[serde(default)]
    pub aspect: Option<String>,
    #[serde(default)]
    pub providers: ImagineKeys,
    #[serde(default)]
    pub workspace: Option<String>,
}

#[derive(Deserialize, Clone, Debug, Default)]
#[serde(rename_all = "camelCase")]
pub struct ImagineKeys {
    #[serde(default)]
    pub openai: Option<Endpoint>,
    #[serde(default)]
    pub google: Option<Endpoint>,
    #[serde(default)]
    pub fal: Option<String>,
    #[serde(default)]
    pub replicate: Option<String>,
    #[serde(default)]
    pub together: Option<String>,
    #[serde(default)]
    pub stability: Option<String>,
    #[serde(default)]
    pub pollinations: Option<bool>,
    #[serde(default)]
    pub custom_images: Vec<Endpoint>,
    #[serde(default, rename = "replicateT2VModel")]
    pub replicate_t2v_model: Option<String>,
    #[serde(default, rename = "replicateI2VModel")]
    pub replicate_i2v_model: Option<String>,
}

#[derive(Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct Endpoint {
    #[serde(default)]
    pub name: Option<String>,
    pub base_url: String,
    #[serde(default)]
    pub api_key: String,
    #[serde(default)]
    pub model: Option<String>,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Attempt {
    pub provider: String,
    pub ok: bool,
    pub error: Option<String>,
    pub ms: i64,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct MediaResult {
    pub path: String,
    pub mime: String,
    pub kind: String,
    pub provider: String,
    pub data_url: Option<String>,
    pub attempts: Vec<Attempt>,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ImagineEvent {
    id: String,
    #[serde(rename = "type")]
    kind: String,
    provider: Option<String>,
    message: Option<String>,
    path: Option<String>,
}

struct MediaPayload {
    provider: String,
    bytes: Vec<u8>,
    mime: String,
    kind: String,
}

type Candidate = (String, BoxFuture<'static, Result<MediaPayload, String>>);

fn boxed<F>(fut: F) -> BoxFuture<'static, Result<MediaPayload, String>>
where
    F: Future<Output = Result<MediaPayload, String>> + Send + 'static,
{
    Box::pin(fut)
}

#[tauri::command]
pub async fn imagine_generate(
    app: AppHandle,
    state: State<'_, ImagineState>,
    req: ImagineRequest,
) -> Result<MediaResult, String> {
    let token = CancellationToken::new();
    {
        let mut jobs = state.jobs.lock().map_err(|e| e.to_string())?;
        jobs.insert(req.id.clone(), token.clone());
    }
    let app2 = app.clone();
    let req2 = req.clone();
    let result = run_imagine(&app2, &req2, token).await;
    if let Ok(mut jobs) = state.jobs.lock() {
        jobs.remove(&req.id);
    }
    result
}

#[tauri::command]
pub fn imagine_cancel(state: State<'_, ImagineState>, id: String) {
    if let Ok(jobs) = state.jobs.lock() {
        if let Some(token) = jobs.get(&id) {
            token.cancel();
        }
    }
}

fn emit(app: &AppHandle, req: &ImagineRequest, kind: &str, provider: Option<&str>, message: Option<String>, path: Option<String>) {
    let _ = app.emit(
        "imagine:event",
        ImagineEvent {
            id: req.id.clone(),
            kind: kind.to_string(),
            provider: provider.map(|p| p.to_string()),
            message,
            path,
        },
    );
}

async fn run_imagine(
    app: &AppHandle,
    req: &ImagineRequest,
    token: CancellationToken,
) -> Result<MediaResult, String> {
    if let Some(ws) = req.workspace.as_deref() {
        scope_for_workspace(app, ws);
    }
    let client = util::client();
    let prompt = req.prompt.trim().to_string();
    if prompt.is_empty() && req.image.is_none() {
        return Err("Опишите, что нужно сгенерировать".to_string());
    }
    let aspect = req.aspect.clone().unwrap_or_else(|| "1:1".to_string());
    let candidates = build_candidates(&client, req, &prompt, &aspect);

    if candidates.is_empty() {
        return Err("Нет доступных источников. Добавьте ключ в Настройки → Imagine.".to_string());
    }

    let mut names: Vec<String> = candidates.iter().map(|(n, _)| n.clone()).collect();
    names.sort();
    emit(
        app,
        req,
        "start",
        None,
        Some(format!("Запускаю {} источника(ов): {}", names.len(), names.join(", "))),
        None,
    );

    let mut futures: FuturesUnordered<BoxFuture<'static, (String, Result<MediaPayload, String>, i64)>> =
        FuturesUnordered::new();
    for (name, fut) in candidates {
        let started = Instant::now();
        futures.push(Box::pin(async move {
            let result = fut.await;
            (name, result, started.elapsed().as_millis() as i64)
        }) as BoxFuture<'static, (String, Result<MediaPayload, String>, i64)>);
    }

    let mut attempts: Vec<Attempt> = Vec::new();
    let winner = loop {
        let next = tokio::select! {
            _ = token.cancelled() => {
                emit(app, req, "error", None, Some("Генерация отменена".to_string()), None);
                return Err("Генерация отменена".to_string());
            }
            next = futures.next() => next,
        };
        let Some((name, result, ms)) = next else { break None };
        match result {
            Ok(payload) => {
                emit(
                    app,
                    req,
                    "success",
                    Some(&payload.provider),
                    Some(format!("{} ответил первым за {ms} мс", payload.provider)),
                    None,
                );
                break Some((payload, ms));
            }
            Err(err) => {
                emit(
                    app,
                    req,
                    "fail",
                    Some(&name),
                    Some(util::truncate_chars(&err, 300)),
                    None,
                );
                attempts.push(Attempt {
                    provider: name,
                    ok: false,
                    error: Some(err),
                    ms,
                });
            }
        }
    };

    let Some((payload, ms)) = winner else {
        let details = attempts
            .iter()
            .map(|a| format!("• {}: {}", a.provider, a.error.clone().unwrap_or_default()))
            .collect::<Vec<_>>()
            .join("\n");
        return Err(format!("Ни один источник не ответил:\n{details}"));
    };

    let dir = media_dir(app);
    let ext = extension_for(&payload.mime, &payload.kind);
    let path = save_media(&dir, &payload.provider, &prompt, ext, &payload.bytes)?;
    attempts.push(Attempt {
        provider: payload.provider.clone(),
        ok: true,
        error: None,
        ms,
    });

    let data_url = if payload.kind == "image" && payload.bytes.len() < 9_000_000 {
        Some(util::data_url(&payload.mime, &payload.bytes))
    } else {
        None
    };

    let result = MediaResult {
        path: path.to_string_lossy().to_string(),
        mime: payload.mime,
        kind: payload.kind,
        provider: payload.provider,
        data_url,
        attempts,
    };
    emit(
        app,
        req,
        "done",
        Some(&result.provider),
        None,
        Some(result.path.clone()),
    );
    Ok(result)
}

fn media_dir(app: &AppHandle) -> PathBuf {
    let dir = app
        .path()
        .app_local_data_dir()
        .unwrap_or_else(|_| std::env::temp_dir())
        .join("media");
    let _ = std::fs::create_dir_all(&dir);
    dir
}

fn extension_for(mime: &str, kind: &str) -> &'static str {
    if kind == "video" {
        return "mp4";
    }
    match mime {
        "image/png" => "png",
        "image/webp" => "webp",
        "image/gif" => "gif",
        "image/jpeg" | "image/jpg" => "jpg",
        _ => "png",
    }
}

fn save_media(dir: &Path, provider: &str, prompt: &str, ext: &str, bytes: &[u8]) -> Result<PathBuf, String> {
    let stamp = chrono::Utc::now().timestamp_millis();
    let slug = util::slug(prompt, 40);
    let name = format!("{stamp}-{}-{slug}.{ext}", util::slug(provider, 14));
    let path = dir.join(name);
    std::fs::write(&path, bytes).map_err(|e| format!("Не удалось сохранить файл: {e}"))?;
    Ok(path)
}

fn build_candidates(
    client: &reqwest::Client,
    req: &ImagineRequest,
    prompt: &str,
    aspect: &str,
) -> Vec<Candidate> {
    let mut list: Vec<Candidate> = Vec::new();
    let keys = &req.providers;
    let image_input = req.image.clone();
    let is_video = req.mode == "video";

    if is_video {
        if let Some(key) = clean_key(&keys.fal) {
            let c = client.clone();
            let p = prompt.to_string();
            let a = aspect.to_string();
            let img = image_input.clone();
            list.push((
                "fal.ai".to_string(),
                boxed(async move { fal_video(&c, &key, &p, &a, img).await }),
            ));
        }
        if let Some(token) = clean_key(&keys.replicate) {
            let c = client.clone();
            let p = prompt.to_string();
            let img = image_input.clone();
            let t2v = keys
                .replicate_t2v_model
                .clone()
                .unwrap_or_else(|| "wan-video/wan-2.2-t2v-fast".to_string());
            let i2v = keys
                .replicate_i2v_model
                .clone()
                .unwrap_or_else(|| "wan-video/wan-2.2-i2v-fast".to_string());
            list.push((
                "replicate".to_string(),
                boxed(async move { replicate_video(&c, &token, &p, img, &t2v, &i2v).await }),
            ));
        }
        if let Some(ep) = keys.google.clone().filter(|e| !e.api_key.trim().is_empty()) {
            let c = client.clone();
            let p = prompt.to_string();
            let a = aspect.to_string();
            let img = image_input.clone();
            list.push((
                "google-veo".to_string(),
                boxed(async move { veo_video(&c, &ep, &p, &a, img).await }),
            ));
        }
        return list;
    }

    // --- Изображения ---
    for ep in keys.custom_images.iter() {
        let ep = ep.clone();
        if ep.base_url.trim().is_empty() {
            continue;
        }
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        let name = ep
            .name
            .clone()
            .filter(|n| !n.trim().is_empty())
            .unwrap_or_else(|| "custom".to_string());
        let label = format!("custom:{name}");
        list.push((
            label,
            boxed(async move { openai_image(&c, &ep, &p, &a).await }),
        ));
    }
    if let Some(ep) = keys.openai.clone().filter(|e| !e.api_key.trim().is_empty()) {
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        list.push((
            "openai".to_string(),
            boxed(async move { openai_image(&c, &ep, &p, &a).await }),
        ));
    }
    if let Some(key) = clean_key(&together_or_none(keys)) {
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        list.push((
            "together".to_string(),
            boxed(async move { together_image(&c, &key, &p, &a).await }),
        ));
    }
    if let Some(key) = clean_key(&keys.fal) {
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        list.push((
            "fal.ai".to_string(),
            boxed(async move { fal_image(&c, &key, &p, &a).await }),
        ));
    }
    if let Some(key) = clean_key(&keys.stability) {
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        list.push((
            "stability".to_string(),
            boxed(async move { stability_image(&c, &key, &p, &a).await }),
        ));
    }
    if keys.pollinations.unwrap_or(true) {
        let c = client.clone();
        let p = prompt.to_string();
        let a = aspect.to_string();
        list.push((
            "pollinations".to_string(),
            boxed(async move { pollinations_image(&c, &p, &a).await }),
        ));
    }
    list
}

fn clean_key(key: &Option<String>) -> Option<String> {
    key.as_ref()
        .map(|k| k.trim().to_string())
        .filter(|k| !k.is_empty())
}

fn together_or_none(keys: &ImagineKeys) -> Option<String> {
    clean_key(&keys.together)
}

// ---------------------------------------------------------------------------
// Хелперы
// ---------------------------------------------------------------------------

fn dims(aspect: &str) -> (u32, u32) {
    match aspect {
        "16:9" => (1280, 720),
        "9:16" => (720, 1280),
        "4:3" => (1024, 768),
        "3:4" => (768, 1024),
        "3:2" => (1216, 832),
        "2:3" => (832, 1216),
        _ => (1024, 1024),
    }
}

fn fal_image_size(aspect: &str) -> &'static str {
    match aspect {
        "16:9" => "landscape_16_9",
        "9:16" => "portrait_16_9",
        "4:3" => "landscape_4_3",
        "3:4" => "portrait_4_3",
        _ => "square_hd",
    }
}

fn openai_size(model: &str, aspect: &str) -> String {
    let legacy = model.to_lowercase().starts_with("dall-e");
    match aspect {
        "16:9" | "4:3" | "3:2" => {
            if legacy {
                "1792x1024".to_string()
            } else {
                "1536x1024".to_string()
            }
        }
        "9:16" | "3:4" | "2:3" => {
            if legacy {
                "1024x1792".to_string()
            } else {
                "1024x1536".to_string()
            }
        }
        _ => "1024x1024".to_string(),
    }
}

async fn fetch_bytes(
    client: &reqwest::Client,
    url: &str,
    headers: &[(&str, String)],
) -> Result<(Vec<u8>, String), String> {
    let mut rb = client.get(url);
    for (k, v) in headers {
        rb = rb.header(*k, v.as_str());
    }
    let resp = rb
        .timeout(Duration::from_secs(180))
        .send()
        .await
        .map_err(|e| format!("Не удалось скачать файл: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let body = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &body));
    }
    let mime = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("application/octet-stream")
        .split(';')
        .next()
        .unwrap_or("application/octet-stream")
        .to_string();
    let bytes = resp
        .bytes()
        .await
        .map_err(|e| format!("Ошибка чтения файла: {e}"))?
        .to_vec();
    Ok((bytes, mime))
}

fn image_mime_or_default(mime: &str) -> String {
    if mime.starts_with("image/") {
        mime.to_string()
    } else if mime.contains("json") || mime.contains("text") {
        "image/png".to_string()
    } else {
        "image/png".to_string()
    }
}

async fn image_from_json(client: &reqwest::Client, value: &Value) -> Result<(Vec<u8>, String), String> {
    if let Some(err) = value.get("error") {
        let msg = err
            .get("message")
            .and_then(|m| m.as_str())
            .or_else(|| err.as_str())
            .unwrap_or("провайдер вернул ошибку");
        return Err(msg.to_string());
    }
    let b64 = util::find_string_deep(value, &["b64_json", "base64", "image_base64", "image"]);
    if let Some(data) = b64 {
        if let Ok(bytes) = util::b64_decode(&data) {
            if !bytes.is_empty() {
                let mime = sniff_image_mime(&bytes);
                return Ok((bytes, mime));
            }
        }
    }
    for key in ["url", "image_url", "uri", "output"] {
        if let Some(url) = util::find_string_deep(value, &[key]) {
            if url.starts_with("http") {
                let (bytes, mime) = fetch_bytes(client, &url, &[]).await?;
                return Ok((bytes, image_mime_or_default(&mime)));
            }
            if url.starts_with("data:") {
                if let Some((mime, bytes)) = util::parse_data_url(&url) {
                    return Ok((bytes, image_mime_or_default(&mime)));
                }
            }
        }
    }
    Err(format!(
        "не удалось найти изображение в ответе: {}",
        util::truncate_chars(&value.to_string(), 220)
    ))
}

fn sniff_image_mime(bytes: &[u8]) -> String {
    if bytes.starts_with(&[0x89, b'P', b'N', b'G']) {
        "image/png".to_string()
    } else if bytes.starts_with(&[0xFF, 0xD8]) {
        "image/jpeg".to_string()
    } else if bytes.starts_with(b"RIFF") && bytes.len() > 12 && &bytes[8..12] == b"WEBP" {
        "image/webp".to_string()
    } else if bytes.starts_with(b"GIF8") {
        "image/gif".to_string()
    } else {
        "image/png".to_string()
    }
}

async fn video_from_json(client: &reqwest::Client, value: &Value) -> Result<Vec<u8>, String> {
    if let Some(err) = value.get("error") {
        let msg = err
            .get("message")
            .and_then(|m| m.as_str())
            .or_else(|| err.as_str())
            .unwrap_or("провайдер вернул ошибку");
        return Err(msg.to_string());
    }
    for key in ["video", "video_url", "url", "uri", "output", "file_url"] {
        if let Some(url) = util::find_string_deep(value, &[key]) {
            if url.starts_with("http") {
                let (bytes, _) = fetch_bytes(client, &url, &[]).await?;
                if !bytes.is_empty() {
                    return Ok(bytes);
                }
            }
            if url.starts_with("data:") {
                if let Some((_, bytes)) = util::parse_data_url(&url) {
                    return Ok(bytes);
                }
            }
        }
    }
    if let Some(b64) = util::find_string_deep(value, &["b64_json", "base64", "video_base64"]) {
        if let Ok(bytes) = util::b64_decode(&b64) {
            if !bytes.is_empty() {
                return Ok(bytes);
            }
        }
    }
    Err(format!(
        "в ответе нет ссылки на видео: {}",
        util::truncate_chars(&value.to_string(), 220)
    ))
}

// ---------------------------------------------------------------------------
// Изображения
// ---------------------------------------------------------------------------

async fn openai_image(
    client: &reqwest::Client,
    ep: &Endpoint,
    prompt: &str,
    aspect: &str,
) -> Result<MediaPayload, String> {
    let url = util::join_url(&ep.base_url, "images/generations");
    let model = ep
        .model
        .clone()
        .filter(|m| !m.trim().is_empty())
        .unwrap_or_else(|| "gpt-image-1".to_string());
    let body = json!({
        "model": model,
        "prompt": prompt,
        "n": 1,
        "size": openai_size(&model, aspect),
    });
    let mut rb = client
        .post(&url)
        .header("content-type", "application/json")
        .timeout(Duration::from_secs(300));
    if !ep.api_key.trim().is_empty() {
        rb = rb.bearer_auth(ep.api_key.trim());
    }
    let resp = rb
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let value: Value = resp.json().await.map_err(|e| format!("json: {e}"))?;
    let (bytes, mime) = image_from_json(client, &value).await?;
    Ok(MediaPayload {
        provider: ep
            .name
            .clone()
            .unwrap_or_else(|| "openai".to_string()),
        bytes,
        mime,
        kind: "image".to_string(),
    })
}

async fn together_image(
    client: &reqwest::Client,
    key: &str,
    prompt: &str,
    aspect: &str,
) -> Result<MediaPayload, String> {
    let (w, h) = dims(aspect);
    let body = json!({
        "model": "black-forest-labs/FLUX.1-schnell-Free",
        "prompt": prompt,
        "width": w,
        "height": h,
        "steps": 4,
        "n": 1,
        "response_format": "b64_json",
    });
    let resp = client
        .post("https://api.together.xyz/v1/images/generations")
        .bearer_auth(key)
        .timeout(Duration::from_secs(240))
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let value: Value = resp.json().await.map_err(|e| format!("json: {e}"))?;
    let (bytes, mime) = image_from_json(client, &value).await?;
    Ok(MediaPayload {
        provider: "together".to_string(),
        bytes,
        mime,
        kind: "image".to_string(),
    })
}

async fn fal_image(
    client: &reqwest::Client,
    key: &str,
    prompt: &str,
    aspect: &str,
) -> Result<MediaPayload, String> {
    let body = json!({
        "prompt": prompt,
        "image_size": fal_image_size(aspect),
        "num_inference_steps": 4,
        "num_images": 1,
        "enable_safety_checker": false,
    });
    let resp = client
        .post("https://fal.run/fal-ai/flux/schnell")
        .header("Authorization", format!("Key {key}"))
        .timeout(Duration::from_secs(240))
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let value: Value = resp.json().await.map_err(|e| format!("json: {e}"))?;
    let (bytes, mime) = image_from_json(client, &value).await?;
    Ok(MediaPayload {
        provider: "fal.ai".to_string(),
        bytes,
        mime,
        kind: "image".to_string(),
    })
}

async fn stability_image(
    client: &reqwest::Client,
    key: &str,
    prompt: &str,
    aspect: &str,
) -> Result<MediaPayload, String> {
    let form = reqwest::multipart::Form::new()
        .text("prompt", prompt.to_string())
        .text("aspect_ratio", aspect.to_string())
        .text("output_format", "png");
    let resp = client
        .post("https://api.stability.ai/v2beta/stable-image/generate/core")
        .header("Authorization", format!("Bearer {key}"))
        .header("Accept", "image/*")
        .timeout(Duration::from_secs(240))
        .multipart(form)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let mime = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("image/png")
        .to_string();
    let bytes = resp
        .bytes()
        .await
        .map_err(|e| format!("чтение: {e}"))?
        .to_vec();
    if bytes.is_empty() {
        return Err("пустой ответ".to_string());
    }
    Ok(MediaPayload {
        provider: "stability".to_string(),
        bytes,
        mime: image_mime_or_default(&mime),
        kind: "image".to_string(),
    })
}

async fn pollinations_image(
    client: &reqwest::Client,
    prompt: &str,
    aspect: &str,
) -> Result<MediaPayload, String> {
    let (w, h) = dims(aspect);
    let seed = chrono::Utc::now().timestamp_millis();
    let url = format!(
        "https://image.pollinations.ai/prompt/{}?width={w}&height={h}&seed={seed}&nologo=true&model=flux&referrer=bajlbesroute.app",
        util::urlencode(prompt)
    );
    let (bytes, mime) = fetch_bytes(client, &url, &[]).await?;
    if bytes.len() < 512 {
        return Err("получен некорректный файл".to_string());
    }
    Ok(MediaPayload {
        provider: "pollinations".to_string(),
        bytes,
        mime: image_mime_or_default(&mime),
        kind: "image".to_string(),
    })
}

// ---------------------------------------------------------------------------
// Видео
// ---------------------------------------------------------------------------

async fn fal_video(
    client: &reqwest::Client,
    key: &str,
    prompt: &str,
    aspect: &str,
    image: Option<String>,
) -> Result<MediaPayload, String> {
    let (path, body) = match image {
        Some(img) => (
            "fal-ai/ltx-video/image-to-video",
            json!({ "prompt": prompt, "image_url": img }),
        ),
        None => (
            "fal-ai/ltx-video",
            json!({ "prompt": prompt, "aspect_ratio": aspect }),
        ),
    };
    let resp = client
        .post(format!("https://fal.run/{path}"))
        .header("Authorization", format!("Key {key}"))
        .timeout(Duration::from_secs(900))
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(status.as_u16(), &text));
    }
    let value: Value = resp.json().await.map_err(|e| format!("json: {e}"))?;
    let bytes = video_from_json(client, &value).await?;
    Ok(MediaPayload {
        provider: "fal.ai".to_string(),
        bytes,
        mime: "video/mp4".to_string(),
        kind: "video".to_string(),
    })
}

async fn replicate_video(
    client: &reqwest::Client,
    token: &str,
    prompt: &str,
    image: Option<String>,
    t2v_model: &str,
    i2v_model: &str,
) -> Result<MediaPayload, String> {
    let (model, input) = match &image {
        Some(img) => (i2v_model, json!({ "prompt": prompt, "image": img })),
        None => (t2v_model, json!({ "prompt": prompt })),
    };
    let url = format!("https://api.replicate.com/v1/models/{model}/predictions");
    let resp = client
        .post(&url)
        .header("Authorization", format!("Bearer {token}"))
        .header("Prefer", "wait=60")
        .timeout(Duration::from_secs(120))
        .json(&json!({ "input": input }))
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    let mut value: Value = resp
        .json()
        .await
        .map_err(|e| format!("json: {e}"))?;
    if !status.is_success() {
        return Err(util::friendly_status(
            status.as_u16(),
            &value.to_string(),
        ));
    }
    let get_url = value
        .get("urls")
        .and_then(|u| u.get("get"))
        .and_then(|u| u.as_str())
        .unwrap_or("")
        .to_string();
    let mut waited = 0u64;
    loop {
        let state = value.get("status").and_then(|s| s.as_str()).unwrap_or("");
        match state {
            "succeeded" => break,
            "failed" | "canceled" => {
                let msg = value
                    .get("error")
                    .and_then(|e| e.as_str())
                    .unwrap_or("задача завершилась ошибкой");
                return Err(msg.to_string());
            }
            _ => {}
        }
        if get_url.is_empty() || waited > 600 {
            return Err(format!("таймаут ожидания (статус: {state})"));
        }
        tokio::time::sleep(Duration::from_secs(4)).await;
        waited += 4;
        let poll = client
            .get(&get_url)
            .header("Authorization", format!("Bearer {token}"))
            .timeout(Duration::from_secs(30))
            .send()
            .await
            .map_err(|e| format!("сеть: {e}"))?;
        value = poll.json().await.map_err(|e| format!("json: {e}"))?;
    }
    let output = value.get("output").cloned().unwrap_or(Value::Null);
    let bytes = video_from_json(client, &output).await?;
    Ok(MediaPayload {
        provider: "replicate".to_string(),
        bytes,
        mime: "video/mp4".to_string(),
        kind: "video".to_string(),
    })
}

async fn veo_video(
    client: &reqwest::Client,
    ep: &Endpoint,
    prompt: &str,
    aspect: &str,
    image: Option<String>,
) -> Result<MediaPayload, String> {
    let mut base = ep.base_url.trim().trim_end_matches('/').to_string();
    if base.contains("generativelanguage.googleapis.com") {
        base = "https://generativelanguage.googleapis.com".to_string();
    } else if !base.is_empty() {
        base = base.trim_end_matches("/v1beta").to_string();
    } else {
        base = "https://generativelanguage.googleapis.com".to_string();
    }
    let mut instance = json!({ "prompt": prompt });
    if let Some(img) = image {
        if let Some((mime, bytes)) = util::parse_data_url(&img) {
            instance["image"] = json!({
                "bytesBase64Encoded": util::b64_encode(&bytes),
                "mimeType": mime,
            });
        }
    }
    let body = json!({
        "instances": [instance],
        "parameters": { "aspectRatio": aspect, "personGeneration": "allow_adult" }
    });
    let url = format!("{base}/v1beta/models/veo-3.0-fast-generate-001:predictLongRunning");
    let resp = client
        .post(&url)
        .header("x-goog-api-key", ep.api_key.trim())
        .timeout(Duration::from_secs(120))
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("сеть: {e}"))?;
    let status = resp.status();
    let value: Value = resp.json().await.map_err(|e| format!("json: {e}"))?;
    if !status.is_success() {
        return Err(util::friendly_status(status.as_u16(), &value.to_string()));
    }
    let op = value
        .get("name")
        .and_then(|v| v.as_str())
        .ok_or_else(|| "операция не создана".to_string())?
        .to_string();
    let poll_url = format!("{base}/v1beta/{op}");
    let mut waited = 0u64;
    loop {
        if waited > 600 {
            return Err("таймаут ожидания видео".to_string());
        }
        tokio::time::sleep(Duration::from_secs(8)).await;
        waited += 8;
        let poll = client
            .get(&poll_url)
            .header("x-goog-api-key", ep.api_key.trim())
            .timeout(Duration::from_secs(40))
            .send()
            .await
            .map_err(|e| format!("сеть: {e}"))?;
        let status = poll.status();
        let value: Value = poll.json().await.map_err(|e| format!("json: {e}"))?;
        if !status.is_success() {
            return Err(util::friendly_status(status.as_u16(), &value.to_string()));
        }
        if let Some(err) = value.get("error") {
            let msg = err
                .get("message")
                .and_then(|m| m.as_str())
                .unwrap_or("ошибка операции");
            return Err(msg.to_string());
        }
        if value.get("done").and_then(|d| d.as_bool()).unwrap_or(false) {
            let uri = util::find_string_deep(&value, &["uri", "video", "video_url", "url"])
                .ok_or_else(|| "в результате нет ссылки на видео".to_string())?;
            let (bytes, _) = fetch_bytes(
                client,
                &uri,
                &[("x-goog-api-key", ep.api_key.trim().to_string())],
            )
            .await?;
            return Ok(MediaPayload {
                provider: "google-veo".to_string(),
                bytes,
                mime: "video/mp4".to_string(),
                kind: "video".to_string(),
            });
        }
    }
}

// ---------------------------------------------------------------------------
// Работа с файлами медиа
// ---------------------------------------------------------------------------

#[tauri::command]
pub fn media_delete(app: AppHandle, path: String) -> Result<(), String> {
    let media_root = media_dir(&app);
    let target = PathBuf::from(&path);
    let canon_root = media_root.canonicalize().unwrap_or(media_root.clone());
    let canon_target = target.canonicalize().unwrap_or(target.clone());
    if !canon_target.starts_with(&canon_root) {
        return Err("Можно удалять только файлы из галереи".to_string());
    }
    std::fs::remove_file(&canon_target).map_err(|e| format!("Не удалось удалить: {e}"))
}

#[tauri::command]
pub fn media_copy(src: String, dest: String) -> Result<String, String> {
    let from = PathBuf::from(&src);
    let to_dir = PathBuf::from(&dest);
    let _ = std::fs::create_dir_all(&to_dir);
    let name = from
        .file_name()
        .ok_or_else(|| "Некорректный путь".to_string())?;
    let target = to_dir.join(name);
    std::fs::copy(&from, &target).map_err(|e| format!("Не удалось скопировать: {e}"))?;
    Ok(target.to_string_lossy().to_string())
}

#[tauri::command]
pub fn media_dir_path(app: AppHandle) -> String {
    media_dir(&app).to_string_lossy().to_string()
}

/// Публичный путь для asset-протокола (для показа медиа из локальной папки).
#[tauri::command]
pub fn allow_media_scope(app: AppHandle) -> Result<(), String> {
    let dir = media_dir(&app);
    app.asset_protocol_scope()
        .allow_directory(&dir, true)
        .map_err(|e| e.to_string())
}

pub fn scope_for_workspace(app: &AppHandle, workspace: &str) {
    if workspace.trim().is_empty() {
        return;
    }
    let _ = app
        .asset_protocol_scope()
        .allow_directory(Path::new(workspace), true);
}
