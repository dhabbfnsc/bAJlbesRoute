//! bAJlbesRoute — точка входа Tauri-приложения.
mod chat;
mod imagine;
mod system;
mod tools;
mod util;

use tauri::Manager;

#[cfg_attr(any(target_os = "android", target_os = "ios"), tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri::Builder::default();

    // single-instance обязан регистрироваться первым
    #[cfg(not(any(target_os = "android", target_os = "ios")))]
    let builder = builder.plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
        if let Some(window) = app.get_webview_window("main") {
            let _ = window.show();
            let _ = window.set_focus();
        }
    }));

    let builder = builder
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_notification::init());

    #[cfg(any(target_os = "android", target_os = "ios"))]
    let builder = builder.plugin(tauri_plugin_haptics::init());

    builder
        .manage(system::Prefs::default())
        .manage(chat::ChatState::default())
        .manage(imagine::ImagineState::default())
        .invoke_handler(tauri::generate_handler![
            system::boot_info,
            system::load_state,
            system::save_state,
            system::set_close_to_tray,
            system::notify,
            system::hide_window,
            system::show_window,
            system::app_quit,
            system::reveal_path,
            system::read_attachment,
            system::list_models,
            system::test_provider,
            system::workspace_overview,
            chat::start_chat,
            chat::stop_chat,
            chat::get_chat_snapshot,
            chat::drop_chat_snapshot,
            imagine::imagine_generate,
            imagine::imagine_cancel,
            imagine::media_delete,
            imagine::media_copy,
            imagine::media_dir_path,
            imagine::allow_media_scope,
        ])
        .setup(|app| {
            #[cfg(not(any(target_os = "android", target_os = "ios")))]
            {
                if let Err(err) = setup_tray(app) {
                    eprintln!("tray init failed: {err}");
                }
            }
            if let Ok(dir) = app.path().app_local_data_dir() {
                let _ = std::fs::create_dir_all(dir.join("media"));
            }
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                let app = window.app_handle();
                let keep_running = app
                    .try_state::<system::Prefs>()
                    .map(|prefs| {
                        prefs
                            .close_to_tray
                            .load(std::sync::atomic::Ordering::Relaxed)
                    })
                    .unwrap_or(false);
                if keep_running && cfg!(not(any(target_os = "android", target_os = "ios"))) {
                    api.prevent_close();
                    let _ = window.hide();
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running bAJlbesRoute");
}

#[cfg(not(any(target_os = "android", target_os = "ios")))]
fn setup_tray(app: &tauri::App) -> tauri::Result<()> {
    use tauri::menu::{Menu, MenuItem};
    use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};

    let show = MenuItem::with_id(app, "show", "Открыть bAJlbesRoute", true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", "Выход", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&show, &quit])?;

    let mut builder = TrayIconBuilder::with_id("main-tray")
        .tooltip("bAJlbesRoute — ваш AI-маршрут")
        .menu(&menu)
        .show_menu_on_left_click(false)
        .on_menu_event(|app, event| match event.id.as_ref() {
            "show" => {
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
            "quit" => app.exit(0),
            _ => {}
        })
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                let app = tray.app_handle();
                if let Some(window) = app.get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
        });

    if let Some(icon) = app.default_window_icon() {
        builder = builder.icon(icon.clone());
    }
    builder.build(app)?;
    Ok(())
}
