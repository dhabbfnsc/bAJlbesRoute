//! Ядро чата: стриминг от OpenAI-совместимых провайдеров и Anthropic,
//! цикл вызова инструментов, отмена, снимки состояния для фонового режима.
use std::collections::{BTreeMap, HashMap};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tauri::{AppHandle, Emitter, Manager, State};
use tokio_util::sync::CancellationToken;

use crate::tools;
use crate::util::{self, SseBuffer};

const CANCELLED: &str = "__cancelled__";
const MAX_TOOL_ROUNDS: usize = 6;
const TOOL_RESULT_LIMIT: usize = 24_000;

// ---------------------------------------------------------------------------
// Состояние
// ---------------------------------------------------------------------------

#[derive(Default)]
pub struct ChatState {
    pub runs: Mutex<HashMap<String, Arc<Run>>>,
}

pub struct Run {
    pub cancel: CancellationToken,
    pub snap: Mutex<Snapshot>,
}

#[derive(Clone, Serialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct Snapshot {
    pub request_id: String,
    pub chat_id: String,
    pub text: String,
    pub reasoning: String,
    pub status: String,
    pub error: Option<String>,
    pub tools: Vec<ToolTrace>,
    pub usage: Option<Usage>,
    pub finished: bool,
    pub started_at: i64,
    pub updated_at: i64,
}

#[derive(Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct Usage {
    pub prompt_tokens: Option<u64>,
    pub completion_tokens: Option<u64>,
    pub total_tokens: Option<u64>,
}

#[derive(Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct ToolTrace {
    pub id: String,
    pub name: String,
    pub args: String,
    pub result: Option<String>,
    pub ok: Option<bool>,
    pub status: String,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatRequest {
    pub request_id: String,
    pub chat_id: String,
    pub provider: ProviderReq,
    pub model: String,
    #[serde(default)]
    pub system: String,
    #[serde(default)]
    pub messages: Vec<ApiMsg>,
    #[serde(default)]
    pub temperature: Option<f32>,
    #[serde(default)]
    pub max_tokens: Option<u32>,
    #[serde(default)]
    pub effort: Option<String>,
    #[serde(default)]
    pub tools: Option<ToolsReq>,
    #[serde(default)]
    pub notify: Option<NotifyReq>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderReq {
    pub kind: String,
    pub base_url: String,
    #[serde(default)]
    pub api_key: String,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ApiMsg {
    pub role: String,
    #[serde(default)]
    pub text: String,
    #[serde(default)]
    pub images: Vec<String>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolsReq {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default)]
    pub root: Option<String>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NotifyReq {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default)]
    pub title: String,
}

// ---------------------------------------------------------------------------
// События
// ---------------------------------------------------------------------------

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase", tag = "type")]
pub enum ChatEvent {
    Status { status: String },
    Delta { text: String },
    Reasoning { text: String },
    Tool { id: String, name: String, args: String },
    ToolResult { id: String, ok: bool, result: String },
    Usage { usage: Usage },
    Done {
        text: String,
        reasoning: String,
        usage: Option<Usage>,
        finish: String,
    },
    Stopped {
        text: String,
        reasoning: String,
    },
    Error { message: String },
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatEnvelope {
    pub request_id: String,
    pub chat_id: String,
    pub event: ChatEvent,
}

// ---------------------------------------------------------------------------
// Внутренние структуры
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq)]
enum Kind {
    OpenAi,
    Anthropic,
}

impl Kind {
    fn from_str(s: &str) -> Kind {
        if s.eq_ignore_ascii_case("anthropic") {
            Kind::Anthropic
        } else {
            Kind::OpenAi
        }
    }
}

#[derive(Default, Clone)]
struct Turn {
    text: String,
    reasoning: String,
    finish: String,
    tool_calls: Vec<ToolCallReq>,
    raw_tool_calls: Vec<Value>,
    blocks: Vec<Value>,
    usage: Option<Usage>,
}

#[derive(Default, Clone)]
struct ToolCallReq {
    id: String,
    name: String,
    args: String,
}

struct Ctx<'a> {
    app: &'a AppHandle,
    req: &'a ChatRequest,
    run: &'a Run,
    http: reqwest::Client,
}

impl<'a> Ctx<'a> {
    fn emit(&self, event: ChatEvent) {
        let _ = self.app.emit(
            "chat:event",
            ChatEnvelope {
                request_id: self.req.request_id.clone(),
                chat_id: self.req.chat_id.clone(),
                event,
            },
        );
    }

    fn status(&self, status: &str) {
        if let Ok(mut s) = self.run.snap.lock() {
            s.status = status.to_string();
            s.updated_at = util::now_ms();
        }
        self.emit(ChatEvent::Status {
            status: status.to_string(),
        });
    }

    fn delta(&self, text: &str) {
        if text.is_empty() {
            return;
        }
        if let Ok(mut s) = self.run.snap.lock() {
            s.text.push_str(text);
            s.updated_at = util::now_ms();
        }
        self.emit(ChatEvent::Delta {
            text: text.to_string(),
        });
    }

    fn reasoning(&self, text: &str) {
        if text.is_empty() {
            return;
        }
        if let Ok(mut s) = self.run.snap.lock() {
            s.reasoning.push_str(text);
            s.updated_at = util::now_ms();
        }
        self.emit(ChatEvent::Reasoning {
            text: text.to_string(),
        });
    }

    fn set_usage(&self, usage: Usage) {
        if let Ok(mut s) = self.run.snap.lock() {
            s.usage = Some(usage.clone());
        }
        self.emit(ChatEvent::Usage { usage });
    }

    fn tool_start(&self, id: &str, name: &str, args: &str) {
        if let Ok(mut s) = self.run.snap.lock() {
            s.tools.push(ToolTrace {
                id: id.to_string(),
                name: name.to_string(),
                args: util::truncate_chars(args, 400),
                result: None,
                ok: None,
                status: "running".to_string(),
            });
        }
        self.emit(ChatEvent::Tool {
            id: id.to_string(),
            name: name.to_string(),
            args: args.to_string(),
        });
    }

    fn tool_result(&self, id: &str, ok: bool, result: &str) {
        if let Ok(mut s) = self.run.snap.lock() {
            if let Some(trace) = s.tools.iter_mut().rev().find(|t| t.id == id) {
                trace.ok = Some(ok);
                trace.status = if ok { "ok" } else { "error" }.to_string();
                trace.result = Some(util::truncate_chars(result, 2000));
            }
        }
        self.emit(ChatEvent::ToolResult {
            id: id.to_string(),
            ok,
            result: util::truncate_chars(result, 2000),
        });
    }

    fn check_cancel(&self) -> Result<(), String> {
        if self.run.cancel.is_cancelled() {
            Err(CANCELLED.to_string())
        } else {
            Ok(())
        }
    }
}

// ---------------------------------------------------------------------------
// Команды
// ---------------------------------------------------------------------------

#[tauri::command]
pub async fn start_chat(
    app: AppHandle,
    state: State<'_, ChatState>,
    req: ChatRequest,
) -> Result<(), String> {
    if req.request_id.trim().is_empty() {
        return Err("Пустой requestId".to_string());
    }
    if req.provider.base_url.trim().is_empty() {
        return Err("Не задан Base URL провайдера".to_string());
    }
    let now = util::now_ms();
    let run = Arc::new(Run {
        cancel: CancellationToken::new(),
        snap: Mutex::new(Snapshot {
            request_id: req.request_id.clone(),
            chat_id: req.chat_id.clone(),
            status: "starting".to_string(),
            started_at: now,
            updated_at: now,
            ..Default::default()
        }),
    });
    {
        let mut runs = state.runs.lock().map_err(|e| e.to_string())?;
        let stale: Vec<String> = runs
            .iter()
            .filter(|(_, r)| {
                let s = r.snap.lock().ok().map(|s| s.finished && s.updated_at < now - 15 * 60 * 1000).unwrap_or(false);
                s
            })
            .map(|(k, _)| k.clone())
            .collect();
        for key in stale {
            runs.remove(&key);
        }
        runs.insert(req.request_id.clone(), run.clone());
    }

    let app2 = app.clone();
    let req2 = req.clone();
    tauri::async_runtime::spawn(async move {
        let result = run_chat(&app2, &req2, &run).await;
        let ctx = Ctx {
            app: &app2,
            req: &req2,
            run: &run,
            http: util::client(),
        };
        match result {
            Ok(finish) => {
                let (text, reasoning, usage) = {
                    let mut s = match run.snap.lock() {
                        Ok(s) => s,
                        Err(_) => return,
                    };
                    s.finished = true;
                    s.status = "done".to_string();
                    s.updated_at = util::now_ms();
                    (s.text.clone(), s.reasoning.clone(), s.usage.clone())
                };
                ctx.emit(ChatEvent::Done {
                    text,
                    reasoning,
                    usage,
                    finish,
                });
                notify_done(&app2, &req2, &run);
            }
            Err(err) if err == CANCELLED => {
                let (text, reasoning) = {
                    let mut s = match run.snap.lock() {
                        Ok(s) => s,
                        Err(_) => return,
                    };
                    s.finished = true;
                    s.status = "stopped".to_string();
                    s.updated_at = util::now_ms();
                    (s.text.clone(), s.reasoning.clone())
                };
                ctx.emit(ChatEvent::Stopped { text, reasoning });
            }
            Err(err) => {
                if let Ok(mut s) = run.snap.lock() {
                    s.finished = true;
                    s.status = "error".to_string();
                    s.error = Some(err.clone());
                    s.updated_at = util::now_ms();
                }
                ctx.emit(ChatEvent::Error { message: err });
            }
        }
    });
    Ok(())
}

#[tauri::command]
pub fn stop_chat(state: State<'_, ChatState>, request_id: String) {
    if let Ok(runs) = state.runs.lock() {
        if let Some(run) = runs.get(&request_id) {
            run.cancel.cancel();
        }
    }
}

#[tauri::command]
pub fn get_chat_snapshot(state: State<'_, ChatState>, request_id: String) -> Option<Snapshot> {
    let runs = state.runs.lock().ok()?;
    let run = runs.get(&request_id)?;
    run.snap.lock().ok().map(|s| s.clone())
}

#[tauri::command]
pub fn drop_chat_snapshot(state: State<'_, ChatState>, request_id: String) {
    if let Ok(mut runs) = state.runs.lock() {
        runs.remove(&request_id);
    }
}

fn notify_done(app: &AppHandle, req: &ChatRequest, run: &Arc<Run>) {
    let Some(cfg) = req.notify.as_ref() else { return };
    if !cfg.enabled {
        return;
    }
    let focused = app
        .get_webview_window("main")
        .and_then(|w| w.is_focused().ok())
        .unwrap_or(false);
    if focused {
        return;
    }
    let text = run
        .snap
        .lock()
        .map(|s| s.text.clone())
        .unwrap_or_default();
    if text.trim().is_empty() {
        return;
    }
    let title = if cfg.title.trim().is_empty() {
        "bAJlbesRoute".to_string()
    } else {
        cfg.title.clone()
    };
    let body = util::truncate_chars(text.trim(), 220);
    use tauri_plugin_notification::NotificationExt;
    let _ = app
        .notification()
        .builder()
        .title(title)
        .body(body)
        .show();
}

// ---------------------------------------------------------------------------
// Основной цикл
// ---------------------------------------------------------------------------

async fn run_chat(app: &AppHandle, req: &ChatRequest, run: &Arc<Run>) -> Result<String, String> {
    let ctx = Ctx {
        app,
        req,
        run,
        http: util::client(),
    };
    let kind = Kind::from_str(&req.provider.kind);
    let root = req
        .tools
        .as_ref()
        .filter(|t| t.enabled)
        .and_then(|t| t.root.clone())
        .map(PathBuf::from)
        .filter(|p| p.is_dir());
    if req.tools.as_ref().map(|t| t.enabled).unwrap_or(false) && root.is_none() {
        ctx.status("no_workspace");
    }

    let mut messages = match kind {
        Kind::OpenAi => openai_messages(req),
        Kind::Anthropic => anthropic_messages(req),
    };
    let rounds = if root.is_some() { MAX_TOOL_ROUNDS } else { 1 };

    for round in 0..rounds {
        ctx.check_cancel()?;
        ctx.status(if round == 0 { "thinking" } else { "tools" });
        let turn = match kind {
            Kind::OpenAi => stream_openai(&ctx, &messages, root.as_deref()).await?,
            Kind::Anthropic => stream_anthropic(&ctx, &messages, root.as_deref()).await?,
        };
        if let Some(usage) = turn.usage.clone() {
            ctx.set_usage(usage);
        }
        let no_tools = turn.tool_calls.is_empty() || root.is_none();
        if no_tools {
            if turn.text.trim().is_empty() {
                return Err("Модель вернула пустой ответ. Проверьте имя модели и параметры.".to_string());
            }
            return Ok(if turn.finish.is_empty() {
                "stop".to_string()
            } else {
                turn.finish
            });
        }
        let root_dir = match root.clone() {
            Some(r) => r,
            None => break,
        };
        match kind {
            Kind::OpenAi => {
                let content = if turn.text.is_empty() {
                    Value::Null
                } else {
                    json!(turn.text)
                };
                messages.push(json!({
                    "role": "assistant",
                    "content": content,
                    "tool_calls": turn.raw_tool_calls,
                }));
                for call in &turn.tool_calls {
                    let result = run_tool(&ctx, &root_dir, call).await;
                    messages.push(json!({
                        "role": "tool",
                        "tool_call_id": call.id,
                        "content": result,
                    }));
                }
            }
            Kind::Anthropic => {
                let mut blocks = turn.blocks.clone();
                if blocks.is_empty() && !turn.text.is_empty() {
                    blocks.push(json!({ "type": "text", "text": turn.text }));
                }
                messages.push(json!({ "role": "assistant", "content": blocks }));
                let mut results = Vec::new();
                for call in &turn.tool_calls {
                    let result = run_tool(&ctx, &root_dir, call).await;
                    results.push(json!({
                        "type": "tool_result",
                        "tool_use_id": call.id,
                        "content": result,
                    }));
                }
                messages.push(json!({ "role": "user", "content": results }));
            }
        }
    }
    Ok("tools_done".to_string())
}

async fn run_tool(ctx: &Ctx<'_>, root: &PathBuf, call: &ToolCallReq) -> String {
    ctx.tool_start(&call.id, &call.name, &call.args);
    let parsed: Value = serde_json::from_str(&call.args).unwrap_or_else(|_| json!({}));
    let root_owned = root.clone();
    let name = call.name.clone();
    let outcome = tokio::task::spawn_blocking(move || tools::execute(&root_owned, &name, &parsed))
        .await
        .unwrap_or_else(|e| (false, format!("Инструмент завершился ошибкой: {e}")));
    let (ok, text) = outcome;
    ctx.tool_result(&call.id, ok, &text);
    let payload = if ok {
        text
    } else {
        format!("Ошибка инструмента: {text}")
    };
    util::truncate_chars(&payload, TOOL_RESULT_LIMIT)
}

// ---------------------------------------------------------------------------
// Подготовка сообщений
// ---------------------------------------------------------------------------

fn openai_messages(req: &ChatRequest) -> Vec<Value> {
    let mut out = Vec::new();
    if !req.system.trim().is_empty() {
        out.push(json!({ "role": "system", "content": req.system }));
    }
    for m in &req.messages {
        let role = match m.role.as_str() {
            "assistant" => "assistant",
            "system" => "system",
            _ => "user",
        };
        if role == "assistant" && m.text.trim().is_empty() {
            continue;
        }
        if m.images.is_empty() {
            out.push(json!({ "role": role, "content": m.text }));
        } else {
            let mut parts = Vec::new();
            if !m.text.is_empty() {
                parts.push(json!({ "type": "text", "text": m.text }));
            }
            for img in &m.images {
                parts.push(json!({ "type": "image_url", "image_url": { "url": img } }));
            }
            out.push(json!({ "role": role, "content": parts }));
        }
    }
    out
}

fn anthropic_messages(req: &ChatRequest) -> Vec<Value> {
    let mut out = Vec::new();
    for m in &req.messages {
        let role = match m.role.as_str() {
            "assistant" => "assistant",
            _ => "user",
        };
        if role == "assistant" && m.text.trim().is_empty() {
            continue;
        }
        if m.images.is_empty() {
            out.push(json!({ "role": role, "content": m.text }));
        } else {
            let mut parts = Vec::new();
            for img in &m.images {
                if let Some((mime, bytes)) = util::parse_data_url(img) {
                    parts.push(json!({
                        "type": "image",
                        "source": { "type": "base64", "media_type": mime, "data": util::b64_encode(&bytes) }
                    }));
                } else if img.starts_with("http") {
                    parts.push(json!({
                        "type": "image",
                        "source": { "type": "url", "url": img }
                    }));
                }
            }
            if !m.text.is_empty() {
                parts.push(json!({ "type": "text", "text": m.text }));
            }
            out.push(json!({ "role": role, "content": parts }));
        }
    }
    out
}

fn effort_budget(effort: &str) -> u32 {
    match effort.to_lowercase().as_str() {
        "low" | "minimal" => 1024,
        "medium" => 4096,
        "high" => 8192,
        _ => 0,
    }
}

fn is_reasoning_model(model: &str) -> bool {
    let m = model.to_lowercase();
    m.starts_with("o1")
        || m.starts_with("o3")
        || m.starts_with("o4")
        || m.contains("gpt-5")
        || m.contains("reasoner")
        || m.contains("thinking")
        || m.contains("deepseek-r")
        || m.contains("grok-4")
}

fn auth_openai(ctx: &Ctx<'_>, rb: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
    let mut rb = rb;
    if !ctx.req.provider.api_key.trim().is_empty() {
        rb = rb.bearer_auth(ctx.req.provider.api_key.trim());
    }
    for (k, v) in &ctx.req.provider.headers {
        rb = rb.header(k.as_str(), v.as_str());
    }
    if ctx.req.provider.base_url.contains("openrouter.ai") {
        rb = rb
            .header("HTTP-Referer", "https://bajlbesroute.app")
            .header("X-Title", "bAJlbesRoute");
    }
    rb
}

// ---------------------------------------------------------------------------
// OpenAI-совместимый провайдер
// ---------------------------------------------------------------------------

fn openai_body(
    req: &ChatRequest,
    messages: &[Value],
    with_tools: bool,
    rich: bool,
) -> Value {
    let mut body = json!({
        "model": req.model,
        "messages": messages,
        "stream": true,
    });
    let effort = req
        .effort
        .clone()
        .unwrap_or_default()
        .to_lowercase();
    let reasoning_on = !effort.is_empty() && effort != "off" && effort != "auto";
    if rich {
        body["stream_options"] = json!({ "include_usage": true });
        if let Some(t) = req.temperature {
            if !reasoning_on {
                body["temperature"] = json!(t);
            }
        }
        if let Some(mt) = req.max_tokens {
            if is_reasoning_model(&req.model) {
                body["max_completion_tokens"] = json!(mt);
            } else {
                body["max_tokens"] = json!(mt);
            }
        }
        if reasoning_on {
            body["reasoning_effort"] = json!(effort);
            if req.provider.base_url.contains("openrouter.ai") {
                body["reasoning"] = json!({ "effort": effort });
            }
        }
    }
    if with_tools {
        body["tools"] = json!(tools::tool_definitions());
        body["tool_choice"] = json!("auto");
    }
    body
}

async fn stream_openai(
    ctx: &Ctx<'_>,
    messages: &[Value],
    root: Option<&std::path::Path>,
) -> Result<Turn, String> {
    let url = util::join_url(&ctx.req.provider.base_url, "chat/completions");
    let mut rich = true;
    loop {
        ctx.check_cancel()?;
        let body = openai_body(ctx.req, messages, root.is_some(), rich);
        let rb = ctx
            .http
            .post(&url)
            .header("content-type", "application/json")
            .header("accept", "text/event-stream");
        let rb = auth_openai(ctx, rb);
        let resp = rb
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("Сетевая ошибка: {e}"))?;
        let status = resp.status();
        if !status.is_success() {
            let code = status.as_u16();
            let text = resp.text().await.unwrap_or_default();
            if code == 400 && rich {
                rich = false;
                continue;
            }
            return Err(util::friendly_status(code, &text));
        }
        let is_stream = resp
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .map(|v| v.contains("event-stream"))
            .unwrap_or(false);
        if !is_stream {
            let text = resp.text().await.map_err(|e| format!("Ошибка чтения ответа: {e}"))?;
            return parse_openai_json(ctx, &text);
        }
        return parse_openai_stream(ctx, resp).await;
    }
}

async fn parse_openai_stream(ctx: &Ctx<'_>, resp: reqwest::Response) -> Result<Turn, String> {
    let mut turn = Turn::default();
    let mut sse = SseBuffer::default();
    let mut tool_calls: BTreeMap<u64, (String, String, String)> = BTreeMap::new();
    let mut stream = resp.bytes_stream();
    loop {
        let chunk = tokio::select! {
            _ = ctx.run.cancel.cancelled() => return Err(CANCELLED.to_string()),
            next = stream.next() => next,
        };
        let Some(chunk) = chunk else { break };
        let bytes = chunk.map_err(|e| format!("Обрыв потока: {e}"))?;
        for event in sse.push(&bytes) {
            handle_openai_event(ctx, &mut turn, &mut tool_calls, &event.data)?;
        }
    }
    if let Some(event) = sse.flush() {
        handle_openai_event(ctx, &mut turn, &mut tool_calls, &event.data)?;
    }
    for (idx, (id, name, args)) in tool_calls {
        turn.tool_calls.push(ToolCallReq {
            id: if id.is_empty() {
                format!("call_{idx}")
            } else {
                id.clone()
            },
            name: name.clone(),
            args: if args.trim().is_empty() {
                "{}".to_string()
            } else {
                args.clone()
            },
        });
        turn.raw_tool_calls.push(json!({
            "id": if id.is_empty() { format!("call_{idx}") } else { id },
            "type": "function",
            "function": { "name": name, "arguments": if args.trim().is_empty() { "{}".to_string() } else { args } }
        }));
    }
    Ok(turn)
}

fn handle_openai_event(
    ctx: &Ctx<'_>,
    turn: &mut Turn,
    tool_calls: &mut BTreeMap<u64, (String, String, String)>,
    data: &str,
) -> Result<(), String> {
    let data = data.trim();
    if data.is_empty() || data == "[DONE]" {
        return Ok(());
    }
    let value: Value = match serde_json::from_str(data) {
        Ok(v) => v,
        Err(_) => return Ok(()),
    };
    if value.get("error").is_some() {
        return Err(extract_error(&value));
    }
    if let Some(usage) = value.get("usage") {
        if usage.is_object() {
            turn.usage = Some(parse_usage(usage));
        }
    }
    let choices = match value.get("choices").and_then(|c| c.as_array()) {
        Some(c) => c,
        None => return Ok(()),
    };
    let Some(choice) = choices.first() else {
        return Ok(());
    };
    if let Some(finish) = choice.get("finish_reason").and_then(|f| f.as_str()) {
        turn.finish = finish.to_string();
    }
    let delta = choice
        .get("delta")
        .cloned()
        .or_else(|| choice.get("message").cloned())
        .unwrap_or(Value::Null);

    if let Some(content) = delta.get("content") {
        match content {
            Value::String(s) => {
                turn.text.push_str(s);
                ctx.delta(s);
            }
            Value::Array(parts) => {
                for part in parts {
                    if let Some(t) = part.get("text").and_then(|v| v.as_str()) {
                        turn.text.push_str(t);
                        ctx.delta(t);
                    }
                }
            }
            _ => {}
        }
    }
    for key in ["reasoning_content", "reasoning", "thinking"] {
        if let Some(reasoning) = delta.get(key) {
            let text = match reasoning {
                Value::String(s) => s.clone(),
                Value::Object(_) => reasoning
                    .get("content")
                    .and_then(|v| v.as_str())
                    .unwrap_or_default()
                    .to_string(),
                _ => String::new(),
            };
            if !text.is_empty() {
                turn.reasoning.push_str(&text);
                ctx.reasoning(&text);
            }
        }
    }
    if let Some(calls) = delta.get("tool_calls").and_then(|v| v.as_array()) {
        for call in calls {
            let idx = call.get("index").and_then(|v| v.as_u64()).unwrap_or(0);
            let entry = tool_calls.entry(idx).or_default();
            if let Some(id) = call.get("id").and_then(|v| v.as_str()) {
                if !id.is_empty() {
                    entry.0 = id.to_string();
                }
            }
            if let Some(func) = call.get("function") {
                if let Some(name) = func.get("name").and_then(|v| v.as_str()) {
                    if !name.is_empty() {
                        entry.1 = name.to_string();
                    }
                }
                if let Some(args) = func.get("arguments").and_then(|v| v.as_str()) {
                    entry.2.push_str(args);
                }
            }
        }
    }
    Ok(())
}

fn parse_openai_json(ctx: &Ctx<'_>, raw: &str) -> Result<Turn, String> {
    let value: Value = serde_json::from_str(raw).map_err(|e| format!("Некорректный JSON: {e}"))?;
    if value.get("error").is_some() {
        return Err(extract_error(&value));
    }
    let mut turn = Turn::default();
    if let Some(usage) = value.get("usage") {
        turn.usage = Some(parse_usage(usage));
    }
    let Some(choice) = value
        .get("choices")
        .and_then(|c| c.as_array())
        .and_then(|c| c.first())
    else {
        return Err("Ответ без choices".to_string());
    };
    if let Some(finish) = choice.get("finish_reason").and_then(|f| f.as_str()) {
        turn.finish = finish.to_string();
    }
    let message = choice.get("message").cloned().unwrap_or(Value::Null);
    if let Some(content) = message.get("content") {
        match content {
            Value::String(s) => {
                turn.text = s.clone();
                ctx.delta(s);
            }
            Value::Array(parts) => {
                for part in parts {
                    if let Some(t) = part.get("text").and_then(|v| v.as_str()) {
                        turn.text.push_str(t);
                        ctx.delta(t);
                    }
                }
            }
            _ => {}
        }
    }
    for key in ["reasoning_content", "reasoning"] {
        if let Some(r) = message.get(key).and_then(|v| v.as_str()) {
            if !r.is_empty() {
                turn.reasoning.push_str(r);
                ctx.reasoning(r);
            }
        }
    }
    if let Some(calls) = message.get("tool_calls").and_then(|v| v.as_array()) {
        for call in calls {
            let id = call.get("id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let func = call.get("function").cloned().unwrap_or(Value::Null);
            let name = func.get("name").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let args = func
                .get("arguments")
                .and_then(|v| v.as_str())
                .unwrap_or("{}")
                .to_string();
            let id = if id.is_empty() { format!("call_{}", turn.tool_calls.len()) } else { id };
            turn.tool_calls.push(ToolCallReq {
                id: id.clone(),
                name: name.clone(),
                args: args.clone(),
            });
            turn.raw_tool_calls.push(json!({
                "id": id,
                "type": "function",
                "function": { "name": name, "arguments": args }
            }));
        }
    }
    Ok(turn)
}

// ---------------------------------------------------------------------------
// Anthropic
// ---------------------------------------------------------------------------

fn anthropic_body(
    req: &ChatRequest,
    messages: &[Value],
    with_tools: bool,
) -> Value {
    let effort = req.effort.clone().unwrap_or_default().to_lowercase();
    let budget = effort_budget(&effort);
    let thinking_on = budget > 0;
    let mut max_tokens = req.max_tokens.unwrap_or(if thinking_on { budget + 4096 } else { 8192 });
    if thinking_on && max_tokens <= budget + 512 {
        max_tokens = budget + 4096;
    }
    let mut body = json!({
        "model": req.model,
        "messages": messages,
        "stream": true,
        "max_tokens": max_tokens,
    });
    if !req.system.trim().is_empty() {
        body["system"] = json!(req.system);
    }
    if thinking_on {
        body["thinking"] = json!({ "type": "enabled", "budget_tokens": budget });
    } else if let Some(t) = req.temperature {
        body["temperature"] = json!(t.clamp(0.0, 1.0));
    }
    if with_tools {
        let defs: Vec<Value> = tools::tool_definitions()
            .into_iter()
            .filter_map(|d| {
                let f = d.get("function")?;
                Some(json!({
                    "name": f.get("name")?,
                    "description": f.get("description")?,
                    "input_schema": f.get("parameters")?,
                }))
            })
            .collect();
        body["tools"] = json!(defs);
    }
    body
}

async fn stream_anthropic(
    ctx: &Ctx<'_>,
    messages: &[Value],
    root: Option<&std::path::Path>,
) -> Result<Turn, String> {
    let url = util::join_url(&ctx.req.provider.base_url, "messages");
    let body = anthropic_body(ctx.req, messages, root.is_some());
    let mut rb = ctx
        .http
        .post(&url)
        .header("content-type", "application/json")
        .header("accept", "text/event-stream")
        .header("anthropic-version", "2023-06-01");
    if !ctx.req.provider.api_key.trim().is_empty() {
        rb = rb.header("x-api-key", ctx.req.provider.api_key.trim());
    }
    for (k, v) in &ctx.req.provider.headers {
        rb = rb.header(k.as_str(), v.as_str());
    }
    let resp = rb
        .json(&body)
        .send()
        .await
        .map_err(|e| format!("Сетевая ошибка: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let code = status.as_u16();
        let text = resp.text().await.unwrap_or_default();
        return Err(util::friendly_status(code, &text));
    }
    let is_stream = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .map(|v| v.contains("event-stream"))
        .unwrap_or(false);
    if !is_stream {
        let raw = resp.text().await.map_err(|e| e.to_string())?;
        return parse_anthropic_json(ctx, &raw);
    }

    let mut turn = Turn::default();
    let mut sse = SseBuffer::default();
    let mut blocks: BTreeMap<u64, BlockAcc> = BTreeMap::new();
    let mut stream = resp.bytes_stream();
    loop {
        let chunk = tokio::select! {
            _ = ctx.run.cancel.cancelled() => return Err(CANCELLED.to_string()),
            next = stream.next() => next,
        };
        let Some(chunk) = chunk else { break };
        let bytes = chunk.map_err(|e| format!("Обрыв потока: {e}"))?;
        for event in sse.push(&bytes) {
            handle_anthropic_event(ctx, &mut turn, &mut blocks, &event.event, &event.data)?;
        }
    }
    if let Some(event) = sse.flush() {
        handle_anthropic_event(ctx, &mut turn, &mut blocks, &event.event, &event.data)?;
    }
    finalize_open_blocks(&mut turn, &mut blocks);
    Ok(turn)
}

#[derive(Default, Clone)]
struct BlockAcc {
    kind: String,
    id: String,
    name: String,
    json: String,
    text: String,
    thinking: String,
    signature: String,
    pushed: bool,
}

fn handle_anthropic_event(
    ctx: &Ctx<'_>,
    turn: &mut Turn,
    blocks: &mut BTreeMap<u64, BlockAcc>,
    event: &Option<String>,
    data: &str,
) -> Result<(), String> {
    if data.trim().is_empty() {
        return Ok(());
    }
    let value: Value = match serde_json::from_str(data) {
        Ok(v) => v,
        Err(_) => return Ok(()),
    };
    let kind = value
        .get("type")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .or_else(|| event.clone())
        .unwrap_or_default();
    match kind.as_str() {
        "error" => {
            let msg = value
                .get("error")
                .and_then(|e| e.get("message"))
                .and_then(|m| m.as_str())
                .unwrap_or("Неизвестная ошибка Anthropic");
            return Err(msg.to_string());
        }
        "message_start" => {
            if let Some(u) = value
                .get("message")
                .and_then(|m| m.get("usage"))
            {
                turn.usage = Some(parse_usage(u));
                ctx.set_usage(turn.usage.clone().unwrap_or_default());
            }
        }
        "content_block_start" => {
            let idx = value.get("index").and_then(|v| v.as_u64()).unwrap_or(0);
            let block = value.get("content_block").cloned().unwrap_or(Value::Null);
            let mut acc = BlockAcc {
                kind: block
                    .get("type")
                    .and_then(|v| v.as_str())
                    .unwrap_or("text")
                    .to_string(),
                ..Default::default()
            };
            if acc.kind == "tool_use" {
                acc.id = block.get("id").and_then(|v| v.as_str()).unwrap_or("").to_string();
                acc.name = block.get("name").and_then(|v| v.as_str()).unwrap_or("").to_string();
                if let Some(input) = block.get("input") {
                    if !input.is_null() && input.as_object().map(|o| !o.is_empty()).unwrap_or(false) {
                        acc.json = input.to_string();
                    }
                }
            } else if acc.kind == "text" {
                if let Some(t) = block.get("text").and_then(|v| v.as_str()) {
                    acc.text.push_str(t);
                    ctx.delta(t);
                }
            }
            blocks.insert(idx, acc);
        }
        "content_block_delta" => {
            let idx = value.get("index").and_then(|v| v.as_u64()).unwrap_or(0);
            let delta = value.get("delta").cloned().unwrap_or(Value::Null);
            let delta_type = delta.get("type").and_then(|v| v.as_str()).unwrap_or("");
            let acc = blocks.entry(idx).or_default();
            match delta_type {
                "text_delta" => {
                    if let Some(t) = delta.get("text").and_then(|v| v.as_str()) {
                        acc.text.push_str(t);
                        turn.text.push_str(t);
                        ctx.delta(t);
                    }
                }
                "thinking_delta" => {
                    if let Some(t) = delta.get("thinking").and_then(|v| v.as_str()) {
                        acc.thinking.push_str(t);
                        turn.reasoning.push_str(t);
                        ctx.reasoning(t);
                    }
                }
                "signature_delta" => {
                    if let Some(s) = delta.get("signature").and_then(|v| v.as_str()) {
                        acc.signature.push_str(s);
                    }
                }
                "input_json_delta" => {
                    if let Some(p) = delta.get("partial_json").and_then(|v| v.as_str()) {
                        acc.json.push_str(p);
                    }
                }
                _ => {}
            }
        }
        "message_delta" => {
            if let Some(finish) = value
                .get("delta")
                .and_then(|d| d.get("stop_reason"))
                .and_then(|v| v.as_str())
            {
                turn.finish = finish.to_string();
            }
            if let Some(u) = value.get("usage") {
                let mut merged = turn.usage.clone().unwrap_or_default();
                let extra = parse_usage(u);
                if extra.prompt_tokens.is_some() {
                    merged.prompt_tokens = extra.prompt_tokens;
                }
                if extra.completion_tokens.is_some() {
                    merged.completion_tokens = extra.completion_tokens;
                }
                merged.total_tokens = match (merged.prompt_tokens, merged.completion_tokens) {
                    (Some(a), Some(b)) => Some(a + b),
                    (a, None) => a,
                    (None, b) => b,
                };
                turn.usage = Some(merged.clone());
                ctx.set_usage(merged);
            }
        }
        "content_block_stop" => {
            let idx = value.get("index").and_then(|v| v.as_u64()).unwrap_or(0);
            if let Some(acc) = blocks.get(&idx) {
                let acc = acc.clone();
                push_block(turn, &acc);
            }
            if let Some(acc) = blocks.get_mut(&idx) {
                acc.pushed = true;
            }
        }
        _ => {}
    }
    Ok(())
}

fn push_block(turn: &mut Turn, acc: &BlockAcc) {
    match acc.kind.as_str() {
        "tool_use" => {
            let args = if acc.json.trim().is_empty() {
                "{}".to_string()
            } else {
                acc.json.clone()
            };
            turn.tool_calls.push(ToolCallReq {
                id: acc.id.clone(),
                name: acc.name.clone(),
                args: args.clone(),
            });
            let parsed: Value = serde_json::from_str(&args).unwrap_or_else(|_| json!({}));
            turn.blocks.push(json!({
                "type": "tool_use",
                "id": acc.id,
                "name": acc.name,
                "input": parsed,
            }));
        }
        "text" => {
            turn.blocks
                .push(json!({ "type": "text", "text": acc.text }));
        }
        "thinking" => {
            let mut block = json!({ "type": "thinking", "thinking": acc.thinking });
            if !acc.signature.is_empty() {
                block["signature"] = json!(acc.signature);
            }
            turn.blocks.push(block);
        }
        _ => {}
    }
}

fn finalize_open_blocks(turn: &mut Turn, blocks: &mut BTreeMap<u64, BlockAcc>) {
    let pending: Vec<BlockAcc> = blocks
        .values()
        .filter(|acc| !acc.pushed)
        .cloned()
        .collect();
    for acc in pending {
        push_block(turn, &acc);
    }
    for acc in blocks.values_mut() {
        acc.pushed = true;
    }
}

fn parse_anthropic_json(ctx: &Ctx<'_>, raw: &str) -> Result<Turn, String> {
    let value: Value = serde_json::from_str(raw).map_err(|e| format!("Некорректный JSON: {e}"))?;
    if let Some(err) = value.get("error") {
        return Err(err
            .get("message")
            .and_then(|m| m.as_str())
            .unwrap_or("Ошибка Anthropic")
            .to_string());
    }
    let mut turn = Turn::default();
    if let Some(u) = value.get("usage") {
        turn.usage = Some(parse_usage(u));
    }
    if let Some(stop) = value.get("stop_reason").and_then(|v| v.as_str()) {
        turn.finish = stop.to_string();
    }
    if let Some(content) = value.get("content").and_then(|v| v.as_array()) {
        for block in content {
            match block.get("type").and_then(|v| v.as_str()).unwrap_or("") {
                "text" => {
                    if let Some(t) = block.get("text").and_then(|v| v.as_str()) {
                        turn.text.push_str(t);
                        ctx.delta(t);
                    }
                }
                "thinking" => {
                    if let Some(t) = block.get("thinking").and_then(|v| v.as_str()) {
                        turn.reasoning.push_str(t);
                        ctx.reasoning(t);
                    }
                }
                "tool_use" => {
                    let id = block.get("id").and_then(|v| v.as_str()).unwrap_or("").to_string();
                    let name = block.get("name").and_then(|v| v.as_str()).unwrap_or("").to_string();
                    let args = block
                        .get("input")
                        .map(|v| v.to_string())
                        .unwrap_or_else(|| "{}".to_string());
                    turn.tool_calls.push(ToolCallReq { id, name, args });
                }
                _ => {}
            }
            turn.blocks.push(block.clone());
        }
    }
    Ok(turn)
}

// ---------------------------------------------------------------------------
// Утилиты
// ---------------------------------------------------------------------------

fn parse_usage(value: &Value) -> Usage {
    let get = |keys: &[&str]| -> Option<u64> {
        for key in keys {
            if let Some(n) = value.get(*key).and_then(|v| v.as_u64()) {
                return Some(n);
            }
        }
        None
    };
    let prompt = get(&["prompt_tokens", "input_tokens"]);
    let completion = get(&["completion_tokens", "output_tokens"]);
    let total = get(&["total_tokens"]).or_else(|| match (prompt, completion) {
        (Some(a), Some(b)) => Some(a + b),
        (a, b) => a.or(b),
    });
    Usage {
        prompt_tokens: prompt,
        completion_tokens: completion,
        total_tokens: total,
    }
}

fn extract_error(value: &Value) -> String {
    let err = value.get("error").unwrap_or(value);
    if let Some(msg) = err.as_str() {
        return msg.to_string();
    }
    if let Some(msg) = err.get("message").and_then(|m| m.as_str()) {
        return msg.to_string();
    }
    if let Some(msg) = err
        .get("error")
        .and_then(|e| e.get("message"))
        .and_then(|m| m.as_str())
    {
        return msg.to_string();
    }
    util::truncate_chars(&err.to_string(), 500)
}
