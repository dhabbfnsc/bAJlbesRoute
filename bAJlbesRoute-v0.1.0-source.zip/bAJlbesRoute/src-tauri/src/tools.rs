//! Файловые инструменты, доступные модели. Все операции ограничены рабочей папкой.
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

const MAX_READ_BYTES: u64 = 300_000;
const MAX_LIST_ENTRIES: usize = 500;
const SKIP_DIRS: &[&str] = &[
    "node_modules", ".git", "target", "dist", "build", ".next", ".venv", "__pycache__",
    ".idea", ".vscode", ".cache", "vendor",
];

pub fn tool_definitions() -> Vec<Value> {
    vec![
        json!({
            "type": "function",
            "function": {
                "name": "list_dir",
                "description": "Показать содержимое папки в рабочем пространстве. Путь относительный, '.' — корень.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": { "type": "string", "description": "Относительный путь к папке" },
                        "depth": { "type": "integer", "description": "Глубина рекурсии, 1-3", "default": 1 }
                    }
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Прочитать текстовый файл из рабочего пространства.",
                "parameters": {
                    "type": "object",
                    "properties": { "path": { "type": "string", "description": "Относительный путь к файлу" } },
                    "required": ["path"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "write_file",
                "description": "Создать или полностью перезаписать файл. Родительские папки создаются автоматически.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": { "type": "string" },
                        "content": { "type": "string" }
                    },
                    "required": ["path", "content"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "append_file",
                "description": "Дописать текст в конец файла.",
                "parameters": {
                    "type": "object",
                    "properties": { "path": { "type": "string" }, "content": { "type": "string" } },
                    "required": ["path", "content"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "create_dir",
                "description": "Создать папку (включая вложенные).",
                "parameters": {
                    "type": "object",
                    "properties": { "path": { "type": "string" } },
                    "required": ["path"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "move_path",
                "description": "Переместить или переименовать файл/папку.",
                "parameters": {
                    "type": "object",
                    "properties": { "from": { "type": "string" }, "to": { "type": "string" } },
                    "required": ["from", "to"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "delete_path",
                "description": "Удалить файл или папку. Для папки укажите recursive=true.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": { "type": "string" },
                        "recursive": { "type": "boolean", "default": false }
                    },
                    "required": ["path"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "file_info",
                "description": "Метаданные файла или папки: размер, тип, дата изменения.",
                "parameters": {
                    "type": "object",
                    "properties": { "path": { "type": "string" } },
                    "required": ["path"]
                }
            }
        }),
        json!({
            "type": "function",
            "function": {
                "name": "search_files",
                "description": "Поиск по именам файлов и (опционально) по содержимому текстовых файлов.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": { "type": "string" },
                        "path": { "type": "string", "description": "Где искать, по умолчанию корень" },
                        "content": { "type": "boolean", "default": true, "description": "Искать внутри файлов" }
                    },
                    "required": ["query"]
                }
            }
        }),
    ]
}

fn resolve(root: &Path, rel: &str) -> Result<PathBuf, String> {
    let root_c = root
        .canonicalize()
        .map_err(|e| format!("Рабочая папка недоступна: {e}"))?;
    let rel = rel.trim();
    let candidate = if rel.is_empty() || rel == "." {
        root_c.clone()
    } else if Path::new(rel).is_absolute() {
        PathBuf::from(rel)
    } else {
        root_c.join(rel)
    };
    let checked = if candidate.exists() {
        candidate.canonicalize().unwrap_or(candidate.clone())
    } else {
        let parent = candidate.parent().unwrap_or(&root_c).to_path_buf();
        let parent_c = parent.canonicalize().unwrap_or(parent.clone());
        match candidate.file_name() {
            Some(name) => parent_c.join(name),
            None => parent_c,
        }
    };
    if !checked.starts_with(&root_c) {
        return Err("Путь вне рабочей папки запрещён".to_string());
    }
    Ok(checked)
}

fn rel_display(root: &Path, path: &Path) -> String {
    path.strip_prefix(root)
        .map(|p| p.to_string_lossy().replace('\\', "/"))
        .unwrap_or_else(|_| path.to_string_lossy().replace('\\', "/"))
}

fn human_size(bytes: u64) -> String {
    const KB: f64 = 1024.0;
    let b = bytes as f64;
    if b < KB {
        format!("{bytes} B")
    } else if b < KB * KB {
        format!("{:.1} KB", b / KB)
    } else if b < KB * KB * KB {
        format!("{:.1} MB", b / (KB * KB))
    } else {
        format!("{:.2} GB", b / (KB * KB * KB))
    }
}

fn listing(root: &Path, dir: &Path, depth: u32, out: &mut Vec<String>) {
    if out.len() >= MAX_LIST_ENTRIES {
        return;
    }
    let Ok(entries) = std::fs::read_dir(dir) else {
        out.push(format!("[нет доступа] {}", rel_display(root, dir)));
        return;
    };
    let mut items: Vec<_> = entries.flatten().collect();
    items.sort_by_key(|e| {
        let is_dir = e.file_type().map(|t| t.is_dir()).unwrap_or(false);
        (!is_dir, e.file_name())
    });
    for entry in items {
        if out.len() >= MAX_LIST_ENTRIES {
            out.push("… (список обрезан)".to_string());
            return;
        }
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        let file_type = entry.file_type().ok();
        let is_dir = file_type.map(|t| t.is_dir()).unwrap_or(false);
        let rel = rel_display(root, &path);
        if is_dir {
            if SKIP_DIRS.contains(&name.as_str()) {
                continue;
            }
            out.push(format!("📁 {rel}/"));
            if depth > 1 {
                listing(root, &path, depth - 1, out);
            }
        } else {
            let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
            out.push(format!("📄 {rel} ({})", human_size(size)));
        }
    }
}

pub fn execute(root: &Path, name: &str, args: &Value) -> (bool, String) {
    let arg = |key: &str| -> String {
        args.get(key)
            .and_then(|v| v.as_str())
            .unwrap_or_default()
            .to_string()
    };
    match name {
        "list_dir" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            if !path.is_dir() {
                return (false, "Это не папка".to_string());
            }
            let depth = args.get("depth").and_then(|v| v.as_u64()).unwrap_or(1).clamp(1, 3) as u32;
            let mut out = Vec::new();
            listing(root, &path, depth, &mut out);
            if out.is_empty() {
                return (true, "Папка пуста".to_string());
            }
            (true, out.join("\n"))
        }
        "read_file" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            let meta = match std::fs::metadata(&path) {
                Ok(m) => m,
                Err(e) => return (false, format!("Не удалось открыть файл: {e}")),
            };
            if meta.is_dir() {
                return (false, "Это папка, используйте list_dir".to_string());
            }
            if meta.len() > MAX_READ_BYTES {
                return (
                    false,
                    format!("Файл слишком большой ({})", human_size(meta.len())),
                );
            }
            match std::fs::read(&path) {
                Ok(bytes) => {
                    if bytes.iter().take(4096).any(|b| *b == 0) {
                        return (false, "Файл бинарный, чтение текстом невозможно".to_string());
                    }
                    (
                        true,
                        String::from_utf8_lossy(&bytes).to_string(),
                    )
                }
                Err(e) => (false, format!("Ошибка чтения: {e}")),
            }
        }
        "write_file" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            let content = arg("content");
            match std::fs::write(&path, content.as_bytes()) {
                Ok(_) => (
                    true,
                    format!(
                        "Записано {} → {}",
                        human_size(content.as_bytes().len() as u64),
                        rel_display(root, &path)
                    ),
                ),
                Err(e) => (false, format!("Ошибка записи: {e}")),
            }
        }
        "append_file" => {
            use std::io::Write;
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            let content = arg("content");
            let file = std::fs::OpenOptions::new().create(true).append(true).open(&path);
            match file {
                Ok(mut f) => match f.write_all(content.as_bytes()) {
                    Ok(_) => (true, format!("Дописано в {}", rel_display(root, &path))),
                    Err(e) => (false, format!("Ошибка записи: {e}")),
                },
                Err(e) => (false, format!("Ошибка открытия: {e}")),
            }
        }
        "create_dir" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            match std::fs::create_dir_all(&path) {
                Ok(_) => (true, format!("Папка создана: {}", rel_display(root, &path))),
                Err(e) => (false, format!("Ошибка создания папки: {e}")),
            }
        }
        "move_path" => {
            let from = match resolve(root, &arg("from")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            let to = match resolve(root, &arg("to")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            if let Some(parent) = to.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            match std::fs::rename(&from, &to) {
                Ok(_) => (
                    true,
                    format!(
                        "{} → {}",
                        rel_display(root, &from),
                        rel_display(root, &to)
                    ),
                ),
                Err(e) => (false, format!("Ошибка перемещения: {e}")),
            }
        }
        "delete_path" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            if path == root.canonicalize().unwrap_or_else(|_| root.to_path_buf()) {
                return (false, "Нельзя удалить корень рабочей папки".to_string());
            }
            let recursive = args
                .get("recursive")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let result = if path.is_dir() {
                if recursive {
                    std::fs::remove_dir_all(&path)
                } else {
                    std::fs::remove_dir(&path)
                }
            } else {
                std::fs::remove_file(&path)
            };
            match result {
                Ok(_) => (true, format!("Удалено: {}", rel_display(root, &path))),
                Err(e) => (false, format!("Ошибка удаления: {e}")),
            }
        }
        "file_info" => {
            let path = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            match std::fs::metadata(&path) {
                Ok(meta) => {
                    let modified = meta
                        .modified()
                        .ok()
                        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
                        .map(|d| d.as_secs())
                        .unwrap_or(0);
                    let kind = if meta.is_dir() { "папка" } else { "файл" };
                    (
                        true,
                        format!(
                            "{kind}: {}\nразмер: {}\nизменён: {}",
                            rel_display(root, &path),
                            human_size(meta.len()),
                            chrono::DateTime::from_timestamp(modified as i64, 0)
                                .map(|d| d.format("%Y-%m-%d %H:%M UTC").to_string())
                                .unwrap_or_else(|| "—".into())
                        ),
                    )
                }
                Err(e) => (false, format!("Ошибка чтения метаданных: {e}")),
            }
        }
        "search_files" => {
            let base = match resolve(root, &arg("path")) {
                Ok(p) => p,
                Err(e) => return (false, e),
            };
            let query = arg("query").to_lowercase();
            if query.len() < 2 {
                return (false, "Запрос слишком короткий".to_string());
            }
            let in_content = args
                .get("content")
                .and_then(|v| v.as_bool())
                .unwrap_or(true);
            let mut hits: Vec<String> = Vec::new();
            let mut stack = vec![(base, 0u32)];
            let root_c = root.canonicalize().unwrap_or_else(|_| root.to_path_buf());
            while let Some((dir, depth)) = stack.pop() {
                if hits.len() >= 80 || depth > 8 {
                    break;
                }
                let Ok(entries) = std::fs::read_dir(&dir) else { continue };
                for entry in entries.flatten() {
                    if hits.len() >= 80 {
                        break;
                    }
                    let path = entry.path();
                    let name = entry.file_name().to_string_lossy().to_string();
                    if name.starts_with('.') || SKIP_DIRS.contains(&name.as_str()) {
                        continue;
                    }
                    let is_dir = entry.file_type().map(|t| t.is_dir()).unwrap_or(false);
                    if is_dir {
                        stack.push((path, depth + 1));
                        continue;
                    }
                    let rel = rel_display(&root_c, &path);
                    if name.to_lowercase().contains(&query) {
                        hits.push(format!("имя: {rel}"));
                        continue;
                    }
                    if !in_content {
                        continue;
                    }
                    let meta = entry.metadata().ok();
                    if meta.as_ref().map(|m| m.len()).unwrap_or(0) > 512_000 {
                        continue;
                    }
                    if let Ok(bytes) = std::fs::read(&path) {
                        if bytes.iter().take(2048).any(|b| *b == 0) {
                            continue;
                        }
                        let text = String::from_utf8_lossy(&bytes);
                        for (i, line) in text.lines().enumerate() {
                            if line.to_lowercase().contains(&query) {
                                let trimmed = crate::util::truncate_chars(line.trim(), 160);
                                hits.push(format!("{rel}:{}: {trimmed}", i + 1));
                                if hits.len() >= 80 {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if hits.is_empty() {
                (true, "Ничего не найдено".to_string())
            } else {
                (true, hits.join("\n"))
            }
        }
        other => (false, format!("Неизвестный инструмент: {other}")),
    }
}

pub fn overview(root: &Path) -> (u64, u64, Vec<String>) {
    let root_c = match root.canonicalize() {
        Ok(p) => p,
        Err(_) => return (0, 0, Vec::new()),
    };
    let mut files = 0u64;
    let mut size = 0u64;
    let mut top = Vec::new();
    let mut stack = vec![(root_c.clone(), 0u32)];
    while let Some((dir, depth)) = stack.pop() {
        if files > 50_000 {
            break;
        }
        let Ok(entries) = std::fs::read_dir(&dir) else { continue };
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().to_string();
            if depth == 0 {
                top.push(name.clone());
            }
            if SKIP_DIRS.contains(&name.as_str()) || name.starts_with('.') {
                if entry.file_type().map(|t| t.is_dir()).unwrap_or(false) {
                    continue;
                }
            }
            let is_dir = entry.file_type().map(|t| t.is_dir()).unwrap_or(false);
            if is_dir {
                stack.push((entry.path(), depth + 1));
            } else {
                files += 1;
                size += entry.metadata().map(|m| m.len()).unwrap_or(0);
            }
        }
    }
    top.sort();
    top.truncate(12);
    (files, size, top)
}
