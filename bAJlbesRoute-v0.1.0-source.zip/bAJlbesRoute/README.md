# bAJlbesRoute

> **Ваш AI-маршрут.** Приватный кроссплатформенный клиент для **своих** AI-ключей и endpoint'ов:
> Windows · Android · iOS. Ядро — Rust, оболочка — Tauri 2, интерфейс — React + TypeScript.

![stack](https://img.shields.io/badge/core-Rust-c4623b) ![tauri](https://img.shields.io/badge/shell-Tauri%202-24c8db) ![react](https://img.shields.io/badge/ui-React%2018%20%2B%20TS-149eca) ![build](https://img.shields.io/badge/CI-GitHub%20Actions-2088ff)

---

## Что умеет

| Возможность | Детали |
|---|---|
| **Свои ключи и endpoint'ы** | OpenAI, Anthropic, Google Gemini, OpenRouter, DeepSeek, Groq, xAI, Mistral, Ollama, LM Studio и любой OpenAI-совместимый / Anthropic-сервер |
| **Стриминг** | SSE-парсер в Rust, отображение текста и блока «Размышления» (reasoning/thinking) в реальном времени |
| **Выбор модели** | Красивый пикер: поиск, группировка по провайдеру, бейджи reasoning / vision / tools, контекст, обновление списка через `GET /models` |
| **Усилия модели** | 4 режима: выкл / низкое / среднее / высокое → `reasoning_effort` (OpenAI) или `thinking.budget_tokens` (Anthropic) |
| **Понимание окружения** | Модель знает: платформу, ОС, устройство, WebView, версию приложения, выбранную модель и провайдера, текущее время, состояние рабочей папки |
| **Работа с файлами** | 9 инструментов (list/read/write/append/create/move/delete/info/search), доступ ограничен выбранной папкой; tool-loop до 6 раундов |
| **Фон на Windows** | Сворачивание в трей, single-instance, генерация продолжается при закрытом окне, системное уведомление «модель ответила» |
| **Мобильный опыт** | Виброотклик (Tauri haptics plugin + `navigator.vibrate`), sheet-модалки, safe-area, крупные тач-цели, продолжение работы в фоне |
| **Imagine** | Генерация **фото и видео**: все доступные источники запускаются параллельно, побеждает **первый успешный ответ**, остальные отменяются. Журнал попыток + локальная галерея |
| **Автосборки** | GitHub Actions: Windows (NSIS/MSI), macOS, Linux, Android APK, iOS unsigned IPA + отдельный CI-workflow |

### Скриншоты
Каталог `docs/screenshots/` — десктоп и мобильный вид (генерируются скриптом, см. ниже).

---

## Требования

* Node.js **20+**
* Rust **1.90+** (`rustup default stable`)
* Платформенные зависимости Tauri 2 — https://v2.tauri.app/start/prerequisites/

---

## Быстрый старт

```bash
npm install
npm run tauri dev          # запуск с реальным Rust-ядром
npm run dev                # только UI в браузере (демо-режим, без API)
npm run typecheck          # проверка типов
```

Полезно: `npm run tauri icon src-tauri/icons/source.png` — перегенерация всех иконок
(исходник рисуется скриптом `python3 scripts/make_icon.py`).

---

## Как упаковать под Windows

### Вариант A — на своей машине (самый быстрый)

1. Установите **Rust** (rustup) и **Node 20+**, а также [Microsoft C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
   (галочка «Разработка классических приложений на C++») и **WebView2 Runtime**
   (на Windows 10/11 он уже стоит).
2. В папке проекта:

```powershell
npm install
npm run tauri build
```

Готовые файлы появятся в:

```
src-tauri\target\release\bundle\nsis\bAJlbesRoute_0.1.0_x64-setup.exe   ← установщик (рекомендуется)
src-tauri\target\release\bundle\msi\bAJlbesRoute_0.1.0_x64_en-US.msi    ← MSI для развёртывания
src-tauri\target\release\bAJlbesRoute.exe                               ← exe, работает и без установки
```

Установщик NSIS ставится **без прав администратора** (`installMode: currentUser`),
языки — русский и английский. WebView2 при отсутствии подтянется автоматически
(`downloadBootstrapper`).

#### «Портативная» версия (один exe, без установки)

Exe из `src-tauri\target\release\` уже самодостаточен — можно скопировать его в любую папку
или на флешку и запускать. Для удобства есть скрипт:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\package-windows.ps1
# → dist\bAJlbesRoute-0.1.0-portable.zip  (exe + инструкция)
# → dist\bAJlbesRoute-0.1.0-installer.zip (NSIS + MSI)
```

#### Подпись кода (убирает SmartScreen-предупреждение)

Нужен сертификат Code Signing (OV/EV). В `src-tauri/tauri.conf.json`:

```json
"bundle": {
  "windows": {
    "certificateThumbprint": "ВАШ_ОТПЕЧАТОК",
    "digestAlgorithm": "sha256",
    "timestampUrl": "http://timestamp.digicert.com"
  }
}
```

или в CI передайте `TAURI_SIGNING_PRIVATE_KEY` для автообновлений (updater) — см. ниже.

### Вариант B — GitHub Actions (рекомендуется для релизов)

`.github/workflows/release.yml` собирает Windows, macOS и Linux на тег:

```bash
git tag v0.1.0
git push origin v0.1.0
```

→ вкладка **Actions** → **Release (Windows / macOS / Linux)** → по завершении в **Releases**
появятся `…_x64-setup.exe`, `…_x64_en-US.msi` и артефакты других платформ.
Можно и вручную: **Actions → Release → Run workflow** (галочка «черновик релиза»).

Артефакты Windows также всегда доступны в блоке **Artifacts → windows-installers**.

---

## Android

```bash
npm run tauri android init     # один раз — создаст src-tauri/gen/android
npm run tauri android dev      # запуск на устройстве/эмуляторе
npm run tauri android build --apk --target aarch64
```

Требуется Android Studio (SDK + NDK 27), JDK 17. В CI это делает
`.github/workflows/android.yml` → артефакт `bajlbesroute-android` (APK).

**Release-подпись (CI).** Добавьте секреты репозитория:

| Секрет | Что это |
|---|---|
| `ANDROID_KEY_BASE64` | keystore в base64: `base64 -w0 release.keystore` |
| `ANDROID_KEY_ALIAS` | алиас ключа |
| `ANDROID_KEY_PASSWORD` | пароль ключа |
| `ANDROID_STORE_PASSWORD` | пароль keystore |

Затем **Actions → Android (APK) → Run workflow** с галочкой `release_build`.

Ключевые мобильные функции уже включены: `@tauri-apps/plugin-haptics` (виброотклик),
разрешения в `src-tauri/capabilities/mobile.json`, работа при свёрнутом приложении
(запрос выполняется в Rust-ядре, а не в WebView).

---

## iOS

```bash
npm run tauri ios init         # один раз — создаст src-tauri/gen/apple
npm run tauri ios dev          # запуск на iPhone (нужен Mac + Xcode + Apple ID)
```

CI: `.github/workflows/ios.yml` собирает **неподписанный .ipa** на `macos-14`
(устанавливается через AltStore / Sideloadly / TrollStore).
Для TestFlight/App Store нужна подпись вашим Apple Developer аккаунтом —
добавьте секреты и замените шаг `xcodebuild` на подписанный (или используйте `tauri ios build`
на Mac с настроенным сертификатом).

Минимальная версия iOS — 14.0, Android — API 24.

---

## Архитектура

```
bAJlbesRoute/
├── src/                        # React + TypeScript (интерфейс)
│   ├── App.tsx                 # каркас, модалки, роутинг экранов
│   ├── components/
│   │   ├── Sidebar.tsx         # чаты + кнопка «imagine» в левом верхнем углу
│   │   ├── TopBar.tsx          # заголовок, статус, быстрый выбор модели
│   │   ├── MessageList.tsx     # сообщения, размышления, tool-чипы, вложения
│   │   ├── Composer.tsx        # ввод, вложения, модель, усилия, папка
│   │   ├── ModelPicker.tsx     # выбор модели + обновление списков
│   │   ├── Settings.tsx        # настройки (5 вкладок)
│   │   ├── ProvidersTab.tsx    # ключи, endpoint'ы, модели
│   │   ├── ImaginePanel.tsx    # генерация фото/видео + галерея
│   │   ├── ImagineTab.tsx      # настройки источников Imagine
│   │   ├── Onboarding.tsx      # 3 шага первого запуска
│   │   ├── MarkdownView.tsx    # Markdown + подсветка кода + копирование
│   │   └── ui.tsx              # дизайн-система (модалки, switch, поля…)
│   ├── lib/                    # мост к Rust, промпты, haptics, notify, demo
│   └── store/store.ts          # zustand: чаты, провайдеры, запуски, медиа
│
├── src-tauri/                  # Rust-ядро
│   ├── src/lib.rs              # регистрация плагинов, трей, single-instance
│   ├── src/chat.rs             # стриминг OpenAI/Anthropic, tool-loop, снапшоты, отмена
│   ├── src/imagine.rs          # «первый успешный ответ»: OpenAI/fal/Replicate/Together/
│   │                           # Stability/Pollinations/Veo + сохранение медиа
│   ├── src/tools.rs            # файловые инструменты (sandbox внутри папки)
│   ├── src/system.rs           # окружение, настройки, вложения, уведомления
│   └── src/util.rs             # HTTP-клиент, SSE-буфер, base64, URL
│
├── .github/workflows/          # ci · release · android · ios
└── scripts/                    # иконка, упаковка под Windows
```

### Почему запросы живут в Rust, а не в WebView

`start_chat` поднимает `tokio`-задачу и отдаёт события `chat:event` в интерфейс.
Даже если окно свернули в трей, заблокировали экран телефона или переключили чат —
поток продолжает читаться, а `get_chat_snapshot` позволяет UI «догнать» состояние
при возвращении. Отмена — через `CancellationToken` (`stop_chat`).

### «Кто я» — самосознание модели

Перед каждым запросом собирается системный промпт (`src/lib/prompt.ts`):
идентичность приложения → выбранная модель и провайдер → режим усилий →
окружение (платформа, ОС, устройство, WebView, версия) → состояние рабочей папки →
правила работы с файлами → стиль ответов → пользовательская инструкция.
Модель корректно отвечает «я — Claude… через Anthropic через bAJlbesRoute» и не путает себя с чужим продуктом.

---

## Imagine: как работает «первый без ошибки»

1. Из настроек собирается список доступных источников (те, где есть ключ/включены).
2. Rust запускает их **одновременно** (`FuturesUnordered`) с общим `CancellationToken`.
3. Первый `Ok(...)` побеждает: файл сохраняется в `app_local_data/media`,
   остальные фьючерсы уничтожаются.
4. Ошибки не фатальны — каждая пишется в журнал (`imagine:event`), UI показывает их списком.
5. Если не ответил никто — вернётся агрегированная ошибка по всем источникам.

| Источник | Фото | Видео | Ключ |
|---|---|---|---|
| OpenAI `gpt-image-1` | ✅ | — | ключ OpenAI в «Провайдерах» |
| fal.ai (FLUX schnell / LTX video) | ✅ | ✅ | `imagine.fal` |
| Replicate (Wan 2.2 t2v/i2v) | — | ✅ | `imagine.replicate` |
| Together (FLUX schnell) | ✅ | — | `imagine.together` |
| Stability (Stable Image Core) | ✅ | — | `imagine.stability` |
| Google Veo 3 fast | — | ✅ | ключ Gemini или отдельный |
| Pollinations | ✅ | — | без ключа (всегда включён) |
| Свои OpenAI-совместимые | ✅ | — | `imagine.customImages[]` |

Анимация фото: загруженный кадр уходит в `image_url` (fal LTX i2v), в `image`
(Replicate i2v) или в `instances[0].image` (Veo).

---

## Идентификаторы

| Что | Значение |
|---|---|
| productName | `bAJlbesRoute` |
| bundle identifier | `com.bajlbesroute.app` |
| Windows-процесс / exe | `bAJlbesRoute.exe` |
| npm-пакет | `bajlbesroute` |
| crate / lib | `bajlbesroute` / `bajlbesroute_lib` |

> Важно: bundle identifier **не меняйте** после релиза — на него завязаны обновления
> и пути данных (`%LOCALAPPDATA%\com.bajlbesroute.app`, `~/Library/…`, Android package).

---

## Приватность и безопасность

* Ключи, чаты и настройки хранятся **локально**: `state.json` в папке данных приложения
  (`%LOCALAPPDATA%\com.bajlbesroute.app\state.json` на Windows).
* Запросы идут **напрямую** к вашему провайдеру — промежуточных серверов нет.
* Файловые инструменты ограничены выбранной рабочей папкой (канонизация путей + проверка префикса).
* CSP отключён (`csp: null`), т.к. пользователь сам задаёт endpoint'ы. Если публикуете
  сборку для других — задайте CSP в `tauri.conf.json` под свои домены.
* Ключи в `state.json` лежат в открытом виде — это осознанный компромисс для портативности.
  Для продакшена подключите [`tauri-plugin-stronghold`](https://v2.tauri.app/plugin/stronghold/)
  или системный keychain.

---

## Roadmap-идеи

- [ ] Stronghold/Keychain для ключей
- [ ] Ветвление сообщений и «продолжить»
- [ ] Экспорт чата в Markdown/JSON
- [ ] Голосовой ввод (Whisper через ваш ключ)
- [ ] Автообновления (`tauri-plugin-updater` + подпись)
- [ ] Локальная статистика расходов по токенам

---

## Лицензия

MIT — см. `LICENSE`. Используйте, форкайте, адаптируйте под себя.
