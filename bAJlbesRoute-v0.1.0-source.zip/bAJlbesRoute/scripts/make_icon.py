#!/usr/bin/env python3
"""Генерация исходной иконки bAJlbesRoute (1024x1024).

Стиль: тёмный тёплый фон + коралловый «маршрут» — две точки, соединённые
плавной кривой. Запуск: python3 scripts/make_icon.py
Затем: npm run icons
"""
from __future__ import annotations

import math
import os

from PIL import Image, ImageDraw, ImageFilter

SIZE = 1024
SS = 4  # supersampling
W = SIZE * SS

ACCENT = (217, 119, 87)
ACCENT_SOFT = (240, 168, 139)
BG_TOP = (32, 29, 26)
BG_BOTTOM = (15, 14, 13)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def bezier(p0, p1, p2, p3, steps=600):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        mt = 1 - t
        x = mt**3 * p0[0] + 3 * mt**2 * t * p1[0] + 3 * mt * t**2 * p2[0] + t**3 * p3[0]
        y = mt**3 * p0[1] + 3 * mt**2 * t * p1[1] + 3 * mt * t**2 * p2[1] + t**3 * p3[1]
        pts.append((x, y))
    return pts


def gradient_bg() -> Image.Image:
    img = Image.new("RGB", (W, W), BG_BOTTOM)
    draw = ImageDraw.Draw(img)
    for y in range(W):
        t = y / (W - 1)
        c = tuple(int(lerp(BG_TOP[i], BG_BOTTOM[i], t**0.85)) for i in range(3))
        draw.line([(0, y), (W, y)], fill=c)
    # тёплое свечение
    glow = Image.new("L", (W, W), 0)
    gd = ImageDraw.Draw(glow)
    gd.ellipse(
        [-W * 0.35, -W * 0.45, W * 0.85, W * 0.65],
        fill=70,
    )
    glow = glow.filter(ImageFilter.GaussianBlur(W // 6))
    warm = Image.new("RGB", (W, W), (120, 62, 40))
    img = Image.composite(warm, img, glow.point(lambda v: int(v * 0.75)))
    return img


def draw_route(layer: Image.Image, color, width: int) -> None:
    d = ImageDraw.Draw(layer)
    p0 = (W * 0.255, W * 0.745)
    p1 = (W * 0.30, W * 0.34)
    p2 = (W * 0.72, W * 0.70)
    p3 = (W * 0.755, W * 0.275)
    pts = bezier(p0, p1, p2, p3)
    r = width / 2
    for (x, y) in pts:
        d.ellipse([x - r, y - r, x + r, y + r], fill=color)
    # узлы маршрута
    for (cx, cy), rad in ((p0, width * 1.14), (p3, width * 1.18)):
        d.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=color)
    # промежуточная точка
    mid = pts[len(pts) // 2]
    rad = width * 0.74
    d.ellipse([mid[0] - rad, mid[1] - rad, mid[0] + rad, mid[1] + rad], fill=color)


def main() -> None:
    base = gradient_bg().convert("RGBA")

    # мягкое свечение маршрута
    glow_layer = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    draw_route(glow_layer, ACCENT + (150,), int(W * 0.070))
    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(W // 30))
    base = Image.alpha_composite(base, glow_layer)

    # сам маршрут с градиентом по толщине (две полосы для объёма)
    route = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    draw_route(route, (150, 72, 50, 255), int(W * 0.088))
    route2 = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    draw_route(route2, ACCENT + (255,), int(W * 0.070))
    base = Image.alpha_composite(base, route)
    base = Image.alpha_composite(base, route2)

    # блик на верхнем узле
    spark = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    sd = ImageDraw.Draw(spark)
    cx, cy = W * 0.755, W * 0.275
    rad = W * 0.044
    sd.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=ACCENT_SOFT + (255,))
    spark = spark.filter(ImageFilter.GaussianBlur(W // 90))
    base = Image.alpha_composite(base, spark)

    # виньетка
    vig = Image.new("L", (W, W), 0)
    vd = ImageDraw.Draw(vig)
    vd.ellipse(
        [-W * 0.12, -W * 0.12, W * 1.12, W * 1.12],
        fill=255,
    )
    vig = vig.filter(ImageFilter.GaussianBlur(W // 12))
    dark = Image.new("RGB", (W, W), (9, 8, 8))
    base = Image.composite(base.convert("RGB"), dark, vig).convert("RGBA")

    out = base.resize((SIZE, SIZE), Image.LANCZOS)
    os.makedirs("src-tauri/icons", exist_ok=True)
    out.save("src-tauri/icons/source.png", "PNG")
    print("saved src-tauri/icons/source.png", out.size)


if __name__ == "__main__":
    main()
