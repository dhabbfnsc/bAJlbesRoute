# bAJlbesRoute: сборка под Windows
# Запуск: powershell -ExecutionPolicy Bypass -File scripts\package-windows.ps1
# Результат: dist\bAJlbesRoute-<version>-portable.zip и dist\bAJlbesRoute-<version>-installer.zip

$ErrorActionPreference = "Stop"

function Write-Step($text) {
    Write-Host ""
    Write-Host "==> $text" -ForegroundColor Cyan
}

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$pkg = Get-Content "package.json" -Raw | ConvertFrom-Json
$version = $pkg.version

Write-Step "Проверяю окружение"
$missing = @()
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { $missing += "Node.js 20+" }
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) { $missing += "Rust (rustup)" }
if ($missing.Count -gt 0) {
    Write-Host "Не найдено: $($missing -join ', ')" -ForegroundColor Red
    Write-Host "Установите Node.js 20+ и Rust: https://rustup.rs" -ForegroundColor Yellow
    exit 1
}

Write-Step "npm ci"
if (Test-Path "package-lock.json") { npm ci } else { npm install }

Write-Step "Сборка релиза (Tauri)"
npm run tauri build

$bundleDir = Join-Path $root "src-tauri\target\release\bundle"
$exe = Join-Path $root "src-tauri\target\release\bAJlbesRoute.exe"
$outDir = Join-Path $root "dist"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Write-Step "Портативная версия"
if (Test-Path $exe) {
    $portableDir = Join-Path $env:TEMP "bajlbesroute-portable"
    Remove-Item -Recurse -Force $portableDir -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $portableDir | Out-Null
    Copy-Item $exe $portableDir
    Copy-Item (Join-Path $root "README.md") $portableDir -ErrorAction SilentlyContinue
    $readme = @"
bAJlbesRoute $version — портативная сборка
=========================================

1. Запустите bAJlbesRoute.exe (WebView2 уже есть в Windows 10/11;
   если нет — приложение подскажет установить).
2. Настройки -> Провайдеры -> вставьте API-ключ.
3. Настройки -> Чат и файлы -> выберите рабочую папку.

Данные хранятся локально: %LOCALAPPDATA%\com.bajlbesroute.app
Закрытие окна сворачивает приложение в трей (настраивается).
"@
    Set-Content -Path (Join-Path $portableDir "КАК-ЗАПУСТИТЬ.txt") -Value $readme -Encoding UTF8
    $portableZip = Join-Path $outDir "bAJlbesRoute-$version-portable.zip"
    if (Test-Path $portableZip) { Remove-Item $portableZip -Force }
    Compress-Archive -Path "$portableDir\*" -DestinationPath $portableZip
    Write-Host "OK: $portableZip" -ForegroundColor Green
} else {
    Write-Host "Не найден $exe — пропускаю портативную сборку" -ForegroundColor Yellow
}

Write-Step "Установщики"
if (Test-Path $bundleDir) {
    $installerZip = Join-Path $outDir "bAJlbesRoute-$version-installer.zip"
    if (Test-Path $installerZip) { Remove-Item $installerZip -Force }
    $files = Get-ChildItem -Path $bundleDir -Recurse -Include *.exe, *.msi -File
    if ($files.Count -gt 0) {
        $stage = Join-Path $env:TEMP "bajlbesroute-installers"
        Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $stage | Out-Null
        $files | ForEach-Object { Copy-Item $_.FullName $stage }
        Compress-Archive -Path "$stage\*" -DestinationPath $installerZip
        Write-Host "OK: $installerZip" -ForegroundColor Green
        $files | ForEach-Object { Write-Host ("   " + $_.Name) }
    } else {
        Write-Host "Установщики не найдены (проверьте bundle.targets)" -ForegroundColor Yellow
    }
}

Write-Step "Готово"
Get-ChildItem $outDir | Format-Table Name, @{Label = "Размер"; Expression = { "{0:N1} МБ" -f ($_.Length / 1MB) } }
