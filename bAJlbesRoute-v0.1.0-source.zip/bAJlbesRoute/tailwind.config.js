/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#121110",
        panel: "#171614",
        elev: "#1e1c19",
        raised: "#252220",
        line: "#2e2a26",
        line2: "#3a352f",
        ink: "#ece7df",
        muted: "#a89f93",
        faint: "#787065",
        accent: {
          DEFAULT: "#d97757",
          soft: "#e79b7d",
          deep: "#a8543a",
          glow: "rgba(217,119,87,0.16)",
        },
        ok: "#8fb573",
        warn: "#e0b166",
        err: "#e0705c",
        info: "#84a9c7",
      },
      fontFamily: {
        sans: [
          "ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto",
          "Helvetica Neue", "Arial", "Noto Sans", "sans-serif", "Apple Color Emoji", "Segoe UI Emoji",
        ],
        mono: ["ui-monospace", "SFMono-Regular", "JetBrains Mono", "Menlo", "Consolas", "monospace"],
      },
      borderRadius: {
        xl2: "18px",
        xl3: "24px",
      },
      boxShadow: {
        float: "0 18px 50px -12px rgba(0,0,0,0.65), 0 0 0 1px rgba(255,255,255,0.04)",
        sheet: "0 -24px 60px -20px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,255,255,0.05)",
        glow: "0 0 0 1px rgba(217,119,87,0.35), 0 8px 30px -8px rgba(217,119,87,0.35)",
      },
      keyframes: {
        fadeUp: {
          from: { opacity: "0", transform: "translateY(6px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: { from: { opacity: "0" }, to: { opacity: "1" } },
        scaleIn: {
          from: { opacity: "0", transform: "scale(0.97) translateY(6px)" },
          to: { opacity: "1", transform: "scale(1) translateY(0)" },
        },
        sheetUp: {
          from: { transform: "translateY(100%)" },
          to: { transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        blink: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.15" },
        },
        pulseSoft: {
          "0%, 100%": { opacity: "0.55" },
          "50%": { opacity: "1" },
        },
        spinSlow: { to: { transform: "rotate(360deg)" } },
      },
      animation: {
        fadeUp: "fadeUp 0.28s cubic-bezier(0.22,1,0.36,1) both",
        fadeIn: "fadeIn 0.2s ease both",
        scaleIn: "scaleIn 0.2s cubic-bezier(0.22,1,0.36,1) both",
        sheetUp: "sheetUp 0.32s cubic-bezier(0.22,1,0.36,1) both",
        shimmer: "shimmer 2.2s linear infinite",
        blink: "blink 1s ease-in-out infinite",
        pulseSoft: "pulseSoft 1.6s ease-in-out infinite",
        spinSlow: "spinSlow 2.4s linear infinite",
      },
    },
  },
  plugins: [],
};
