# Как упаковать bAJlbesRoute для Windows

Короткая инструкция + разбор проблем. Полная версия — в `README.md`.

---

## 1. Что установить (один раз)

| Компонент | Ссылка | Зачем |
|---|---|---|
| **Node.js 20 LTS** | https://nodejs.org | сборка интерфейса |
| **Rust (rustup)** | https://rustup.rs | ядро приложения |
| **Visual Studio Build Tools** | https://visualstudio.microsoft.com/visual-cpp-build-tools/ | линковщик C++ (`MSVC v143` + Windows 10/11 SDK) |
| **WebView2 Runtime** | обычно уже есть в Win10/11 | движок окна (приложение умеет доустановить) |

Проверка после установки:

```powershell
node -v      # v20.x
cargo -V     # cargo 1.9x.x
```

---

## 2. Сборка

```powershell
cd bAJlbesRoute
npm install
npm run tauri build
```

Первая сборка занимает 5–15 минут (компилируется Rust), потом — быстрее.

### Что получится

```
src-tauri\target\release\
├── bAJlbesRoute.exe                                     ← портативный exe
└── bundle\
    ├── nsis\bAJlbesRoute_0.1.0_x64-setup.exe            ← установщик (рекомендуется)
    └── msi\bAJlbesRoute_0.1.0_x64_en-US.msi             ← MSI (для компаний)
```

Все три варианта уже готовы к раздаче:

* **`…-setup.exe`** — обычная установка «для текущего пользователя» (без UAC),
  ярлык на рабочем столе и в меню «Пуск», деинсталлятор.
* **`.msi`** — групповые политики, MDM, развёртывание.
* **`bAJlbesRoute.exe`** — просто скопировать в любую папку/флешку и запустить,
  данные будут лежать в `%LOCALAPPDATA%\com.bajlbesroute.app`.

### Одной командой со сборкой архивов

```powershell
powershell -ExecutionPolicy Bypass -File scripts\package-windows.ps1
```

Результат в `dist\`:

```
dist\bAJlbesRoute-0.1.0-portable.zip     (exe + «КАК-ЗАПУСТИТЬ.txt»)
dist\bAJlbesRoute-0.1.0-installer.zip    (NSIS + MSI)
```

### Отдельные варианты сборки

```powershell
npm run tauri build -- --bundles nsis        # только установщик
npm run tauri build -- --bundles msi         # только MSI
npm run tauri build -- --no-bundle           # только exe (быстрее)
npm run tauri build -- --target x86_64-pc-windows-msvc
```

---

## 3. Сборка через GitHub Actions (без Windows на руках)

```bash
git tag v0.1.0
git push origin v0.1.0
```

Workflow **Release (Windows / macOS / Linux)** соберёт установщики и приложит их к релизу.
Вручную: *Actions → Release → Run workflow* → отметьте «черновик релиза».

Артефакты также лежат в *Actions → (последний запуск) → Artifacts → `windows-installers`*.

---

## 4. Настройки сборки, которые стоит знать

`src-tauri/tauri.conf.json`:

```json
"windows": {
  "webviewInstallMode": { "type": "downloadBootstrapper", "silent": true },
  "nsis": { "installMode": "currentUser" }
}
```

* `downloadBootstrapper` — если WebView2 нет, установщик скачает ~2 МБ бутстраппер.
  Хотите полностью офлайн-установщик → `{ "type": "offlineInstaller" }` (+120 МБ).
* `installMode: "perMachine"` — установка для всех пользователей (нужен UAC).

### Иконка и название

* Иконки: `src-tauri/icons/*` (перегенерация: `python3 scripts/make_icon.py && npm run icons`).
* Название окна/продукта: `productName` в `tauri.conf.json` (`bAJlbesRoute`).
* Версия: `version` там же (и в `package.json`, `src-tauri/Cargo.toml` — держите в синхроне).

---

## 5. Подпись кода и SmartScreen

Без подписи Windows покажет «Windows защитила ваш компьютер». Варианты:

1. **Сертификат Code Signing (OV/EV)** — в `tauri.conf.json`:

   ```json
   "windows": {
     "certificateThumbprint": "A1B2C3…",
     "digestAlgorithm": "sha256",
     "timestampUrl": "http://timestamp.digicert.com"
   }
   ```

   EV-сертификат (аппаратный токен) сразу даёт репутацию SmartScreen.

2. **Azure Trusted Signing / SignPath** — подпись в CI без токена.

3. Пока сертификата нет — можно распространять «портативный» exe и приложить хеш SHA-256,
   чтобы пользователи могли проверить файл:

   ```powershell
   Get-FileHash .\bAJlbesRoute.exe -Algorithm SHA256
   ```

---

## 6. Частые проблемы

| Симптом | Решение |
|---|---|
| `error: linker 'link.exe' not found` | не установлен Visual Studio Build Tools (C++) |
| `error MSB8020 / Windows SDK not found` | в Build Tools отметьте Windows 10/11 SDK |
| Окно пустое/белое | нет WebView2 Runtime → установите Evergreen Runtime |
| `npm run tauri` не распознан | выполните `npm install` в папке проекта |
| Антивирус ругается на неподписанный exe | добавьте в исключения или подпишите (см. п.5) |
| `cargo build` падает на `openssl` | не нужен: используется `rustls` |
| Очень долгая первая сборка | это нормально: ~600 крейтов компилируются один раз |
| Хочу уменьшить размер | в `Cargo.toml` уже включены `lto`, `opt-level="s"`, `strip`; exe ≈ 8–12 МБ |

---

## 7. Проверка после установки

1. Запустите приложение → пройдите 3 шага онбординга (ключ можно вставить позже).
2. **Настройки → Провайдеры** → вставьте ключ → «Проверить» (должно появиться
   «Соединение успешно · моделей: N»).
3. **Настройки → Чат и файлы** → выберите рабочую папку.
4. Задайте вопрос, попросите «создай файл notes.md с планом» — убедитесь, что файл появился.
5. Сверните окно (или закройте — приложение уйдёт в трей) во время ответа:
   по завершении должно прийти уведомление. Иконка в трее открывает окно обратно.
