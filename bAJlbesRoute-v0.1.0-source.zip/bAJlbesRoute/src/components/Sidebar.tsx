import { useMemo, useState } from "react";
import {
  FolderOpen,
  MessageSquarePlus,
  Pin,
  PinOff,
  Search,
  Settings2,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { selectActiveChat, useStore } from "../store/store";
import { cn, groupLabel, plainPreview, timeAgo } from "../lib/utils";
import { choose, tap } from "../lib/haptics";
import { Logo, Wordmark } from "./ui";

export function Sidebar({
  onOpenSettings,
  onOpenImagine,
}: {
  onOpenSettings: (tab?: string) => void;
  onOpenImagine: () => void;
}) {
  const chats = useStore((s) => s.chats);
  const activeChatId = useStore((s) => s.activeChatId);
  const sidebarOpen = useStore((s) => s.sidebarOpen);
  const toggleSidebar = useStore((s) => s.toggleSidebar);
  const newChat = useStore((s) => s.newChat);
  const selectChat = useStore((s) => s.selectChat);
  const deleteChat = useStore((s) => s.deleteChat);
  const renameChat = useStore((s) => s.renameChat);
  const togglePin = useStore((s) => s.togglePin);
  const settings = useStore((s) => s.settings);
  const boot = useStore((s) => s.boot);
  const runs = useStore((s) => s.runs);
  const mediaCount = useStore((s) => s.imagineItems.length);

  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return chats;
    return chats.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.text.toLowerCase().includes(q)),
    );
  }, [chats, query]);

  const groups = useMemo(() => {
    const pinned = filtered.filter((c) => c.pinned);
    const rest = filtered.filter((c) => !c.pinned).sort((a, b) => b.updatedAt - a.updatedAt);
    const buckets = new Map<string, typeof rest>();
    for (const chat of rest) {
      const label = groupLabel(chat.updatedAt);
      if (!buckets.has(label)) buckets.set(label, []);
      buckets.get(label)!.push(chat);
    }
    return { pinned, buckets: Array.from(buckets.entries()) };
  }, [filtered]);

  const startRename = (id: string, title: string) => {
    setEditingId(id);
    setEditValue(title);
  };

  const commitRename = () => {
    if (editingId) renameChat(editingId, editValue);
    setEditingId(null);
  };

  const runningCount = Object.keys(runs).length;

  return (
    <>
      {sidebarOpen && (
        <div
          className="backdrop-enter fixed inset-0 z-30 bg-black/50 backdrop-blur-[2px] lg:hidden"
          onClick={() => toggleSidebar(false)}
        />
      )}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-[292px] flex-col border-r border-line/70 bg-panel/95 transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
          "glass lg:static lg:z-0 lg:translate-x-0 lg:bg-panel/40",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        {/* Шапка */}
        <div className="safe-top flex items-center gap-2 px-3 pb-2 pt-3">
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <Logo size={24} />
            <Wordmark className="truncate text-[15px]" />
          </div>
          <button
            className="icon-btn lg:hidden"
            onClick={() => {
              void tap();
              toggleSidebar(false);
            }}
            aria-label="Закрыть меню"
          >
            <X size={17} />
          </button>
          <button
            onClick={() => {
              void choose();
              newChat();
            }}
            className="icon-btn"
            title="Новый чат"
            aria-label="Новый чат"
          >
            <MessageSquarePlus size={17} />
          </button>
        </div>

        {/* Imagine */}
        <div className="px-3 pb-2">
          <button
            type="button"
            onClick={() => {
              void choose();
              onOpenImagine();
            }}
            className="group relative flex w-full items-center gap-2.5 overflow-hidden rounded-2xl border border-accent/25 px-3 py-2.5 text-left transition-all duration-200 hover:border-accent/45 hover:shadow-glow"
            style={{
              background:
                "linear-gradient(135deg, rgb(var(--accent)/0.16) 0%, rgba(255,255,255,0.02) 55%, rgb(var(--accent)/0.08) 100%)",
            }}
          >
            <span
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl"
              style={{ background: "linear-gradient(180deg, rgb(var(--accent)), rgb(var(--accent-deep)))" }}
            >
              <Sparkles size={15} className="text-white" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[13.5px] font-semibold tracking-[0.01em] text-ink">imagine</span>
              <span className="block truncate text-[11px] text-muted">фото · видео · анимация</span>
            </span>
            {mediaCount > 0 && (
              <span className="rounded-full bg-black/25 px-1.5 py-0.5 text-[10.5px] tabular-nums text-ink/80">
                {mediaCount}
              </span>
            )}
          </button>
        </div>

        {/* Поиск */}
        <div className="px-3 pb-2">
          <div className="relative">
            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-faint" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск по чатам"
              className="w-full rounded-xl border border-transparent bg-white/[0.04] py-1.5 pl-8 pr-2.5 text-[12.5px] text-ink placeholder:text-faint outline-none transition-colors focus:border-line2 focus:bg-white/[0.06]"
            />
          </div>
        </div>

        {/* Список чатов */}
        <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-2">
          {filtered.length === 0 && (
            <div className="px-3 py-8 text-center text-[12px] leading-relaxed text-faint">
              {query ? "Ничего не найдено" : "Пока пусто — начните новый чат"}
            </div>
          )}

          {groups.pinned.length > 0 && (
            <ChatGroup
              label="Закреплённые"
              chats={groups.pinned}
              activeChatId={activeChatId}
              runningIds={Object.keys(runs)}
              editingId={editingId}
              editValue={editValue}
              setEditValue={setEditValue}
              commitRename={commitRename}
              setEditingId={setEditingId}
              onSelect={selectChat}
              onRename={startRename}
              onDelete={(id) => {
                void choose();
                deleteChat(id);
              }}
              onPin={(id) => {
                void choose();
                togglePin(id);
              }}
            />
          )}

          {groups.buckets.map(([label, list]) => (
            <ChatGroup
              key={label}
              label={label}
              chats={list}
              activeChatId={activeChatId}
              runningIds={Object.keys(runs)}
              editingId={editingId}
              editValue={editValue}
              setEditValue={setEditValue}
              commitRename={commitRename}
              setEditingId={setEditingId}
              onSelect={selectChat}
              onRename={startRename}
              onDelete={(id) => {
                void choose();
                deleteChat(id);
              }}
              onPin={(id) => {
                void choose();
                togglePin(id);
              }}
            />
          ))}
        </div>

        {/* Подвал */}
        <div className="safe-bottom border-t border-line/60 px-2 pb-2 pt-1.5">
          <button
            type="button"
            onClick={() => {
              void choose();
              onOpenSettings("chat");
            }}
            className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[11.5px] text-muted transition-colors hover:bg-white/[0.045] hover:text-ink"
          >
            <FolderOpen size={13} className="shrink-0 text-faint" />
            <span className="truncate">
              {settings.workspace ? settings.workspace.split(/[\\/]/).pop() : "Рабочая папка не выбрана"}
            </span>
          </button>
          <div className="mt-0.5 flex items-center gap-1">
            <div className="flex min-w-0 flex-1 items-center gap-1.5 px-2 py-1 text-[10.5px] text-faint">
              <span
                className={cn(
                  "h-1.5 w-1.5 shrink-0 rounded-full",
                  runningCount ? "animate-pulseSoft bg-accent" : "bg-ok/70",
                )}
              />
              <span className="truncate">
                {boot ? boot.platformLabel : "…"}
                {runningCount > 0 ? ` · ${runningCount} в работе` : ""}
              </span>
            </div>
            <button
              onClick={() => {
                void choose();
                onOpenSettings("general");
              }}
              className="icon-btn h-8 w-8"
              title="Настройки"
            >
              <Settings2 size={15} />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}

function ChatGroup({
  label,
  chats,
  activeChatId,
  runningIds,
  editingId,
  editValue,
  setEditValue,
  commitRename,
  setEditingId,
  onSelect,
  onRename,
  onDelete,
  onPin,
}: {
  label: string;
  chats: ReturnType<typeof useStore.getState>["chats"];
  activeChatId: string | null;
  runningIds: string[];
  editingId: string | null;
  editValue: string;
  setEditValue: (v: string) => void;
  commitRename: () => void;
  setEditingId: (id: string | null) => void;
  onSelect: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
  onPin: (id: string) => void;
}) {
  return (
    <div className="mb-1">
      <div className="px-2 pb-1 pt-2 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-faint/80">
        {label}
      </div>
      {chats.map((chat) => {
        const active = chat.id === activeChatId;
        const running = runningIds.includes(chat.id);
        const last = chat.messages[chat.messages.length - 1];
        return (
          <div
            key={chat.id}
            className={cn(
              "group relative mb-0.5 flex cursor-pointer items-center gap-2 rounded-xl px-2 py-1.5 transition-colors",
              active ? "bg-white/[0.07]" : "hover:bg-white/[0.04]",
            )}
            onClick={() => {
              void tap();
              onSelect(chat.id);
            }}
            onDoubleClick={(e) => {
              e.stopPropagation();
              onRename(chat.id, chat.title);
            }}
          >
            <div className="min-w-0 flex-1">
              {editingId === chat.id ? (
                <input
                  ref={(el) => {
                    if (el && document.activeElement !== el) {
                      el.focus();
                      el.select();
                    }
                  }}
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  onBlur={commitRename}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename();
                    if (e.key === "Escape") setEditingId(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full rounded-md border border-accent/40 bg-bg px-1.5 py-0.5 text-[12.5px] text-ink outline-none"
                />
              ) : (
                <div className="flex items-center gap-1.5">
                  {running && <span className="h-1.5 w-1.5 shrink-0 animate-pulseSoft rounded-full bg-accent" />}
                  <span
                    className={cn(
                      "truncate text-[12.8px] leading-tight",
                      active ? "font-medium text-ink" : "text-ink/85",
                    )}
                  >
                    {chat.title}
                  </span>
                </div>
              )}
              {!editingId && (
                <div className="truncate text-[10.5px] leading-tight text-faint">
                  {last && last.text ? plainPreview(last.text) : "Пусто"} · {timeAgo(chat.updatedAt)}
                </div>
              )}
            </div>
            <div
              className={cn(
                "flex shrink-0 items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100",
                active && "opacity-100",
              )}
            >
              <button
                className="rounded-md p-1 text-faint hover:text-ink"
                title={chat.pinned ? "Открепить" : "Закрепить"}
                onClick={(e) => {
                  e.stopPropagation();
                  onPin(chat.id);
                }}
              >
                {chat.pinned ? <PinOff size={12} /> : <Pin size={12} />}
              </button>
              <button
                className="rounded-md p-1 text-faint hover:text-err"
                title="Удалить чат"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(chat.id);
                }}
              >
                <Trash2 size={12} />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
