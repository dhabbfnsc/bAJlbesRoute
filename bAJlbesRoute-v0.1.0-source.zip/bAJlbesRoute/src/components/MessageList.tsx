import { memo, useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Brain,
  Check,
  ChevronDown,
  Copy,
  FileText,
  FolderTree,
  HardDrive,
  Image as ImageIcon,
  PencilLine,
  RefreshCw,
  Search,
  Sparkles,
  SquarePen,
  Trash2,
  Wrench,
} from "lucide-react";
import type { Attachment, Chat, Message, RunState, ToolTrace } from "../types";
import { useStore } from "../store/store";
import { cn, formatClock } from "../lib/utils";
import { choose } from "../lib/haptics";
import { MarkdownView } from "./MarkdownView";
import { Logo, Spinner } from "./ui";

/* ------------------------------------------------------------------ */
/* Вложения                                                           */
/* ------------------------------------------------------------------ */

function AttachmentStrip({ attachments }: { attachments: Attachment[] }) {
  if (!attachments.length) return null;
  return (
    <div className="mb-2 flex flex-wrap gap-2">
      {attachments.map((a) =>
        a.kind === "image" && a.dataUrl ? (
          <img
            key={a.id}
            src={a.dataUrl}
            alt={a.name}
            className="h-24 w-24 rounded-xl border border-line object-cover"
          />
        ) : (
          <div
            key={a.id}
            className="flex max-w-[220px] items-center gap-2 rounded-xl border border-line bg-elev/70 px-2.5 py-1.5"
          >
            <FileText size={14} className="shrink-0 text-faint" />
            <span className="truncate text-[11.5px] text-muted">{a.name}</span>
          </div>
        ),
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Инструменты                                                        */
/* ------------------------------------------------------------------ */

const TOOL_META: Record<string, { icon: typeof HardDrive; label: string }> = {
  list_dir: { icon: FolderTree, label: "Список папки" },
  read_file: { icon: FileText, label: "Чтение файла" },
  write_file: { icon: SquarePen, label: "Запись файла" },
  append_file: { icon: SquarePen, label: "Дописать файл" },
  create_dir: { icon: FolderTree, label: "Создание папки" },
  move_path: { icon: FolderTree, label: "Перемещение" },
  delete_path: { icon: Trash2, label: "Удаление" },
  file_info: { icon: HardDrive, label: "Метаданные" },
  search_files: { icon: Search, label: "Поиск" },
};

function ToolChip({ tool }: { tool: ToolTrace }) {
  const [open, setOpen] = useState(false);
  const meta = TOOL_META[tool.name] ?? { icon: Wrench, label: tool.name };
  const Icon = meta.icon;
  const pathMatch = /"path"\s*:\s*"([^"]+)"/.exec(tool.args);
  const queryMatch = /"query"\s*:\s*"([^"]+)"/.exec(tool.args);
  const detail = pathMatch?.[1] ?? queryMatch?.[1] ?? "";
  return (
    <div className="overflow-hidden rounded-xl border border-line/80 bg-panel/60">
      <button
        type="button"
        onClick={() => {
          void choose();
          setOpen((v) => !v);
        }}
        className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left"
      >
        <Icon size={12.5} className={cn("shrink-0", tool.status === "error" ? "text-err" : "text-accent-soft")} />
        <span className="text-[11.5px] font-medium text-ink/90">{meta.label}</span>
        {detail && <span className="min-w-0 flex-1 truncate font-mono text-[10.5px] text-faint">{detail}</span>}
        <span className="ml-auto shrink-0">
          {tool.status === "running" ? (
            <Spinner size={11} />
          ) : tool.ok ? (
            <Check size={11.5} className="text-ok" />
          ) : (
            <AlertTriangle size={11.5} className="text-err" />
          )}
        </span>
        <ChevronDown size={11} className={cn("shrink-0 text-faint transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="border-t border-line/70 px-2.5 py-2">
          <div className="label mb-1">аргументы</div>
          <pre className="max-h-40 overflow-auto whitespace-pre-wrap rounded-lg bg-black/25 p-2 font-mono text-[10.5px] leading-relaxed text-muted">
            {tool.args || "—"}
          </pre>
          {tool.result && (
            <>
              <div className="label mb-1 mt-2">результат</div>
              <pre className="max-h-52 overflow-auto whitespace-pre-wrap rounded-lg bg-black/25 p-2 font-mono text-[10.5px] leading-relaxed text-muted">
                {tool.result}
              </pre>
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Размышления                                                        */
/* ------------------------------------------------------------------ */

function ReasoningPanel({ text, streaming }: { text: string; streaming: boolean }) {
  const [open, setOpen] = useState(streaming);
  const [auto, setAuto] = useState(true);
  const show = useStore((s) => s.settings.showReasoning);

  useEffect(() => {
    if (!streaming && auto) setOpen(false);
  }, [streaming, auto]);

  if (!text.trim() || !show) return null;
  return (
    <div className="mb-2 overflow-hidden rounded-xl border border-line/70 bg-panel/40">
      <button
        type="button"
        onClick={() => {
          void choose();
          setAuto(false);
          setOpen((v) => !v);
        }}
        className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left"
      >
        <Brain size={12.5} className={cn("shrink-0 text-accent-soft/80", streaming && "animate-pulseSoft")} />
        <span className="text-[11.5px] font-medium text-muted">
          {streaming ? "Размышляет…" : "Размышления"}
        </span>
        <span className="truncate text-[10.5px] text-faint">{text.replace(/\s+/g, " ").slice(0, 60)}</span>
        <ChevronDown size={11} className={cn("ml-auto shrink-0 text-faint transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="border-t border-line/60 px-3 py-2">
          <p className="whitespace-pre-wrap text-[12px] leading-relaxed text-muted/90">{text}</p>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Сообщения                                                          */
/* ------------------------------------------------------------------ */

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      className="icon-btn h-7 w-7"
      title="Копировать"
      onClick={async () => {
        void choose();
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1400);
        } catch {
          /* ignore */
        }
      }}
    >
      {copied ? <Check size={13} className="text-ok" /> : <Copy size={13} />}
    </button>
  );
}

function UserBubble({ message, onDelete }: { message: Message; onDelete: () => void }) {
  return (
    <div className="message-enter group flex flex-col items-end gap-1">
      <div className="max-w-[88%] rounded-2xl rounded-br-md border border-line bg-raised/80 px-3.5 py-2.5 sm:max-w-[80%]">
        {message.attachments && <AttachmentStrip attachments={message.attachments} />}
        <p className="whitespace-pre-wrap break-words text-[14px] leading-relaxed text-ink">{message.text}</p>
      </div>
      <div className="flex items-center gap-1 pr-1 opacity-0 transition-opacity group-hover:opacity-100">
        <span className="mr-1 text-[10.5px] text-faint">{formatClock(message.createdAt)}</span>
        <CopyButton text={message.text} />
        <button type="button" className="icon-btn h-7 w-7" title="Удалить" onClick={onDelete}>
          <Trash2 size={13} />
        </button>
      </div>
    </div>
  );
}

function AssistantHeader({ message }: { message: Message }) {
  return (
    <div className="mb-1.5 flex items-center gap-2 text-[11px] text-faint">
      <Logo size={15} />
      <span className="font-medium text-muted">
        {message.providerName ? `${message.providerName}` : "Модель"}
      </span>
      {message.modelId && (
        <span className="truncate rounded-md bg-white/[0.05] px-1.5 py-0.5 font-mono text-[10px] text-faint">
          {message.modelId}
        </span>
      )}
      <span className="ml-auto tabular-nums">{formatClock(message.createdAt)}</span>
    </div>
  );
}

const AssistantBubble = memo(function AssistantBubble({
  message,
  streamingText,
  streamingReasoning,
  streaming,
  status,
  tools,
  isLast,
  onRegenerate,
  onDelete,
}: {
  message: Message;
  streamingText?: string;
  streamingReasoning?: string;
  streaming: boolean;
  status?: string;
  tools?: ToolTrace[];
  isLast: boolean;
  onRegenerate: () => void;
  onDelete: () => void;
}) {
  const text = streaming ? streamingText ?? "" : message.text;
  const reasoning = streaming ? streamingReasoning ?? "" : message.reasoning ?? "";
  const toolList = streaming ? tools ?? [] : message.tools ?? [];
  const usage = message.usage;

  return (
    <div className="message-enter group flex flex-col">
      <AssistantHeader message={message} />

      {reasoning && <ReasoningPanel text={reasoning} streaming={streaming} />}

      {streaming && !text && (
        <div className="flex items-center gap-2 py-1 text-[13px] text-muted">
          <Spinner size={13} />
          <span className="thinking-shimmer font-medium">
            {status === "tools" || (tools && tools.some((t) => t.status === "running"))
              ? "Работаю с файлами…"
              : status === "no_workspace"
                ? "Думает…"
                : "Думает…"}
          </span>
        </div>
      )}

      {text && (
        <div className={cn(streaming && "typing-caret")}>
          <MarkdownView text={text} />
        </div>
      )}

      {toolList.length > 0 && (
        <div className="mt-2.5 flex flex-col gap-1.5">
          {toolList.map((tool) => (
            <ToolChip key={tool.id} tool={tool} />
          ))}
        </div>
      )}

      {message.error && (
        <div className="mt-2 flex items-start gap-2 rounded-xl border border-err/30 bg-err/[0.07] px-3 py-2">
          <AlertTriangle size={14} className="mt-0.5 shrink-0 text-err" />
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-medium text-err">Ошибка запроса</div>
            <p className="mt-0.5 whitespace-pre-wrap break-words text-[11.5px] leading-relaxed text-err/85">
              {message.error}
            </p>
            {isLast && (
              <button className="btn-soft mt-2 h-7 px-2 py-0 text-[11.5px]" onClick={onRegenerate}>
                <RefreshCw size={12} /> Повторить
              </button>
            )}
          </div>
        </div>
      )}

      {message.stopped && (
        <div className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-warn">
          <PencilLine size={11} /> Остановлено пользователем
        </div>
      )}

      {!streaming && (
        <div className="mt-1.5 flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
          {text && <CopyButton text={text} />}
          {isLast && (
            <button type="button" className="icon-btn h-7 w-7" title="Сгенерировать заново" onClick={onRegenerate}>
              <RefreshCw size={13} />
            </button>
          )}
          <button type="button" className="icon-btn h-7 w-7" title="Удалить" onClick={onDelete}>
            <Trash2 size={13} />
          </button>
          {usage?.totalTokens ? (
            <span className="ml-1 text-[10px] tabular-nums text-faint">
              {usage.promptTokens ?? 0}↑ {usage.completionTokens ?? 0}↓ · {usage.totalTokens} ток.
            </span>
          ) : null}
        </div>
      )}
    </div>
  );
});

/* ------------------------------------------------------------------ */
/* Пустой экран                                                       */
/* ------------------------------------------------------------------ */

const SUGGESTIONS = [
  "Объясни, как работает SSE-стриминг, простыми словами",
  "Составь план изучения Rust на 2 недели",
  "Придумай название и слоган для кофейни",
  "Напиши функцию на Python для парсинга CSV",
];

function Hero({ onSuggestion }: { onSuggestion: (text: string) => void }) {
  const settings = useStore((s) => s.settings);
  const boot = useStore((s) => s.boot);
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-2 pb-4 pt-6 text-center sm:pt-12">
      <div className="relative mb-5">
        <div
          className="absolute inset-0 -z-10 blur-2xl"
          style={{ background: "radial-gradient(circle, rgb(var(--accent)/0.32), transparent 70%)" }}
        />
        <Logo size={52} />
      </div>
      <h1 className="text-[26px] font-semibold tracking-tight text-ink sm:text-[30px]">
        Ваш AI-маршрут
      </h1>
      <p className="mt-2 max-w-md text-[13.5px] leading-relaxed text-muted">
        Свои ключи и endpoint'ы, любая модель, работа с файлами
        {boot?.isMobile ? " и виброотклик" : " и фоновые ответы"} — всё в одном месте.
      </p>

      <div className="mt-5 flex flex-wrap items-center justify-center gap-1.5 text-[11px] text-faint">
        <span className="chip">
          <span className={cn("h-1.5 w-1.5 rounded-full", settings.workspace ? "bg-ok" : "bg-warn")} />
          {settings.workspace ? `Папка: ${settings.workspace.split(/[\\/]/).pop()}` : "Папка не выбрана"}
        </span>
        <span className="chip">
          <Wrench size={11} /> {settings.toolsEnabled ? "Инструменты вкл" : "Инструменты выкл"}
        </span>
        {boot && <span className="chip">{boot.platformLabel}</span>}
      </div>

      <div className="mt-7 grid w-full grid-cols-1 gap-2 sm:grid-cols-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              void choose();
              onSuggestion(s);
            }}
            className="group flex items-start gap-2 rounded-xl border border-line/80 bg-panel/50 px-3 py-2.5 text-left text-[12.5px] leading-snug text-muted transition-all hover:border-line2 hover:bg-panel hover:text-ink"
          >
            <Sparkles size={13} className="mt-0.5 shrink-0 text-accent/70" />
            <span>{s}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Список                                                             */
/* ------------------------------------------------------------------ */

export function MessageList({
  chat,
  run,
  onSuggestion,
}: {
  chat: Chat | null;
  run: RunState | undefined;
  onSuggestion: (text: string) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);
  const regenerate = useStore((s) => s.regenerate);
  const deleteMessage = useStore((s) => s.deleteMessage);

  const messages = chat?.messages ?? [];
  const lastAssistantId = [...messages].reverse().find((m) => m.role === "assistant")?.id;

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useLayoutEffect(() => {
    if (atBottomRef.current) {
      bottomRef.current?.scrollIntoView({ block: "end" });
    }
  }, [messages.length, run?.text, run?.reasoning, run?.status, run?.tools.length]);

  if (!messages.length) {
    return (
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
        <Hero onSuggestion={onSuggestion} />
      </div>
    );
  }

  return (
    <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-5 px-3 py-5 sm:px-6">
        {messages.map((message) => {
          const streaming = Boolean(run && run.assistantId === message.id);
          if (message.role === "user") {
            return (
              <UserBubble
                key={message.id}
                message={message}
                onDelete={() => {
                  void choose();
                  deleteMessage(chat!.id, message.id);
                }}
              />
            );
          }
          return (
            <AssistantBubble
              key={message.id}
              message={message}
              streaming={streaming}
              streamingText={streaming ? run?.text : undefined}
              streamingReasoning={streaming ? run?.reasoning : undefined}
              status={streaming ? run?.status : undefined}
              tools={streaming ? run?.tools : undefined}
              isLast={message.id === lastAssistantId}
              onRegenerate={() => {
                void choose();
                void regenerate();
              }}
              onDelete={() => {
                void choose();
                deleteMessage(chat!.id, message.id);
              }}
            />
          );
        })}
        <div ref={bottomRef} className="h-1" />
      </div>
    </div>
  );
}

export { ImageIcon };
