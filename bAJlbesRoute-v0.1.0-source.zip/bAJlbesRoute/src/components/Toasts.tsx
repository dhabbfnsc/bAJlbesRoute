import { AlertCircle, Check, Info, X } from "lucide-react";
import { useStore } from "../store/store";
import { cn } from "../lib/utils";

export function Toasts() {
  const toasts = useStore((s) => s.toasts);
  const dismiss = useStore((s) => s.dismissToast);

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-3 z-[60] flex flex-col items-center gap-2 px-3 sm:bottom-5">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            "message-enter pointer-events-auto flex w-full max-w-md items-start gap-2.5 rounded-2xl border px-3.5 py-2.5 shadow-float glass-strong",
            t.kind === "err"
              ? "border-err/35"
              : t.kind === "ok"
                ? "border-ok/35"
                : "border-line2",
          )}
        >
          <span className="mt-0.5 shrink-0">
            {t.kind === "err" ? (
              <AlertCircle size={15} className="text-err" />
            ) : t.kind === "ok" ? (
              <Check size={15} className="text-ok" />
            ) : (
              <Info size={15} className="text-info" />
            )}
          </span>
          <p className="min-w-0 flex-1 whitespace-pre-line text-[12.5px] leading-relaxed text-ink">{t.text}</p>
          <button
            type="button"
            onClick={() => dismiss(t.id)}
            className="-mr-1 shrink-0 rounded-lg p-1 text-faint hover:text-ink"
            aria-label="Закрыть"
          >
            <X size={13} />
          </button>
        </div>
      ))}
    </div>
  );
}
