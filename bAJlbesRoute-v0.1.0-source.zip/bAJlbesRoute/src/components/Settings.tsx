import { useEffect, useState } from "react";
import {
  BellRing,
  Check,
  Cpu,
  FolderOpen,
  FolderPlus,
  Inbox,
  Info,
  KeyRound,
  LogOut,
  RotateCcw,
  Settings2,
  Sparkles,
  Trash2,
  Wand2,
} from "lucide-react";
import type { Effort, WorkspaceOverview } from "../types";
import { selectCurrentModelInfo, selectCurrentProvider, useStore } from "../store/store";
import { ACCENTS, EFFORT_HINT, EFFORT_LABEL } from "../lib/catalog";
import { bootInfo, isTauri, revealPath, workspaceOverview, quitApp } from "../lib/bridge";
import { chooseDirectory, baseName } from "../lib/files";
import { notifyNow, ensureNotificationPermission } from "../lib/notify";
import { formatBytes, cn } from "../lib/utils";
import { choose } from "../lib/haptics";
import { ProvidersTab } from "./ProvidersTab";
import { ImagineTab } from "./ImagineTab";
import { Logo, Modal, Range, Row, Section, Segmented, Spinner, Switch, Wordmark } from "./ui";

export type SettingsTab = "general" | "providers" | "chat" | "imagine" | "about";

const TABS: { id: SettingsTab; label: string; icon: typeof Settings2 }[] = [
  { id: "general", label: "Основное", icon: Settings2 },
  { id: "providers", label: "Провайдеры", icon: KeyRound },
  { id: "chat", label: "Чат и файлы", icon: FolderOpen },
  { id: "imagine", label: "Imagine", icon: Wand2 },
  { id: "about", label: "О приложении", icon: Info },
];

export function SettingsPanel({
  open,
  onClose,
  initialTab = "general",
}: {
  open: boolean;
  onClose: () => void;
  initialTab?: SettingsTab;
}) {
  const [tab, setTab] = useState<SettingsTab>(initialTab);
  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  return (
    <Modal open={open} onClose={onClose} title="Настройки" subtitle="Всё хранится локально на этом устройстве" size="lg">
      <div className="sticky top-0 z-10 border-b border-line/60 bg-elev/92 px-2 py-2 backdrop-blur">
        <div className="flex gap-1 overflow-x-auto no-scrollbar">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                void choose();
                setTab(id);
              }}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium transition-colors",
                tab === id ? "bg-white/[0.08] text-ink" : "text-muted hover:bg-white/[0.04] hover:text-ink",
              )}
            >
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-3 py-3 sm:px-4">
        {tab === "general" && <GeneralTab />}
        {tab === "providers" && <ProvidersTab />}
        {tab === "chat" && <ChatTab />}
        {tab === "imagine" && <ImagineTab />}
        {tab === "about" && <AboutTab />}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */

function GeneralTab() {
  const settings = useStore((s) => s.settings);
  const patch = useStore((s) => s.patchSettings);
  const toast = useStore((s) => s.toast);
  const boot = useStore((s) => s.boot);
  const isMobile = Boolean(boot?.isMobile);

  return (
    <div>
      <Section title="Внешний вид">
        <div className="px-3 py-3">
          <div className="mb-2 text-[13px] font-medium text-ink">Акцентный цвет</div>
          <div className="flex gap-2">
            {ACCENTS.map((accent) => (
              <button
                key={accent.id}
                type="button"
                onClick={() => {
                  void choose();
                  patch({ accent: accent.id });
                }}
                className={cn(
                  "flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-[11.5px] transition-all",
                  settings.accent === accent.id
                    ? "border-line2 bg-white/[0.06] text-ink"
                    : "border-line text-muted hover:text-ink",
                )}
              >
                <span
                  className="h-3.5 w-3.5 rounded-full"
                  style={{ background: accent.color }}
                />
                {accent.label}
                {settings.accent === accent.id && <Check size={11} className="text-accent" />}
              </button>
            ))}
          </div>
        </div>
        <div className="px-3">
          <Row title="Размер текста" desc="Влияет на сообщения и редактор">
            <Segmented
              value={settings.fontSize}
              onChange={(v) => patch({ fontSize: v })}
              options={[
                { value: "sm", label: "S" },
                { value: "md", label: "M" },
                { value: "lg", label: "L" },
              ]}
            />
          </Row>
        </div>
        <div className="px-3">
          <Row title="Плавные анимации" desc="Отключите, если устройство медленное">
            <Switch checked={settings.animations} onChange={(v) => patch({ animations: v })} />
          </Row>
        </div>
      </Section>

      <Section title="Поведение">
        <div className="px-3">
          <Row
            title="Enter отправляет сообщение"
            desc={isMobile ? "На телефоне отправка — кнопкой" : "Shift+Enter — перенос строки"}
          >
            <Switch checked={settings.sendOnEnter} onChange={(v) => patch({ sendOnEnter: v })} disabled={isMobile} />
          </Row>
        </div>
        <div className="px-3">
          <Row title="Показывать размышления" desc="Блок «Размышления» у reasoning-моделей">
            <Switch checked={settings.showReasoning} onChange={(v) => patch({ showReasoning: v })} />
          </Row>
        </div>
        <div className="px-3">
          <Row
            title="Виброотклик"
            desc={isMobile ? "Тактильная отдача при действиях и ответе модели" : "Работает на Android и iOS"}
          >
            <Switch checked={settings.haptics} onChange={(v) => patch({ haptics: v })} />
          </Row>
        </div>
      </Section>

      <Section title="Уведомления и фон">
        <div className="px-3">
          <Row
            title="Уведомление, когда модель ответила"
            desc={
              isMobile
                ? "Приходит, если приложение свёрнуто"
                : "Приходит, если окно свёрнуто в трей или не в фокусе"
            }
          >
            <Switch
              checked={settings.notifications}
              onChange={async (v) => {
                patch({ notifications: v });
                if (v) {
                  const granted = await ensureNotificationPermission();
                  if (!granted) toast("Разрешите уведомления в системе", "err");
                }
              }}
            />
          </Row>
        </div>
        {settings.notifications && (
          <div className="px-3 py-2">
            <button
              className="btn-soft h-8 px-2.5 text-[11.5px]"
              onClick={async () => {
                const granted = await ensureNotificationPermission();
                if (!granted) {
                  toast("Разрешение не выдано", "err");
                  return;
                }
                await notifyNow("bAJlbesRoute", "Так выглядит уведомление — модель ответила ✓");
                toast("Уведомление отправлено", "ok");
              }}
            >
              <BellRing size={12} /> Проверить уведомление
            </button>
          </div>
        )}
        {!isMobile && (
          <div className="px-3 pb-3">
            <Row
              title="Сворачивать в трей вместо закрытия"
              desc="Ответ модели догенерируется в фоне, а окно можно открыть из иконки в трее"
            >
              <Switch checked={settings.closeToTray} onChange={(v) => patch({ closeToTray: v })} />
            </Row>
          </div>
        )}
        <div className="border-t border-line/60 px-3 py-2.5">
          <p className="flex items-start gap-2 text-[11px] leading-relaxed text-faint">
            <Inbox size={12} className="mt-0.5 shrink-0" />
            {isMobile
              ? "Запрос продолжает выполняться, даже если вы свернули приложение: ответ сохранится в чате, а телефон коротко вибрирует по завершении."
              : "Запрос выполняется в отдельном потоке Rust-ядра: можно свернуть окно в трей, ответ догенерируется, а в системном трее появится уведомление."}
          </p>
        </div>
      </Section>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function WorkspaceSection() {
  const settings = useStore((s) => s.settings);
  const setWorkspace = useStore((s) => s.setWorkspace);
  const boot = useStore((s) => s.boot);
  const toast = useStore((s) => s.toast);
  const [overview, setOverview] = useState<WorkspaceOverview | null>(null);
  const [manual, setManual] = useState(settings.workspace ?? "");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setManual(settings.workspace ?? "");
    if (!settings.workspace || !isTauri()) {
      setOverview(null);
      return;
    }
    let alive = true;
    setLoading(true);
    workspaceOverview(settings.workspace)
      .then((data) => alive && setOverview(data))
      .catch(() => alive && setOverview(null))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [settings.workspace]);

  const pick = async () => {
    void choose();
    const dir = await chooseDirectory();
    if (dir) {
      await setWorkspace(dir);
      toast(`Рабочая папка: ${baseName(dir)}`, "ok");
    } else if (!isTauri()) {
      toast("Выбор папки доступен в приложении", "err");
    }
  };

  return (
    <Section
      title="Рабочая папка"
      desc="Модель сможет читать, создавать и искать файлы только внутри этой папки"
    >
      <div className="px-3 py-3">
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1 rounded-xl border border-line bg-bg/60 px-2.5 py-2">
            <div className="truncate font-mono text-[11.5px] text-ink/90">
              {settings.workspace || "не выбрана"}
            </div>
            {overview?.exists && (
              <div className="mt-0.5 text-[10.5px] text-faint">
                {overview.files} файлов · {formatBytes(overview.size)}
              </div>
            )}
          </div>
          {isTauri() && !boot?.isMobile && (
            <button className="btn-soft h-[42px] px-2.5 text-[11.5px]" onClick={() => void pick()}>
              <FolderOpen size={13} /> Выбрать
            </button>
          )}
          {settings.workspace && (
            <button
              className="btn-ghost h-[42px] px-2 text-err hover:bg-err/10"
              onClick={() => void setWorkspace(null)}
              title="Убрать папку"
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>

        {Boolean(boot?.isMobile) && (
          <div className="mt-2 flex gap-1.5">
            <input
              className="field flex-1 font-mono text-[11.5px]"
              placeholder="Путь вручную: /storage/emulated/0/Documents"
              value={manual}
              onChange={(e) => setManual(e.target.value)}
            />
            <button
              className="btn-soft px-2.5"
              onClick={() => {
                if (manual.trim()) {
                  void setWorkspace(manual.trim());
                  toast("Папка сохранена", "ok");
                }
              }}
            >
              <FolderPlus size={14} />
            </button>
          </div>
        )}

        {loading && (
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-faint">
            <Spinner size={11} /> Сканирую папку…
          </div>
        )}

        {overview?.exists && overview.entries.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {overview.entries.slice(0, 10).map((entry) => (
              <span key={entry} className="chip py-0.5 text-[10.5px]">
                {entry}
              </span>
            ))}
          </div>
        )}

        {settings.workspace && isTauri() && (
          <button
            className="btn-ghost mt-2 h-7 px-2 text-[11px]"
            onClick={() => void revealPath(settings.workspace!)}
          >
            <FolderOpen size={11} /> Открыть папку в проводнике
          </button>
        )}

        <p className="mt-2 text-[10.5px] leading-relaxed text-faint">
          Подсказка: выберите папку, где лежат файлы для работы — например, Documents/Projects. Модель не имеет
          доступа за её пределы.
        </p>
      </div>
    </Section>
  );
}

function ChatTab() {
  const settings = useStore((s) => s.settings);
  const patch = useStore((s) => s.patchSettings);
  const setEffort = useStore((s) => s.setEffort);
  const effort = useStore((s) => s.currentEffort);
  const model = useStore(selectCurrentModelInfo);
  const provider = useStore(selectCurrentProvider);

  return (
    <div>
      <WorkspaceSection />

      <Section title="Инструменты модели" desc="Файловые операции выполняются Rust-ядром локально">
        <div className="px-3">
          <Row
            title="Инструменты файлов"
            desc={
              settings.workspace
                ? "Модель может читать, создавать, искать и изменять файлы в рабочей папке"
                : "Сначала выберите рабочую папку"
            }
          >
            <Switch
              checked={settings.toolsEnabled}
              onChange={(v) => patch({ toolsEnabled: v })}
              disabled={!settings.workspace}
            />
          </Row>
        </div>
      </Section>

      <Section title="Параметры по умолчанию">
        <div className="px-3 py-3">
          <div className="mb-1.5 text-[13px] font-medium text-ink">Усилия модели</div>
          <Segmented
            value={effort}
            onChange={(value: Effort) => setEffort(value)}
            options={(["off", "low", "medium", "high"] as Effort[]).map((value) => ({
              value,
              label: EFFORT_LABEL[value],
            }))}
          />
          <p className="mt-1.5 text-[10.5px] text-faint">{EFFORT_HINT[effort]}</p>
        </div>

        <div className="border-t border-line/60 px-3 py-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[13px] font-medium text-ink">Температура</span>
            <span className="text-[11px] tabular-nums text-muted">{settings.temperature.toFixed(2)}</span>
          </div>
          <Range
            min={0}
            max={2}
            step={0.05}
            value={settings.temperature}
            onChange={(v) => patch({ temperature: v })}
            format={() => ""}
          />
          <p className="mt-1.5 text-[10.5px] text-faint">
            Не отправляется reasoning-моделям. 0 — точнее, 1+ — креативнее.
          </p>
        </div>

        <div className="border-t border-line/60 px-3 py-3">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[13px] font-medium text-ink">Лимит токенов ответа</span>
            <button
              className="text-[10.5px] text-accent-soft hover:underline"
              onClick={() => patch({ maxTokens: settings.maxTokens ? null : 4096 })}
            >
              {settings.maxTokens ? "сделать авто" : "задать вручную"}
            </button>
          </div>
          {settings.maxTokens ? (
            <input
              type="number"
              className="field w-32 tabular-nums"
              value={settings.maxTokens}
              min={64}
              step={64}
              onChange={(e) => patch({ maxTokens: Math.max(64, Number(e.target.value) || 64) })}
            />
          ) : (
            <p className="text-[11.5px] text-muted">Авто — провайдер сам решит (рекомендуется).</p>
          )}
        </div>
      </Section>

      <Section
        title="Системная инструкция"
        desc="Добавляется к автоматическому описанию окружения, модели и рабочей папки"
      >
        <div className="px-3 py-3">
          <textarea
            className="field min-h-[120px] resize-y leading-relaxed"
            placeholder="Например: отвечай кратко, люби код на Rust, обращайся ко мне по имени…"
            value={settings.systemPromptExtra}
            onChange={(e) => patch({ systemPromptExtra: e.target.value })}
          />
          <div className="mt-2 rounded-xl border border-line/70 bg-panel/40 px-2.5 py-2">
            <div className="label mb-1">Что модель знает о себе</div>
            <div className="space-y-0.5 text-[11px] text-muted">
              <div>
                <span className="text-faint">Модель:</span> {model?.label ?? "—"}{" "}
                {provider ? `(${provider.name})` : ""}
              </div>
              <div>
                <span className="text-faint">Окружение:</span> платформа, ОС, устройство, папка данных, время
              </div>
              <div>
                <span className="text-faint">Файлы:</span>{" "}
                {settings.toolsEnabled && settings.workspace ? "доступны инструменты" : "недоступны"}
              </div>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function AboutTab() {
  const boot = useStore((s) => s.boot);
  const settings = useStore((s) => s.settings);
  const patch = useStore((s) => s.patchSettings);
  const clearAllChats = useStore((s) => s.clearAllChats);
  const toast = useStore((s) => s.toast);
  const [env, setEnv] = useState(boot);

  useEffect(() => {
    if (!boot) void bootInfo().then(setEnv).catch(() => {});
  }, [boot]);

  const rows: [string, string][] = [
    ["Версия", env?.appVersion ?? "0.1.0"],
    ["Платформа", `${env?.platformLabel ?? "—"} · ${env?.arch ?? ""}`],
    ["ОС", env?.osVersion || "—"],
    ["Устройство", env?.deviceName || "—"],
    ["WebView", env?.webview || "—"],
    ["Данные", env?.dataDir || "—"],
    ["Медиа", env?.mediaDir || "—"],
  ];

  return (
    <div>
      <div className="mb-4 flex items-center gap-3 rounded-2xl border border-line bg-panel/60 px-3.5 py-3">
        <Logo size={38} />
        <div>
          <div className="text-[15px] font-semibold">
            <Wordmark />
          </div>
          <div className="text-[11px] text-muted">Ваш AI-маршрут · v{env?.appVersion ?? "0.1.0"}</div>
        </div>
        <Sparkles className="ml-auto text-accent/60" size={18} />
      </div>

      <Section title="Окружение" desc="Эти данные получает модель в системной инструкции">
        <div className="px-3 py-1">
          {rows.map(([label, value]) => (
            <div key={label} className="flex gap-3 border-b border-line/50 py-1.5 last:border-0">
              <span className="w-24 shrink-0 text-[11.5px] text-faint">{label}</span>
              <span className="min-w-0 flex-1 break-all font-mono text-[11px] text-muted">{value}</span>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Приватность">
        <div className="px-3 py-3">
          <p className="text-[11.5px] leading-relaxed text-muted">
            Ключи, чаты и настройки лежат в локальном файле <code className="text-accent-soft">state.json</code>{" "}
            в папке данных приложения. Запросы отправляются напрямую вашему провайдеру, минуя любые
            промежуточные серверы. Медиа хранится в папке <code className="text-accent-soft">media</code>.
          </p>
        </div>
      </Section>

      <Section title="Действия">
        <div className="flex flex-wrap gap-1.5 px-3 py-3">
          <button
            className="btn-soft h-8 px-2.5 text-[11.5px]"
            onClick={() => void patch({ onboarded: false })}
          >
            <RotateCcw size={12} /> Показать обучение заново
          </button>
          <button
            className="btn-soft h-8 px-2.5 text-[11.5px]"
            onClick={() => {
              clearAllChats();
              toast("Все чаты удалены", "ok");
            }}
          >
            <Trash2 size={12} /> Удалить все чаты
          </button>
          {env && isTauri() && env.dataDir && (
            <button
              className="btn-soft h-8 px-2.5 text-[11.5px]"
              onClick={() => void revealPath(env.dataDir)}
            >
              <FolderOpen size={12} /> Папка данных
            </button>
          )}
          {!env?.isMobile && isTauri() && (
            <button
              className="btn-danger h-8 px-2.5 text-[11.5px]"
              onClick={() => void quitApp()}
            >
              <LogOut size={12} /> Выйти
            </button>
          )}
        </div>
      </Section>

      {!isTauri() && (
        <p className="mb-2 flex items-start gap-2 rounded-xl border border-warn/25 bg-warn/[0.06] px-3 py-2 text-[11px] leading-relaxed text-warn">
          <Cpu size={12} className="mt-0.5 shrink-0" />
          Открыто веб-превью без Rust-ядра: чат работает в демо-режиме. Соберите приложение
          (<span className="font-mono">npm run tauri dev</span>), чтобы подключить реальные API.
        </p>
      )}

      <div className="mt-3 flex items-center justify-center gap-2 pb-2 text-[10.5px] text-faint">
        <span>Сделано с вниманием к деталям · {new Date().getFullYear()}</span>
      </div>
      <span className="hidden">{settings.haptics ? "" : ""}</span>
    </div>
  );
}
