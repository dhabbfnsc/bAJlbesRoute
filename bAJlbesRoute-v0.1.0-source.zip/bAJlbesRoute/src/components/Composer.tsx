import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUp,
  ChevronDown,
  Cpu,
  FolderPlus,
  Gauge,
  ImagePlus,
  Paperclip,
  ShieldCheck,
  Square,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import type { Attachment, Effort } from "../types";
import { selectActiveChat, selectCurrentModelInfo, selectCurrentProvider, useStore } from "../store/store";
import { EFFORT_HINT, EFFORT_LABEL } from "../lib/catalog";
import { cn, estimateTokens, formatBytes, uid } from "../lib/utils";
import { choose, tap } from "../lib/haptics";
import { isTauri } from "../lib/bridge";
import { Spinner } from "./ui";

const MAX_ATTACHMENTS = 8;

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function Composer({
  draft,
  onDraftChange,
  onOpenModelPicker,
  onOpenSettings,
}: {
  draft: string;
  onDraftChange: (value: string) => void;
  onOpenModelPicker: () => void;
  onOpenSettings: (tab?: string) => void;
}) {
  const chat = useStore(selectActiveChat);
  const run = useStore((s) => (chat ? s.runs[chat.id] : undefined));
  const send = useStore((s) => s.send);
  const stop = useStore((s) => s.stop);
  const settings = useStore((s) => s.settings);
  const effort = useStore((s) => s.currentEffort);
  const setEffort = useStore((s) => s.setEffort);
  const model = useStore(selectCurrentModelInfo);
  const provider = useStore(selectCurrentProvider);
  const boot = useStore((s) => s.boot);
  const toast = useStore((s) => s.toast);

  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [effortOpen, setEffortOpen] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const effortRef = useRef<HTMLDivElement>(null);

  const isMobile = Boolean(boot?.isMobile);
  const running = Boolean(run);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [draft]);

  useEffect(() => {
    if (!run) {
      setElapsed(0);
      return;
    }
    const timer = window.setInterval(() => {
      setElapsed(Math.floor((Date.now() - run.startedAt) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [run]);

  useEffect(() => {
    if (!effortOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!effortRef.current?.contains(e.target as Node)) setEffortOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [effortOpen]);

  const contextInfo = useMemo(() => {
    const used = (chat?.messages ?? []).reduce((acc, m) => acc + estimateTokens(m.text), 0) + estimateTokens(draft);
    const max = model?.context ?? 0;
    return { used, max, ratio: max ? Math.min(1, used / max) : 0 };
  }, [chat?.messages, draft, model?.context]);

  const canSend = draft.trim().length > 0 || attachments.length > 0;

  const doSend = () => {
    if (!canSend || running) return;
    void tap();
    const toSend = attachments;
    onDraftChange("");
    setAttachments([]);
    void send(draft, toSend);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      doSend();
      return;
    }
    if (e.key === "Enter" && !e.shiftKey && settings.sendOnEnter && !isMobile) {
      e.preventDefault();
      doSend();
    }
    if (e.key === "Escape" && running && chat) {
      e.preventDefault();
      void stop(chat.id);
    }
  };

  const addFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    const next: Attachment[] = [];
    for (const file of Array.from(files).slice(0, MAX_ATTACHMENTS - attachments.length)) {
      try {
        if (file.type.startsWith("image/")) {
          const dataUrl = await readAsDataUrl(file);
          next.push({
            id: uid("att"),
            name: file.name,
            mime: file.type || "image/png",
            size: file.size,
            kind: "image",
            dataUrl,
          });
        } else if (file.size <= 500_000) {
          const text = await file.text();
          next.push({
            id: uid("att"),
            name: file.name,
            mime: file.type || "text/plain",
            size: file.size,
            kind: "file",
            text,
          });
        } else {
          toast(`«${file.name}» больше 500 КБ — положите его в рабочую папку`, "err");
        }
      } catch {
        toast(`Не удалось прочитать «${file.name}»`, "err");
      }
    }
    if (next.length) setAttachments((prev) => [...prev, ...next].slice(0, MAX_ATTACHMENTS));
    if (fileRef.current) fileRef.current.value = "";
  };

  const modelLabel = model?.label ?? "Выбрать модель";
  const workspaceName = settings.workspace ? settings.workspace.split(/[\\/]/).filter(Boolean).pop() : null;

  return (
    <div className="border-t border-line/60 px-2 pb-[max(env(safe-area-inset-bottom),10px)] pt-2.5 sm:px-4">
      <div className="mx-auto w-full max-w-3xl">
        <div
          className={cn(
            "relative rounded-2xl border bg-elev/80 transition-all duration-200",
            running ? "border-accent/40 shadow-glow" : "border-line focus-within:border-line2",
          )}
        >
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 px-3 pt-2.5">
              {attachments.map((a) => (
                <div key={a.id} className="group relative">
                  {a.kind === "image" && a.dataUrl ? (
                    <img src={a.dataUrl} alt={a.name} className="h-14 w-14 rounded-lg border border-line object-cover" />
                  ) : (
                    <div className="flex h-14 max-w-[180px] items-center gap-1.5 rounded-lg border border-line bg-panel px-2">
                      <Paperclip size={12} className="shrink-0 text-faint" />
                      <div className="min-w-0">
                        <div className="truncate text-[10.5px] text-muted">{a.name}</div>
                        <div className="text-[9.5px] text-faint">{formatBytes(a.size)}</div>
                      </div>
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => setAttachments((prev) => prev.filter((x) => x.id !== a.id))}
                    className="absolute -right-1.5 -top-1.5 rounded-full border border-line bg-bg p-0.5 text-muted hover:text-err"
                  >
                    <X size={10} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <textarea
            ref={textareaRef}
            value={draft}
            onChange={(e) => onDraftChange(e.target.value)}
            onKeyDown={onKeyDown}
            rows={1}
            placeholder={
              model ? `Спросите ${model.label}…` : "Сначала выберите модель…"
            }
            className="block max-h-[220px] w-full resize-none bg-transparent px-3.5 pb-1 pt-3 text-[14.5px] leading-relaxed text-ink placeholder:text-faint outline-none"
          />

          <div className="flex items-center gap-1 px-2 pb-2 pt-1">
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="image/*,text/*,.md,.markdown,.json,.csv,.ts,.tsx,.js,.jsx,.py,.rs,.go,.java,.c,.cpp,.h,.html,.css,.yml,.yaml,.toml,.sh,.sql,.log,.txt"
              className="hidden"
              onChange={(e) => void addFiles(e.target.files)}
            />
            <button
              type="button"
              className="icon-btn h-8 w-8"
              title="Прикрепить файлы"
              onClick={() => {
                void choose();
                fileRef.current?.click();
              }}
              disabled={running}
            >
              <Paperclip size={15} />
            </button>

            {/* Модель */}
            <button
              type="button"
              onClick={() => {
                void choose();
                onOpenModelPicker();
              }}
              className={cn(
                "flex h-8 min-w-0 items-center gap-1.5 rounded-lg border px-2 text-[11.5px] transition-colors",
                model
                  ? "border-line bg-panel text-ink hover:border-line2"
                  : "border-accent/40 bg-accent/10 text-accent-soft",
              )}
            >
              <Cpu size={12} className="shrink-0 text-accent-soft" />
              <span className="max-w-[130px] truncate font-medium sm:max-w-[220px]">{modelLabel}</span>
              <ChevronDown size={11} className="shrink-0 text-faint" />
            </button>

            {/* Усилия */}
            <div className="relative" ref={effortRef}>
              <button
                type="button"
                onClick={() => {
                  void choose();
                  setEffortOpen((v) => !v);
                }}
                className={cn(
                  "flex h-8 items-center gap-1 rounded-lg border px-2 text-[11.5px] transition-colors",
                  effort === "off"
                    ? "border-line bg-panel text-muted hover:border-line2"
                    : "border-line bg-panel text-ink hover:border-line2",
                )}
                title="Усилия модели"
              >
                {effort === "off" ? <Zap size={11} className="text-faint" /> : <Gauge size={12} className="text-accent-soft" />}
                <span className="hidden font-medium sm:inline">{EFFORT_LABEL[effort]}</span>
                <ChevronDown size={11} className="text-faint" />
              </button>
              {effortOpen && (
                <div className="modal-enter absolute bottom-10 left-0 z-30 w-60 overflow-hidden rounded-xl border border-line2 bg-elev shadow-float">
                  <div className="border-b border-line/70 px-3 py-2">
                    <div className="text-[11px] font-semibold text-ink">Усилия модели</div>
                    <div className="text-[10.5px] text-faint">Насколько глубоко модель рассуждает</div>
                  </div>
                  {(["off", "low", "medium", "high"] as Effort[]).map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => {
                        void choose();
                        setEffort(value);
                        setEffortOpen(false);
                      }}
                      className={cn(
                        "flex w-full items-start gap-2 px-3 py-2 text-left transition-colors hover:bg-white/[0.05]",
                        effort === value && "bg-white/[0.04]",
                      )}
                    >
                      <span
                        className={cn(
                          "mt-1 h-1.5 w-1.5 shrink-0 rounded-full",
                          effort === value ? "bg-accent" : "bg-line2",
                        )}
                      />
                      <span className="min-w-0">
                        <span className="block text-[12px] font-medium text-ink">{EFFORT_LABEL[value]}</span>
                        <span className="block text-[10.5px] leading-snug text-faint">{EFFORT_HINT[value]}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Папка */}
            <button
              type="button"
              onClick={() => {
                void choose();
                onOpenSettings("chat");
              }}
              className={cn(
                "hidden h-8 items-center gap-1 rounded-lg border px-2 text-[11.5px] transition-colors sm:flex",
                workspaceName
                  ? "border-line bg-panel text-muted hover:border-line2 hover:text-ink"
                  : "border-warn/30 bg-warn/[0.07] text-warn hover:bg-warn/[0.12]",
              )}
              title={settings.workspace ?? "Выбрать рабочую папку"}
            >
              {workspaceName ? <Wrench size={11} /> : <FolderPlus size={12} />}
              <span className="max-w-[110px] truncate">{workspaceName ?? "Папка"}</span>
            </button>

            <div className="ml-auto flex items-center gap-2">
              <div className="hidden items-center gap-1.5 text-[10px] tabular-nums text-faint md:flex" title="Приблизительный размер контекста">
                <span
                  className={cn(
                    "h-1 w-10 overflow-hidden rounded-full bg-line2",
                    contextInfo.ratio > 0.9 && "bg-err/30",
                  )}
                >
                  <span
                    className={cn("block h-full rounded-full", contextInfo.ratio > 0.9 ? "bg-err" : "bg-accent/80")}
                    style={{ width: `${Math.max(4, contextInfo.ratio * 100)}%` }}
                  />
                </span>
                <span>
                  ~{contextInfo.used > 999 ? `${(contextInfo.used / 1000).toFixed(1)}k` : contextInfo.used}
                  {contextInfo.max ? ` / ${(contextInfo.max / 1000).toFixed(0)}k` : ""}
                </span>
              </div>

              {running ? (
                <div className="flex items-center gap-2">
                  <span className="hidden items-center gap-1.5 text-[10.5px] tabular-nums text-muted sm:flex">
                    <Spinner size={11} /> {elapsed} с
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      void choose();
                      if (chat) void stop(chat.id);
                    }}
                    className="flex h-8 items-center gap-1.5 rounded-lg border border-line2 bg-raised px-2.5 text-[12px] font-medium text-ink hover:border-err/50 hover:text-err"
                    title="Остановить"
                  >
                    <Square size={11} fill="currentColor" /> Стоп
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={doSend}
                  disabled={!canSend}
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-lg transition-all",
                    canSend ? "text-white active:scale-95" : "bg-raised text-faint",
                  )}
                  style={
                    canSend
                      ? { background: "linear-gradient(180deg, rgb(var(--accent)), rgb(var(--accent-deep)))" }
                      : undefined
                  }
                  title="Отправить"
                >
                  {isTauri() && provider && !provider.apiKey.trim() && !provider.baseUrl.includes("localhost") && !provider.baseUrl.includes("127.0.0.1") ? (
                    <ShieldCheck size={15} />
                  ) : (
                    <ArrowUp size={16} />
                  )}
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="mt-1 flex items-center justify-between gap-3 px-1 text-[10px] text-faint">
          <span className="truncate">
            {isMobile
              ? "Enter — перенос строки"
              : settings.sendOnEnter
                ? "Enter — отправить · Shift+Enter — перенос"
                : "Ctrl+Enter — отправить"}
            {provider ? ` · ${provider.name}` : ""}
          </span>
          <span className="flex shrink-0 items-center gap-1">
            <ImagePlus size={10} />
            {isMobile ? "виброотклик вкл" : settings.closeToTray ? "фон и уведомления вкл" : "фон выкл"}
          </span>
        </div>
      </div>
    </div>
  );
}
