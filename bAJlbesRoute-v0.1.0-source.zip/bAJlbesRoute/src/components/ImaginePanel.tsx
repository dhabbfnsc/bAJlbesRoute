import { useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  Film,
  FolderOpen,
  Image as ImageIcon,
  ImagePlus,
  Loader2,
  Settings2,
  Sparkles,
  Trash2,
  Wand2,
  X,
} from "lucide-react";
import { useStore } from "../store/store";
import { isTauri, mediaCopy, revealPath } from "../lib/bridge";
import { assetUrl } from "../lib/assets";
import { chooseSaveDirectory } from "../lib/files";
import { downloadDataUrl, formatBytes, cn, timeAgo } from "../lib/utils";
import { choose, tap } from "../lib/haptics";
import { Badge, Modal, Spinner } from "./ui";

const ASPECTS = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"];

export function ImaginePanel({
  open,
  onClose,
  onOpenSettings,
}: {
  open: boolean;
  onClose: () => void;
  onOpenSettings: (tab?: string) => void;
}) {
  const settings = useStore((s) => s.settings);
  const items = useStore((s) => s.imagineItems);
  const running = useStore((s) => s.imagineRunning);
  const logs = useStore((s) => s.imagineLogs);
  const error = useStore((s) => s.imagineError);
  const result = useStore((s) => s.imagineResult);
  const generate = useStore((s) => s.imagineGenerate);
  const cancel = useStore((s) => s.imagineCancel);
  const removeItem = useStore((s) => s.imagineDelete);
  const toast = useStore((s) => s.toast);
  const patchImagine = useStore((s) => s.patchImagine);

  const [mode, setMode] = useState<"image" | "video">("image");
  const [prompt, setPrompt] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [aspect, setAspect] = useState(settings.imagine.aspect);
  const [elapsed, setElapsed] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!running) {
      setElapsed(0);
      return;
    }
    const started = Date.now();
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [running]);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [logs.length]);

  const sources = useMemo(() => {
    const list: { label: string; ok: boolean }[] = [];
    const imagine = settings.imagine;
    const openai = settings.providers.find((p) => p.preset === "openai" && p.apiKey.trim());
    const google = settings.providers.find((p) => p.preset === "google" && p.apiKey.trim());
    if (openai) list.push({ label: "OpenAI", ok: true });
    if (imagine.fal.trim()) list.push({ label: "fal.ai", ok: true });
    if (imagine.replicate.trim()) list.push({ label: "Replicate", ok: true });
    if (imagine.together.trim()) list.push({ label: "Together", ok: true });
    if (imagine.stability.trim()) list.push({ label: "Stability", ok: true });
    if (imagine.pollinations) list.push({ label: "Pollinations", ok: true });
    if (imagine.googleKey.trim() || (imagine.useProviderKeyForGoogle && google)) list.push({ label: "Veo", ok: true });
    imagine.customImages
      .filter((c) => c.baseUrl.trim())
      .forEach((c) => list.push({ label: c.name || "custom", ok: true }));
    if (!list.length) list.push({ label: "нет источников", ok: false });
    return list;
  }, [settings]);

  const pickImage = () => fileRef.current?.click();

  const onFile = async (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImage(String(reader.result));
    reader.readAsDataURL(file);
  };

  const start = () => {
    if (!prompt.trim() && !image) {
      toast("Опишите, что сгенерировать", "err");
      return;
    }
    void tap();
    patchImagine({ aspect });
    void generate({ mode, prompt, image, aspect });
  };

  const saveResult = async (item: typeof result) => {
    if (!item) return;
    if (item.dataUrl && !isTauri()) {
      downloadDataUrl(item.dataUrl, `imagine-${item.id}.png`);
      return;
    }
    if (!isTauri()) return;
    const dir = await chooseSaveDirectory();
    if (!dir) return;
    try {
      const target = await mediaCopy(item.path, dir);
      toast(`Сохранено: ${target}`, "ok");
    } catch (err) {
      toast(err instanceof Error ? err.message : String(err), "err");
    }
  };

  const previewSrc = result ? assetUrl(result.path, result.dataUrl ?? null) : undefined;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={
        <span className="flex items-center gap-2">
          <span
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ background: "linear-gradient(180deg, rgb(var(--accent)), rgb(var(--accent-deep)))" }}
          >
            <Sparkles size={13} className="text-white" />
          </span>
          imagine
        </span>
      }
      subtitle="Фото, видео и анимация. Модель не выбирается — работает первый успешный источник."
      size="full"
      headerRight={
        <button className="btn-ghost h-8 px-2 text-[11.5px]" onClick={() => onOpenSettings("imagine")}>
          <Settings2 size={13} /> Источники
        </button>
      }
    >
      <div className="grid gap-4 p-3 sm:grid-cols-[minmax(0,320px)_minmax(0,1fr)] sm:p-4">
        {/* Левая колонка: управление */}
        <div className="space-y-3">
          <div className="flex rounded-xl border border-line bg-panel p-0.5">
            {(
              [
                { id: "image" as const, label: "Фото", icon: ImageIcon },
                { id: "video" as const, label: "Видео", icon: Film },
              ]
            ).map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  void choose();
                  setMode(id);
                }}
                className={cn(
                  "flex flex-1 items-center justify-center gap-1.5 rounded-[10px] py-1.5 text-[12.5px] font-medium transition-colors",
                  mode === id ? "bg-raised text-ink" : "text-muted hover:text-ink",
                )}
              >
                <Icon size={13} /> {label}
              </button>
            ))}
          </div>

          <div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder={
                mode === "image"
                  ? "Опишите изображение: сюжет, стиль, свет, настроение…"
                  : "Опишите движение в кадре: что происходит, как движется камера…"
              }
              className="field min-h-[104px] resize-y leading-relaxed"
            />
          </div>

          <div>
            <div className="mb-1.5 flex items-center justify-between">
              <span className="label">Кадр (для анимации фото)</span>
              {image && (
                <button className="text-[10.5px] text-err hover:underline" onClick={() => setImage(null)}>
                  убрать
                </button>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
            {image ? (
              <button type="button" onClick={pickImage} className="relative block w-full">
                <img src={image} alt="кадр" className="max-h-36 w-full rounded-xl border border-line object-cover" />
                <span className="absolute bottom-1.5 right-1.5 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] text-white">
                  заменить
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={pickImage}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-line2 px-3 py-3 text-[11.5px] text-muted transition-colors hover:border-accent/40 hover:text-ink"
              >
                <ImagePlus size={14} /> Загрузить фото для анимации
              </button>
            )}
          </div>

          <div>
            <div className="label mb-1.5">Формат</div>
            <div className="flex flex-wrap gap-1">
              {ASPECTS.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAspect(value)}
                  className={cn("chip py-0.5 text-[10.5px]", aspect === value && "chip-active")}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-1">
            {sources.map((source) => (
              <span
                key={source.label}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[10px]",
                  source.ok ? "border-line bg-panel text-muted" : "border-err/30 bg-err/10 text-err",
                )}
              >
                <span className={cn("h-1 w-1 rounded-full", source.ok ? "bg-ok" : "bg-err")} />
                {source.label}
              </span>
            ))}
          </div>

          {running ? (
            <button type="button" className="btn-soft w-full" onClick={() => cancel()}>
              <X size={14} /> Отменить · {elapsed} с
            </button>
          ) : (
            <button type="button" className="btn-primary w-full py-2.5" onClick={start}>
              <Wand2 size={15} /> Сгенерировать
            </button>
          )}

          {logs.length > 0 && (
            <div
              ref={logRef}
              className="max-h-36 overflow-y-auto rounded-xl border border-line/70 bg-black/20 px-2 py-1.5"
            >
              {logs.map((log) => (
                <div key={log.id} className="flex items-start gap-1.5 py-0.5 text-[10.5px] leading-snug">
                  <span
                    className={cn(
                      "mt-1 h-1 w-1 shrink-0 rounded-full",
                      log.level === "err" ? "bg-err" : log.level === "ok" ? "bg-ok" : "bg-info",
                    )}
                  />
                  <span className={cn("min-w-0 flex-1 break-words", log.level === "err" ? "text-err/80" : "text-muted")}>
                    {log.text}
                  </span>
                </div>
              ))}
              {running && (
                <div className="flex items-center gap-1.5 py-1 text-[10.5px] text-faint">
                  <Spinner size={10} /> Ждём первый успешный ответ…
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="whitespace-pre-line rounded-xl border border-err/30 bg-err/[0.07] px-2.5 py-2 text-[11px] leading-relaxed text-err/85">
              {error}
            </div>
          )}
        </div>

        {/* Правая колонка: превью и галерея */}
        <div className="min-w-0">
          {running && !result && (
            <div className="flex aspect-square w-full max-w-xl animate-pulseSoft flex-col items-center justify-center rounded-2xl border border-line bg-panel/40">
              <Loader2 size={26} className="animate-spin text-accent" />
              <p className="mt-3 text-[12px] text-muted">Генерирую… источники соревнуются</p>
              <p className="mt-1 text-[10.5px] text-faint">{elapsed} с</p>
            </div>
          )}

          {!running && !result && (
            <div className="flex aspect-square w-full max-w-xl flex-col items-center justify-center rounded-2xl border border-dashed border-line bg-panel/30 px-6 text-center">
              <Sparkles size={22} className="mb-2 text-accent/60" />
              <p className="text-[12.5px] text-muted">Здесь появится результат</p>
              <p className="mt-1 max-w-xs text-[10.5px] leading-relaxed text-faint">
                Одновременно запускаются все подключённые источники, побеждает первый ответ без ошибки —
                остальные отменяются.
              </p>
            </div>
          )}

          {result && (
            <div className="overflow-hidden rounded-2xl border border-line bg-black/30">
              {result.kind === "video" ? (
                <video src={previewSrc} controls autoPlay loop className="max-h-[52vh] w-full object-contain" />
              ) : (
                <img src={previewSrc} alt={result.prompt} className="max-h-[52vh] w-full object-contain" />
              )}
              <div className="flex flex-wrap items-center gap-2 border-t border-line/70 px-2.5 py-2">
                <Badge tone="accent">{result.provider}</Badge>
                <span className="text-[10.5px] text-faint">{timeAgo(result.createdAt)}</span>
                <div className="ml-auto flex items-center gap-1">
                  <button className="btn-ghost h-7 px-2 text-[11px]" title="Сохранить файл" onClick={() => void saveResult(result)}>
                    <Download size={12} /> Сохранить
                  </button>
                  {isTauri() && result.path && (
                    <button
                      className="btn-ghost h-7 px-2 text-[11px]"
                      title="Открыть папку с файлом"
                      onClick={() => {
                        const dir = result.path.replace(/[\\/][^\\/]+$/, "");
                        void revealPath(dir);
                      }}
                    >
                      <FolderOpen size={12} /> Папка
                    </button>
                  )}
                  <button
                    className="btn-ghost h-7 px-2 text-[11px] text-err hover:bg-err/10"
                    title="Удалить из галереи"
                    onClick={() => removeItem(result.id)}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
              <div className="border-t border-line/60 px-2.5 py-1.5">
                <p className="line-clamp-2 text-[10.5px] leading-snug text-faint">{result.prompt}</p>
              </div>
            </div>
          )}

          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="label">Галерея ({items.length})</span>
              {items.length > 0 && (
                <span className="text-[10px] text-faint">
                  {formatBytes(items.reduce((acc, item) => acc + (item.dataUrl?.length ?? 0) * 0.75, 0))}
                </span>
              )}
            </div>
            {items.length === 0 ? (
              <p className="rounded-xl border border-line/60 bg-panel/30 px-3 py-4 text-center text-[11px] text-faint">
                Пока пусто. Сгенерируйте первое изображение — оно сохранится в локальную папку media.
              </p>
            ) : (
              <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-4">
                {items.map((item) => {
                  const src = assetUrl(item.path, item.dataUrl ?? null);
                  return (
                    <div key={item.id} className="group relative aspect-square overflow-hidden rounded-xl border border-line">
                      {item.kind === "video" ? (
                        <video src={src} muted className="h-full w-full object-cover" />
                      ) : (
                        <img src={src} alt={item.prompt} className="h-full w-full object-cover" />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                      <button
                        className="absolute right-1 top-1 rounded-md bg-black/60 p-1 text-white/80 opacity-0 transition-opacity hover:text-err group-hover:opacity-100"
                        onClick={() => removeItem(item.id)}
                        title="Удалить"
                      >
                        <Trash2 size={11} />
                      </button>
                      <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1 py-0.5 text-[9px] text-white/80 opacity-0 transition-opacity group-hover:opacity-100">
                        {item.provider}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
}
