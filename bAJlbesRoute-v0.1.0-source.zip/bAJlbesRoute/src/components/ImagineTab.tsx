import { Plus, Trash2 } from "lucide-react";
import { useStore } from "../store/store";
import { Row, Segmented, Switch } from "./ui";

const ASPECTS = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"];

export function ImagineTab() {
  const imagine = useStore((s) => s.settings.imagine);
  const patch = useStore((s) => s.patchImagine);
  const providers = useStore((s) => s.settings.providers);
  const openaiKey = providers.find((p) => p.preset === "openai")?.apiKey ?? "";
  const googleKey = providers.find((p) => p.preset === "google")?.apiKey ?? "";

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-accent/25 bg-accent/[0.06] px-3 py-2.5">
        <p className="text-[11.5px] leading-relaxed text-muted">
          <span className="font-semibold text-accent-soft">Принцип работы:</span> модель не выбирается вручную.
          Imagine запускает все доступные источники параллельно и берёт первый ответ без ошибки. Остальные
          попытки отменяются — это видно в журнале генерации.
        </p>
      </div>

      <div>
        <div className="label mb-1.5">Формат по умолчанию</div>
        <div className="flex flex-wrap gap-1.5">
          {ASPECTS.map((aspect) => (
            <button
              key={aspect}
              type="button"
              onClick={() => patch({ aspect })}
              className={
                imagine.aspect === aspect
                  ? "chip chip-active"
                  : "chip hover:border-line2 hover:text-ink"
              }
            >
              {aspect}
            </button>
          ))}
        </div>
      </div>

      <div className="card divide-y divide-line/70">
        <div className="px-3">
          <Row
            title="Pollinations"
            desc="Бесплатный источник без ключа — работает всегда, хорош как резерв."
          >
            <Switch checked={imagine.pollinations} onChange={(v) => patch({ pollinations: v })} />
          </Row>
        </div>
        <div className="px-3">
          <Row
            title="OpenAI Images"
            desc={
              openaiKey
                ? "Используется ключ провайдера OpenAI из вкладки «Провайдеры»."
                : "Добавьте ключ OpenAI в «Провайдерах», чтобы включить gpt-image."
            }
          >
            <input
              className="field w-[170px] font-mono text-[12px]"
              value={imagine.openaiModel}
              placeholder="gpt-image-1"
              onChange={(e) => patch({ openaiModel: e.target.value })}
            />
          </Row>
        </div>
        <div className="px-3">
          <Row
            title="Google Veo"
            desc={
              googleKey
                ? "Видео Veo через ключ Gemini из «Провайдеров»."
                : "Нужен ключ Google AI Studio (Gemini)."
            }
          >
            <Switch
              checked={imagine.useProviderKeyForGoogle}
              onChange={(v) => patch({ useProviderKeyForGoogle: v })}
            />
          </Row>
        </div>
        {!imagine.useProviderKeyForGoogle && (
          <div className="px-3 py-2.5">
            <input
              className="field font-mono text-[12px]"
              value={imagine.googleKey}
              placeholder="Отдельный ключ Google (AIza…)"
              onChange={(e) => patch({ googleKey: e.target.value.trim() })}
            />
          </div>
        )}
      </div>

      <div>
        <div className="label mb-1.5">Ключи источников</div>
        <div className="space-y-2">
          {(
            [
              ["fal", "fal.ai", "Key из dashboard.fal.ai — изображения FLUX и видео LTX"],
              ["replicate", "Replicate", "r8_… — изображения и видео (Wan 2.2)"],
              ["together", "Together AI", "FLUX.1 schnell — быстрые изображения"],
              ["stability", "Stability AI", "Stable Image Core"],
            ] as const
          ).map(([key, label, hint]) => (
            <label key={key} className="block">
              <span className="mb-1 flex items-center justify-between">
                <span className="text-[12px] font-medium text-muted">{label}</span>
                <span className="text-[10px] text-faint">{imagine[key] ? "подключено" : "не задан"}</span>
              </span>
              <input
                className="field font-mono text-[12px]"
                type="password"
                value={imagine[key]}
                placeholder={hint}
                onChange={(e) => patch({ [key]: e.target.value.trim() } as never)}
                spellCheck={false}
              />
            </label>
          ))}
        </div>
      </div>

      <div>
        <div className="label mb-1.5">Replicate: модели видео</div>
        <div className="space-y-2">
          <input
            className="field font-mono text-[12px]"
            value={imagine.replicateT2V}
            placeholder="текст → видео"
            onChange={(e) => patch({ replicateT2V: e.target.value.trim() })}
          />
          <input
            className="field font-mono text-[12px]"
            value={imagine.replicateI2V}
            placeholder="фото → видео"
            onChange={(e) => patch({ replicateI2V: e.target.value.trim() })}
          />
        </div>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between">
          <div className="label">Свои источники изображений</div>
          <button
            className="btn-ghost h-7 px-2 text-[11px]"
            onClick={() =>
              patch({
                customImages: [
                  ...imagine.customImages,
                  { name: `Источник ${imagine.customImages.length + 1}`, baseUrl: "", apiKey: "", model: "" },
                ],
              })
            }
          >
            <Plus size={12} /> Добавить
          </button>
        </div>
        <p className="mb-2 text-[11px] leading-relaxed text-faint">
          Любой OpenAI-совместимый endpoint с <code className="text-accent-soft">/images/generations</code>.
        </p>
        <div className="space-y-2">
          {imagine.customImages.map((endpoint, index) => (
            <div key={index} className="card space-y-1.5 p-2.5">
              <div className="flex gap-1.5">
                <input
                  className="field flex-1 text-[12px]"
                  value={endpoint.name}
                  placeholder="Название"
                  onChange={(e) => {
                    const list = [...imagine.customImages];
                    list[index] = { ...endpoint, name: e.target.value };
                    patch({ customImages: list });
                  }}
                />
                <button
                  className="btn-ghost h-[38px] w-9 px-0 text-err hover:bg-err/10"
                  onClick={() => patch({ customImages: imagine.customImages.filter((_, i) => i !== index) })}
                  title="Удалить"
                >
                  <Trash2 size={13} />
                </button>
              </div>
              <input
                className="field font-mono text-[11.5px]"
                value={endpoint.baseUrl}
                placeholder="https://api.example.com/v1"
                onChange={(e) => {
                  const list = [...imagine.customImages];
                  list[index] = { ...endpoint, baseUrl: e.target.value.trim() };
                  patch({ customImages: list });
                }}
              />
              <div className="flex gap-1.5">
                <input
                  className="field flex-1 font-mono text-[11.5px]"
                  type="password"
                  value={endpoint.apiKey}
                  placeholder="API-ключ"
                  onChange={(e) => {
                    const list = [...imagine.customImages];
                    list[index] = { ...endpoint, apiKey: e.target.value.trim() };
                    patch({ customImages: list });
                  }}
                />
                <input
                  className="field flex-1 font-mono text-[11.5px]"
                  value={endpoint.model}
                  placeholder="model (необязательно)"
                  onChange={(e) => {
                    const list = [...imagine.customImages];
                    list[index] = { ...endpoint, model: e.target.value.trim() };
                    patch({ customImages: list });
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="label mb-1.5">Галерея</div>
        <div className="card px-3">
          <Row title="Формат по умолчанию" desc="Используется, если не выбрать формат в панели imagine.">
            <Segmented
              value={imagine.aspect === "9:16" ? "9:16" : "1:1"}
              onChange={(v) => patch({ aspect: v })}
              options={[
                { value: "1:1", label: "Квадрат" },
                { value: "9:16", label: "Вертикаль" },
              ]}
            />
          </Row>
        </div>
      </div>
    </div>
  );
}
