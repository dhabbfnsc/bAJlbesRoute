import { useEffect, type ReactNode } from "react";
import { Loader2, X } from "lucide-react";
import { cn } from "../lib/utils";
import { choose } from "../lib/haptics";

export function Logo({ size = 22, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="logo-route" x1="10" y1="54" x2="54" y2="10" gradientUnits="userSpaceOnUse">
          <stop stopColor="rgb(var(--accent-deep))" />
          <stop offset="1" stopColor="rgb(var(--accent-soft))" />
        </linearGradient>
      </defs>
      <path
        d="M16 48C17.5 33 25 21 34 29C41 35.4 44.5 33 48 16"
        stroke="url(#logo-route)"
        strokeWidth="6.5"
        strokeLinecap="round"
      />
      <circle cx="16" cy="48" r="6" fill="rgb(var(--accent))" />
      <circle cx="32.5" cy="31.5" r="4" fill="rgb(var(--accent))" opacity="0.85" />
      <circle cx="48" cy="16" r="7" fill="rgb(var(--accent-soft))" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-semibold tracking-[0.01em] text-ink", className)}>
      b<span className="text-accent-soft">AJlbes</span>Route
    </span>
  );
}

export function Spinner({ size = 16, className }: { size?: number; className?: string }) {
  return <Loader2 size={size} className={cn("animate-spin text-accent", className)} />;
}

export function IconButton({
  children,
  onClick,
  title,
  className,
  disabled,
  active,
}: {
  children: ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  title?: string;
  className?: string;
  disabled?: boolean;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={disabled}
      onClick={(e) => {
        void choose();
        onClick?.(e);
      }}
      className={cn("icon-btn", active && "bg-white/[0.07] text-ink", className)}
    >
      {children}
    </button>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  size = "md",
  headerRight,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  subtitle?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg" | "full";
  headerRight?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  const width =
    size === "sm" ? "sm:max-w-sm" : size === "lg" ? "sm:max-w-2xl" : size === "full" ? "sm:max-w-4xl" : "sm:max-w-lg";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="backdrop-enter absolute inset-0 bg-black/55 backdrop-blur-[3px]" onClick={onClose} />
      <div
        className={cn(
          "sheet-enter relative flex w-full flex-col overflow-hidden border border-line glass-strong",
          "max-h-[92dvh] rounded-t-3xl shadow-sheet sm:max-h-[86dvh] sm:rounded-3xl sm:shadow-float",
          width,
        )}
      >
        {(title || headerRight) && (
          <div className="flex items-start gap-3 border-b border-line/70 px-4 py-3.5 sm:px-5">
            <div className="min-w-0 flex-1">
              {title && <div className="text-[15px] font-semibold text-ink">{title}</div>}
              {subtitle && <div className="mt-0.5 text-[12px] leading-snug text-muted">{subtitle}</div>}
            </div>
            {headerRight}
            <IconButton title="Закрыть" onClick={onClose} className="-mr-1.5 -mt-0.5">
              <X size={18} />
            </IconButton>
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">{children}</div>
        {footer && <div className="border-t border-line/70 px-4 py-3 sm:px-5">{footer}</div>}
      </div>
    </div>
  );
}

export function Switch({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => {
        void choose();
        onChange(!checked);
      }}
      className={cn(
        "relative h-[26px] w-[44px] shrink-0 rounded-full border transition-colors duration-200 disabled:opacity-40",
        checked ? "border-transparent" : "border-line2 bg-raised",
      )}
      style={checked ? { background: "linear-gradient(180deg, rgb(var(--accent)), rgb(var(--accent-deep)))" } : undefined}
    >
      <span
        className={cn(
          "absolute top-1/2 h-[20px] w-[20px] -translate-y-1/2 rounded-full bg-white shadow-sm transition-all duration-200",
          checked ? "left-[22px]" : "left-[3px] bg-muted/80",
        )}
      />
    </button>
  );
}

export function Row({
  title,
  desc,
  children,
  className,
}: {
  title: ReactNode;
  desc?: ReactNode;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-start gap-3 py-3", className)}>
      <div className="min-w-0 flex-1">
        <div className="text-[13.5px] font-medium text-ink">{title}</div>
        {desc && <div className="mt-0.5 text-[12px] leading-relaxed text-muted">{desc}</div>}
      </div>
      <div className="shrink-0 pt-0.5">{children}</div>
    </div>
  );
}

export function Section({
  title,
  desc,
  children,
  right,
}: {
  title: string;
  desc?: string;
  children: ReactNode;
  right?: ReactNode;
}) {
  return (
    <section className="mb-6 last:mb-2">
      <div className="mb-2 flex items-end justify-between gap-3">
        <div>
          <h3 className="label">{title}</h3>
          {desc && <p className="mt-1 text-[12px] leading-relaxed text-faint">{desc}</p>}
        </div>
        {right}
      </div>
      <div className="card divide-y divide-line/70 overflow-hidden">{children}</div>
    </section>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex rounded-xl border border-line bg-panel p-0.5", className)}>
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          onClick={() => {
            void choose();
            onChange(opt.value);
          }}
          className={cn(
            "flex-1 rounded-[10px] px-2.5 py-1.5 text-[12.5px] font-medium transition-all duration-150",
            value === opt.value
              ? "bg-raised text-ink shadow-[0_1px_0_rgba(255,255,255,0.05)_inset]"
              : "text-muted hover:text-ink",
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export function Range({
  value,
  min,
  max,
  step,
  onChange,
  format,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  return (
    <div className="flex items-center gap-3">
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-line2 outline-none
          [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none
          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-0 [&::-webkit-slider-thumb]:bg-accent
          [&::-webkit-slider-thumb]:shadow-[0_0_0_4px_rgb(var(--accent)/0.18)]"
        style={{
          background: `linear-gradient(to right, rgb(var(--accent)) ${((value - min) / (max - min)) * 100}%, #3a352f ${
            ((value - min) / (max - min)) * 100
          }%)`,
        }}
      />
      <span className="w-14 shrink-0 text-right text-[12px] tabular-nums text-muted">
        {format ? format(value) : value}
      </span>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 block text-[12px] font-medium text-muted">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[11.5px] leading-relaxed text-faint">{hint}</span>}
    </label>
  );
}

export function EmptyState({
  icon,
  title,
  desc,
  action,
}: {
  icon?: ReactNode;
  title: string;
  desc?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      {icon && <div className="mb-3 text-faint">{icon}</div>}
      <div className="text-[14px] font-medium text-ink">{title}</div>
      {desc && <div className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-muted">{desc}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "accent" | "ok" | "err" | "warn";
}) {
  const tones: Record<string, string> = {
    neutral: "border-line bg-panel text-faint",
    accent: "border-accent/35 bg-accent/10 text-accent-soft",
    ok: "border-ok/30 bg-ok/10 text-ok",
    err: "border-err/35 bg-err/10 text-err",
    warn: "border-warn/35 bg-warn/10 text-warn",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10.5px] font-medium", tones[tone])}>
      {children}
    </span>
  );
}
