import { useState } from "react";
import { ArrowRight, BellRing, Check, FolderOpen, KeyRound, Sparkles } from "lucide-react";
import { useStore } from "../store/store";
import { PROVIDER_PRESETS } from "../lib/catalog";
import { chooseDirectory } from "../lib/files";
import { ensureNotificationPermission } from "../lib/notify";
import { isTauri } from "../lib/bridge";
import { cn } from "../lib/utils";
import { choose } from "../lib/haptics";
import { Logo, Wordmark } from "./ui";

const POPULAR = ["openai", "anthropic", "google", "openrouter", "openai"];

export function Onboarding() {
  const settings = useStore((s) => s.settings);
  const patch = useStore((s) => s.patchSettings);
  const addProvider = useStore((s) => s.addProvider);
  const updateProvider = useStore((s) => s.updateProvider);
  const setWorkspace = useStore((s) => s.setWorkspace);
  const setModel = useStore((s) => s.setModel);
  const boot = useStore((s) => s.boot);

  const [step, setStep] = useState(0);
  const [presetKey, setPresetKey] = useState<string>("openai");
  const [apiKey, setApiKey] = useState("");
  const presets = PROVIDER_PRESETS.filter((p) => Array.from(new Set(POPULAR)).includes(p.key));

  const finish = () => {
    patch({ onboarded: true });
  };

  const saveKey = () => {
    const preset = PROVIDER_PRESETS.find((p) => p.key === presetKey);
    if (!preset) return;
    const existing = settings.providers.find((p) => p.preset === presetKey);
    const id = existing?.id ?? addProvider(presetKey);
    if (id && apiKey.trim()) updateProvider(id, { apiKey: apiKey.trim() });
    if (id) {
      const provider = useStore.getState().settings.providers.find((p) => p.id === id);
      if (provider?.models[0]) setModel(id, provider.models[0].id);
    }
  };

  const steps = [
    {
      title: "Добро пожаловать в bAJlbesRoute",
      body: (
        <div className="space-y-3">
          <p className="text-[13px] leading-relaxed text-muted">
            Это приватный клиент для ваших собственных AI-ключей и endpoint'ов. Один интерфейс для всех
            моделей — на Windows, Android и iOS.
          </p>
          <div className="grid gap-2">
            {[
              ["Свои ключи", "OpenAI, Anthropic, Gemini, OpenRouter, DeepSeek, локальные серверы"],
              ["Работа с файлами", "модель читает и создаёт файлы в выбранной папке"],
              ["Imagine", "фото и видео: первый успешный ответ среди всех источников"],
            ].map(([title, desc]) => (
              <div key={title} className="flex gap-2.5 rounded-xl border border-line/70 bg-panel/50 px-3 py-2">
                <Sparkles size={14} className="mt-0.5 shrink-0 text-accent-soft" />
                <div>
                  <div className="text-[12.5px] font-medium text-ink">{title}</div>
                  <div className="text-[11px] leading-relaxed text-faint">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ),
    },
    {
      title: "Подключите провайдера",
      body: (
        <div className="space-y-3">
          <p className="text-[12.5px] leading-relaxed text-muted">
            Вставьте API-ключ — модель подхватится автоматически. Ключ хранится только на этом устройстве.
          </p>
          <div className="grid grid-cols-2 gap-1.5">
            {presets.map((preset) => (
              <button
                key={preset.key}
                type="button"
                onClick={() => {
                  void choose();
                  setPresetKey(preset.key);
                }}
                className={cn(
                  "flex items-center justify-between rounded-xl border px-2.5 py-2 text-left text-[12px] font-medium transition-colors",
                  presetKey === preset.key
                    ? "border-accent/45 bg-accent/10 text-ink"
                    : "border-line bg-panel/50 text-muted hover:text-ink",
                )}
              >
                {preset.name}
                {presetKey === preset.key && <Check size={12} className="text-accent" />}
              </button>
            ))}
          </div>
          <input
            className="field font-mono text-[12px]"
            type="password"
            placeholder="API-ключ"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            spellCheck={false}
          />
          <button
            type="button"
            className="btn-soft w-full"
            disabled={!apiKey.trim()}
            onClick={() => {
              saveKey();
              setStep(2);
            }}
          >
            <KeyRound size={13} /> Сохранить ключ и продолжить
          </button>
        </div>
      ),
    },
    {
      title: "Последние штрихи",
      body: (
        <div className="space-y-2.5">
          <button
            type="button"
            className="flex w-full items-center gap-2.5 rounded-xl border border-line bg-panel/50 px-3 py-2.5 text-left transition-colors hover:border-line2"
            onClick={async () => {
              const dir = await chooseDirectory();
              if (dir) await setWorkspace(dir);
            }}
          >
            <FolderOpen size={15} className="shrink-0 text-accent-soft" />
            <span className="min-w-0 flex-1">
              <span className="block text-[12.5px] font-medium text-ink">
                {settings.workspace ? `Папка: ${settings.workspace.split(/[\\/]/).filter(Boolean).pop()}` : "Выбрать рабочую папку"}
              </span>
              <span className="block text-[10.5px] text-faint">
                {isTauri() ? "Модель сможет работать с файлами внутри неё" : "Доступно в приложении"}
              </span>
            </span>
            <ArrowRight size={13} className="shrink-0 text-faint" />
          </button>

          <button
            type="button"
            className="flex w-full items-center gap-2.5 rounded-xl border border-line bg-panel/50 px-3 py-2.5 text-left transition-colors hover:border-line2"
            onClick={async () => {
              const granted = await ensureNotificationPermission();
              patch({ notifications: granted });
            }}
          >
            <BellRing size={15} className="shrink-0 text-accent-soft" />
            <span className="min-w-0 flex-1">
              <span className="block text-[12.5px] font-medium text-ink">
                {settings.notifications ? "Уведомления включены" : "Разрешить уведомления"}
              </span>
              <span className="block text-[10.5px] text-faint">
                {boot?.isMobile ? "Виброотклик и уведомление об ответе" : "Сообщим, когда модель ответила в фоне"}
              </span>
            </span>
            <ArrowRight size={13} className="shrink-0 text-faint" />
          </button>

          <p className="pt-1 text-[10.5px] leading-relaxed text-faint">
            Всё это можно изменить позже в настройках.
          </p>
        </div>
      ),
    },
  ];

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-bg/95 p-4 backdrop-blur-sm">
      <div className="modal-enter w-full max-w-md overflow-hidden rounded-3xl border border-line glass-strong shadow-float">
        <div className="flex items-center gap-2.5 border-b border-line/70 px-4 py-3">
          <Logo size={26} />
          <Wordmark className="text-[14.5px]" />
          <div className="ml-auto flex gap-1">
            {steps.map((_, index) => (
              <span
                key={index}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  index === step ? "w-5 bg-accent" : "w-1.5 bg-line2",
                )}
              />
            ))}
          </div>
        </div>

        <div className="px-4 py-4">
          <h2 className="mb-2 text-[17px] font-semibold text-ink">{steps[step].title}</h2>
          {steps[step].body}
        </div>

        <div className="flex items-center gap-2 border-t border-line/70 px-4 py-3">
          {step > 0 ? (
            <button className="btn-ghost h-9 px-2 text-[12px]" onClick={() => setStep(step - 1)}>
              Назад
            </button>
          ) : (
            <button className="btn-ghost h-9 px-2 text-[12px]" onClick={finish}>
              Пропустить
            </button>
          )}
          <div className="ml-auto flex items-center gap-2">
            {step < steps.length - 1 ? (
              <button className="btn-primary h-9" onClick={() => setStep(step + 1)}>
                Далее <ArrowRight size={14} />
              </button>
            ) : (
              <button className="btn-primary h-9" onClick={finish}>
                Начать <Check size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
