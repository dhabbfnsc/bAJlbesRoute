import { useMemo, useState } from "react";
import { Brain, Check, Eye, KeyRound, RefreshCw, Search, Settings2, Wrench } from "lucide-react";
import type { ModelInfo, ProviderConfig } from "../types";
import { providerNeedsKey, useStore } from "../store/store";
import { cn, hostOf } from "../lib/utils";
import { choose } from "../lib/haptics";
import { Badge, EmptyState, IconButton, Modal, Spinner } from "./ui";

export function ModelPicker({
  open,
  onClose,
  onOpenSettings,
}: {
  open: boolean;
  onClose: () => void;
  onOpenSettings: (tab?: string) => void;
}) {
  const providers = useStore((s) => s.settings.providers);
  const currentModel = useStore((s) => s.currentModel);
  const setModel = useStore((s) => s.setModel);
  const syncModels = useStore((s) => s.syncModels);
  const toast = useStore((s) => s.toast);
  const [query, setQuery] = useState("");
  const [syncing, setSyncing] = useState<string | null>(null);

  const available = useMemo(() => providers.filter((p) => p.enabled), [providers]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return available
      .map((p) => ({
        provider: p,
        models: q
          ? p.models.filter(
              (m) =>
                m.id.toLowerCase().includes(q) ||
                m.label.toLowerCase().includes(q) ||
                p.name.toLowerCase().includes(q),
            )
          : p.models,
      }))
      .filter((entry) => entry.models.length > 0 || (!q && entry.provider.enabled));
  }, [available, query]);

  const sync = async (provider: ProviderConfig) => {
    setSyncing(provider.id);
    const result = await syncModels(provider.id);
    setSyncing(null);
    toast(result.message, result.ok ? "ok" : "err");
  };

  const pick = (provider: ProviderConfig, model: ModelInfo) => {
    void choose();
    setModel(provider.id, model.id);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Выбор модели"
      subtitle="Модели берутся из ваших провайдеров. Список можно обновить кнопкой справа."
      size="lg"
      headerRight={
        <button
          type="button"
          className="btn-ghost h-8 px-2 text-[11.5px]"
          onClick={() => {
            onClose();
            onOpenSettings("providers");
          }}
        >
          <Settings2 size={13} /> Провайдеры
        </button>
      }
    >
      <div className="sticky top-0 z-10 border-b border-line/60 bg-elev/90 px-4 py-2.5 backdrop-blur">
        <div className="relative">
          <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-faint" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск модели или провайдера…"
            className="field pl-8"
          />
        </div>
      </div>

      <div className="p-2 sm:p-3">
        {filtered.length === 0 || available.length === 0 ? (
          <EmptyState
            icon={<KeyRound size={26} />}
            title="Нет доступных провайдеров"
            desc="Добавьте API-ключ и endpoint — модели появятся здесь автоматически."
            action={
              <button
                className="btn-primary"
                onClick={() => {
                  onClose();
                  onOpenSettings("providers");
                }}
              >
                <KeyRound size={14} /> Добавить провайдера
              </button>
            }
          />
        ) : (
          filtered.map(({ provider, models }) => {
            const needsKey = providerNeedsKey(provider) && !provider.apiKey.trim();
            return (
              <div key={provider.id} className="mb-3 last:mb-0">
                <div className="flex items-center gap-2 px-2 pb-1.5">
                  <span className="text-[11.5px] font-semibold text-ink">{provider.name}</span>
                  <span className="truncate text-[10.5px] text-faint">{hostOf(provider.baseUrl)}</span>
                  {needsKey && (
                    <Badge tone="warn">
                      <KeyRound size={9} /> нет ключа
                    </Badge>
                  )}
                  <span className="ml-auto text-[10px] tabular-nums text-faint">{models.length}</span>
                  <IconButton
                    title="Обновить список моделей"
                    className="h-6 w-6"
                    disabled={syncing === provider.id}
                    onClick={() => void sync(provider)}
                  >
                    {syncing === provider.id ? <Spinner size={11} /> : <RefreshCw size={11} />}
                  </IconButton>
                </div>
                <div className="card divide-y divide-line/60 overflow-hidden">
                  {models.length === 0 && (
                    <div className="px-3 py-3 text-[11.5px] text-faint">
                      Моделей нет — обновите список или добавьте вручную в настройках.
                    </div>
                  )}
                  {models.map((model) => {
                    const active =
                      currentModel?.providerId === provider.id && currentModel?.modelId === model.id;
                    return (
                      <button
                        key={model.id}
                        type="button"
                        onClick={() => pick(provider, model)}
                        className={cn(
                          "flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors",
                          active ? "bg-accent/[0.09]" : "hover:bg-white/[0.04]",
                        )}
                      >
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-1.5">
                            <span
                              className={cn(
                                "truncate text-[12.5px]",
                                active ? "font-medium text-ink" : "text-ink/90",
                              )}
                            >
                              {model.label || model.id}
                            </span>
                            {model.reasoning && (
                              <span title="Поддерживает reasoning" className="text-accent-soft/70">
                                <Brain size={11} />
                              </span>
                            )}
                            {model.vision && (
                              <span title="Поддерживает изображения" className="text-info/70">
                                <Eye size={11} />
                              </span>
                            )}
                            {model.tools && (
                              <span title="Поддерживает инструменты" className="text-ok/70">
                                <Wrench size={10} />
                              </span>
                            )}
                          </span>
                          <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-faint">
                            <span className="truncate font-mono">{model.id}</span>
                            {model.context ? <span className="shrink-0">· {(model.context / 1000).toFixed(0)}k</span> : null}
                          </span>
                        </span>
                        {active && <Check size={14} className="shrink-0 text-accent" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </Modal>
  );
}
