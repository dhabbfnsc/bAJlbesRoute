import { isValidElement, memo, useMemo, useState, type ReactNode } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { Check, Copy } from "lucide-react";
import { openExternal } from "../lib/links";
import { cn } from "../lib/utils";

function extractText(node: ReactNode): string {
  if (node == null || node === false) return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(extractText).join("");
  if (isValidElement(node)) {
    const props = node.props as { children?: ReactNode };
    return extractText(props.children);
  }
  return "";
}

function CodeBlock({ children, raw, lang }: { children: ReactNode; raw: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(raw);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  };
  return (
    <div className="group/code relative my-1">
      <div className="pointer-events-none absolute right-2 top-2 z-10 flex items-center gap-1.5">
        {lang && (
          <span className="rounded-md bg-white/[0.06] px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-faint">
            {lang}
          </span>
        )}
        <button
          type="button"
          onClick={copy}
          className="pointer-events-auto rounded-md bg-white/[0.06] p-1.5 text-muted opacity-0 transition-opacity hover:text-ink group-hover/code:opacity-100"
          title="Копировать код"
        >
          {copied ? <Check size={12} className="text-ok" /> : <Copy size={12} />}
        </button>
      </div>
      <pre className="!mt-0">{children}</pre>
    </div>
  );
}

const components: Components = {
  pre({ children }) {
    const childArray = Array.isArray(children) ? children : [children];
    const codeEl = childArray.find(
      (c): c is React.ReactElement<{ className?: string; children?: ReactNode }> =>
        typeof c === "object" && c !== null && "props" in (c as object),
    );
    const className = codeEl?.props?.className ?? "";
    const match = /language-([\w+-]+)/.exec(className);
    const raw = extractText(children).replace(/\n$/, "");
    return (
      <CodeBlock raw={raw} lang={match?.[1]}>
        {children}
      </CodeBlock>
    );
  },
  a({ href, children }) {
    return (
      <a
        href={href}
        onClick={(e) => {
          e.preventDefault();
          if (href) void openExternal(href);
        }}
      >
        {children}
      </a>
    );
  },
  table({ children }) {
    return (
      <div className="overflow-x-auto">
        <table>{children}</table>
      </div>
    );
  },
  input({ checked, ...props }) {
    return <input {...props} type="checkbox" checked={Boolean(checked)} readOnly />;
  },
};

export const MarkdownView = memo(function MarkdownView({
  text,
  className,
}: {
  text: string;
  className?: string;
}) {
  const content = useMemo(() => text, [text]);
  return (
    <div className={cn("md", className)}>
      <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[[rehypeHighlight, { detect: true, ignoreMissing: true }]]} components={components}>
        {content}
      </ReactMarkdown>
    </div>
  );
});
