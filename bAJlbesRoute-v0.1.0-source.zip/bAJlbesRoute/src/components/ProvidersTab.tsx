import { useState } from "react";
import {
  ChevronDown,
  Eye,
  EyeOff,
  KeyRound,
  Plus,
  RefreshCw,
  Trash2,
  Trash,
  Zap,
} from "lucide-react";
import type { ProviderConfig } from "../types";
import { useStore } from "../store/store";
import { PROVIDER_PRESETS, presetByKey } from "../lib/catalog";
import { cn, hostOf, timeAgo } from "../lib/utils";
import { choose, succeed } from "../lib/haptics";
import { openExternal } from "../lib/links";
import { Badge, Field, IconButton, Segmented, Spinner, Switch } from "./ui";

export function ProvidersTab() {
  const providers = useStore((s) => s.settings.providers);
  const addProvider = useStore((s) => s.addProvider);
  const updateProvider = useStore((s) => s.updateProvider);
  const removeProvider = useStore((s) => s.removeProvider);
  const syncModels = useStore((s) => s.syncModels);
  const addManualModel = useStore((s) => s.addManualModel);
  const removeModel = useStore((s) => s.removeModel);
  const toast = useStore((s) => s.toast);

  const [expanded, setExpanded] = useState<string | null>(providers[0]?.id ?? null);
  const [showKey, setShowKey] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [manual, setManual] = useState<Record<string, string>>({});

  const test = async (provider: ProviderConfig) => {
    setBusy(provider.id);
    try {
      const { testProvider } = await import("../lib/bridge");
      const message = await testProvider({
        kind: provider.kind,
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
      });
      toast(message, "ok");
      succeed();
      const result = await syncModels(provider.id);
      if (result.ok) toast(result.message, "ok");
    } catch (err) {
      toast(err instanceof Error ? err.message : String(err), "err");
    } finally {
      setBusy(null);
    }
  };

  const sync = async (provider: ProviderConfig) => {
    setBusy(provider.id);
    const result = await syncModels(provider.id);
    setBusy(null);
    toast(result.message, result.ok ? "ok" : "err");
  };

  return (
    <div>
      <p className="mb-3 rounded-xl border border-line/70 bg-panel/50 px-3 py-2 text-[11.5px] leading-relaxed text-muted">
        Ключи хранятся только на этом устройстве. Запросы идут напрямую к провайдеру — без посредников.
      </p>

      {providers.map((provider) => {
        const preset = presetByKey(provider.preset);
        const open = expanded === provider.id;
        return (
          <div key={provider.id} className="card mb-2 overflow-hidden">
            <div className="flex items-center gap-2 px-3 py-2.5">
              <button
                type="button"
                className="flex min-w-0 flex-1 items-center gap-2 text-left"
                onClick={() => {
                  void choose();
                  setExpanded(open ? null : provider.id);
                }}
              >
                <ChevronDown
                  size={14}
                  className={cn("shrink-0 text-faint transition-transform", open && "rotate-180")}
                />
                <span className="min-w-0">
                  <span className="flex items-center gap-1.5">
                    <span className="truncate text-[13px] font-medium text-ink">{provider.name}</span>
                    <Badge tone={provider.kind === "anthropic" ? "accent" : "neutral"}>
                      {provider.kind === "anthropic" ? "Anthropic" : "OpenAI"}
                    </Badge>
                    {provider.apiKey.trim() ? (
                      <Badge tone="ok">
                        <KeyRound size={8} /> ключ есть
                      </Badge>
                    ) : (
                      <Badge tone="warn">без ключа</Badge>
                    )}
                  </span>
                  <span className="mt-0.5 block truncate text-[10.5px] text-faint">
                    {hostOf(provider.baseUrl)} · моделей: {provider.models.length}
                    {provider.lastSync ? ` · обновлено ${timeAgo(provider.lastSync)}` : ""}
                  </span>
                </span>
              </button>
              <Switch
                checked={provider.enabled}
                onChange={(value) => updateProvider(provider.id, { enabled: value })}
              />
            </div>

            {open && (
              <div className="border-t border-line/70 px-3 pb-3 pt-2.5">
                <div className="grid gap-2.5 sm:grid-cols-2">
                  <Field label="Название">
                    <input
                      className="field"
                      value={provider.name}
                      onChange={(e) => updateProvider(provider.id, { name: e.target.value })}
                    />
                  </Field>
                  <Field label="Тип API">
                    <Segmented
                      value={provider.kind}
                      onChange={(value) => updateProvider(provider.id, { kind: value })}
                      options={[
                        { value: "openai", label: "OpenAI-совместимый" },
                        { value: "anthropic", label: "Anthropic" },
                      ]}
                    />
                  </Field>
                  <Field
                    label="Base URL"
                    hint={preset?.docs ? undefined : "Например https://api.example.com/v1"}
                    className="sm:col-span-2"
                  >
                    <input
                      className="field font-mono text-[12px]"
                      value={provider.baseUrl}
                      placeholder="https://api.openai.com/v1"
                      onChange={(e) => updateProvider(provider.id, { baseUrl: e.target.value.trim() })}
                      spellCheck={false}
                    />
                  </Field>
                  <Field label="API-ключ" className="sm:col-span-2">
                    <div className="relative">
                      <input
                        className="field pr-9 font-mono text-[12px]"
                        type={showKey[provider.id] ? "text" : "password"}
                        value={provider.apiKey}
                        placeholder="sk-…"
                        onChange={(e) => updateProvider(provider.id, { apiKey: e.target.value.trim() })}
                        spellCheck={false}
                      />
                      <button
                        type="button"
                        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-faint hover:text-ink"
                        onClick={() => setShowKey((prev) => ({ ...prev, [provider.id]: !prev[provider.id] }))}
                      >
                        {showKey[provider.id] ? <EyeOff size={13} /> : <Eye size={13} />}
                      </button>
                    </div>
                  </Field>
                </div>

                <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                  <button className="btn-soft h-8 px-2.5 text-[11.5px]" onClick={() => void test(provider)} disabled={busy === provider.id}>
                    {busy === provider.id ? <Spinner size={12} /> : <Zap size={12} />} Проверить
                  </button>
                  <button className="btn-soft h-8 px-2.5 text-[11.5px]" onClick={() => void sync(provider)} disabled={busy === provider.id}>
                    <RefreshCw size={12} /> Обновить модели
                  </button>
                  {preset?.docs && (
                    <button
                      className="btn-ghost h-8 px-2 text-[11.5px]"
                      onClick={() => void openExternal(preset.docs!)}
                    >
                      Где взять ключ
                    </button>
                  )}
                  <button
                    className="btn-ghost ml-auto h-8 px-2 text-[11.5px] text-err hover:bg-err/10 hover:text-err"
                    onClick={() => {
                      void choose();
                      removeProvider(provider.id);
                    }}
                  >
                    <Trash2 size={12} /> Удалить
                  </button>
                </div>

                <div className="mt-3">
                  <div className="label mb-1.5">Модели ({provider.models.length})</div>
                  <div className="max-h-56 overflow-y-auto rounded-xl border border-line/70">
                    {provider.models.length === 0 && (
                      <div className="px-3 py-3 text-[11.5px] text-faint">
                        Список пуст — нажмите «Обновить модели» или добавьте вручную.
                      </div>
                    )}
                    {provider.models.map((model) => (
                      <div
                        key={model.id}
                        className="flex items-center gap-2 border-b border-line/50 px-2.5 py-1.5 last:border-0"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[12px] text-ink/90">{model.label || model.id}</div>
                          <div className="truncate font-mono text-[10px] text-faint">{model.id}</div>
                        </div>
                        {model.context ? (
                          <span className="shrink-0 text-[10px] tabular-nums text-faint">
                            {(model.context / 1000).toFixed(0)}k
                          </span>
                        ) : null}
                        <button
                          className="rounded-md p-1 text-faint hover:text-err"
                          onClick={() => removeModel(provider.id, model.id)}
                          title="Убрать из списка"
                        >
                          <Trash size={11} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="mt-1.5 flex gap-1.5">
                    <input
                      className="field flex-1 font-mono text-[12px]"
                      placeholder="Добавить модель вручную: например gpt-5.1"
                      value={manual[provider.id] ?? ""}
                      onChange={(e) => setManual((prev) => ({ ...prev, [provider.id]: e.target.value }))}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && (manual[provider.id] ?? "").trim()) {
                          addManualModel(provider.id, manual[provider.id]);
                          setManual((prev) => ({ ...prev, [provider.id]: "" }));
                        }
                      }}
                    />
                    <button
                      className="btn-soft h-[38px] px-2.5"
                      onClick={() => {
                        if ((manual[provider.id] ?? "").trim()) {
                          addManualModel(provider.id, manual[provider.id]);
                          setManual((prev) => ({ ...prev, [provider.id]: "" }));
                        }
                      }}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div className="mt-4">
        <div className="label mb-1.5">Добавить провайдера</div>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          {PROVIDER_PRESETS.filter((preset) => !providers.some((p) => p.preset === preset.key)).map((preset) => (
            <button
              key={preset.key}
              type="button"
              onClick={() => {
                void choose();
                const id = addProvider(preset.key);
                if (id) setExpanded(id);
              }}
              className="flex items-center gap-2 rounded-xl border border-line bg-panel/60 px-2.5 py-2 text-left transition-colors hover:border-line2 hover:bg-panel"
            >
              <Plus size={13} className="shrink-0 text-accent-soft" />
              <span className="min-w-0">
                <span className="block truncate text-[12px] font-medium text-ink">{preset.name}</span>
                <span className="block truncate text-[10px] text-faint">{preset.hint ?? hostOf(preset.baseUrl)}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export { IconButton };
