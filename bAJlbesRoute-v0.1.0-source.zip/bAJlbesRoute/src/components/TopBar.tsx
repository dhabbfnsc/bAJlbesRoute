import { ChevronDown, Menu, Settings2, Sparkles } from "lucide-react";
import { selectActiveChat, selectCurrentModelInfo, selectCurrentProvider, useStore } from "../store/store";
import { cn } from "../lib/utils";
import { choose } from "../lib/haptics";
import { EFFORT_LABEL } from "../lib/catalog";
import { Spinner } from "./ui";

export function TopBar({
  onOpenModelPicker,
  onOpenSettings,
}: {
  onOpenModelPicker: () => void;
  onOpenSettings: (tab?: string) => void;
}) {
  const chat = useStore(selectActiveChat);
  const run = useStore((s) => (chat ? s.runs[chat.id] : undefined));
  const runs = useStore((s) => s.runs);
  const chats = useStore((s) => s.chats);
  const selectChat = useStore((s) => s.selectChat);
  const toggleSidebar = useStore((s) => s.toggleSidebar);
  const model = useStore(selectCurrentModelInfo);
  const provider = useStore(selectCurrentProvider);
  const effort = useStore((s) => s.currentEffort);
  const settings = useStore((s) => s.settings);

  const backgroundRuns = Object.values(runs).filter((r) => r.chatId !== chat?.id);

  const statusText = run
    ? run.status === "tools"
      ? "работает с файлами"
      : run.status === "thinking"
        ? "думает"
        : "пишет"
    : "";

  return (
    <header className="safe-top z-20 flex h-[52px] shrink-0 items-center gap-1.5 border-b border-line/60 px-2 glass sm:px-3">
      <button
        className="icon-btn lg:hidden"
        onClick={() => {
          void choose();
          toggleSidebar(true);
        }}
        aria-label="Меню"
      >
        <Menu size={18} />
      </button>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-[13.5px] font-medium text-ink">
            {chat?.title ?? "Новый чат"}
          </span>
          {run && (
            <span className="flex shrink-0 items-center gap-1 rounded-full bg-accent/10 px-1.5 py-0.5 text-[10px] font-medium text-accent-soft">
              <Spinner size={9} /> {statusText}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5 truncate text-[10.5px] text-faint">
          <span className="truncate">{provider ? provider.name : "Провайдер не выбран"}</span>
          <span className="opacity-50">·</span>
          <span>{EFFORT_LABEL[effort]}</span>
          {settings.toolsEnabled && settings.workspace && (
            <>
              <span className="opacity-50">·</span>
              <span className="truncate">файлы: {settings.workspace.split(/[\\/]/).filter(Boolean).pop()}</span>
            </>
          )}
        </div>
      </div>

      {backgroundRuns.map((bgRun) => {
        const bgChat = chats.find((c) => c.id === bgRun.chatId);
        if (!bgChat) return null;
        return (
          <button
            key={bgRun.chatId}
            type="button"
            onClick={() => {
              void choose();
              selectChat(bgRun.chatId);
            }}
            className="hidden items-center gap-1.5 rounded-lg border border-accent/25 bg-accent/[0.08] px-2 py-1 text-[10.5px] font-medium text-accent-soft hover:bg-accent/[0.14] sm:flex"
            title={`В фоне: ${bgChat.title}`}
          >
            <Spinner size={10} />
            <span className="max-w-[120px] truncate">{bgChat.title}</span>
          </button>
        );
      })}

      <button
        type="button"
        onClick={() => {
          void choose();
          onOpenModelPicker();
        }}
        className={cn(
          "flex h-8 shrink-0 items-center gap-1 rounded-lg border px-2 text-[11.5px] transition-colors",
          model
            ? "border-line bg-panel/70 text-ink hover:border-line2"
            : "border-accent/40 bg-accent/10 text-accent-soft",
        )}
      >
        <span className="max-w-[120px] truncate font-medium sm:max-w-[200px]">
          {model?.label ?? "Модель"}
        </span>
        <ChevronDown size={11} className="text-faint" />
      </button>

      <button
        className="icon-btn lg:hidden"
        onClick={() => {
          void choose();
          onOpenSettings("general");
        }}
        aria-label="Настройки"
      >
        <Settings2 size={17} />
      </button>
    </header>
  );
}
