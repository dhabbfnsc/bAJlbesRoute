/**
 * Демо-режим для веб-превью (когда нет Rust-ядра).
 * Позволяет посмотреть интерфейс и потоковый вывод без установки приложения.
 */
import type { Effort } from "../types";
import { sleep } from "./utils";

export interface DemoRunHandlers {
  onStatus(status: string): void;
  onDelta(text: string): void;
  onReasoning(text: string): void;
  onDone(text: string, reasoning: string, finish: string): void;
  onError(message: string): void;
}

export interface DemoRunOptions {
  prompt: string;
  model: string;
  provider: string;
  effort: Effort;
  workspace?: string | null;
}

function composeAnswer(opts: DemoRunOptions): { reasoning: string; answer: string } {
  const { prompt, model, provider, effort, workspace } = opts;
  const reasoning =
    effort === "off"
      ? ""
      : `Пользователь написал: «${prompt.slice(0, 120)}». Это веб-превью интерфейса bAJlbesRoute: Rust-ядро здесь не запущено, поэтому ответ демонстрационный. Нужно аккуратно показать, как выглядит стриминг, панель размышлений и форматирование Markdown.`;
  const answer = `**Демо-режим интерфейса.** Вы видите это сообщение, потому что bAJlbesRoute открыт в браузере без нативного ядра.

В собранном приложении здесь отвечает ваша модель — **${model}** через **${provider}**, с режимом усилий «${effort === "off" ? "выкл" : effort}»${
    workspace ? ` и доступом к папке \`${workspace}\`` : ""
  }.

### Что уже работает в приложении
1. **Свои ключи и endpoint'ы** — OpenAI, Anthropic, Gemini, OpenRouter, DeepSeek, Groq, xAI, Mistral, Ollama, LM Studio и любой OpenAI-совместимый сервер.
2. **Стриминг ответов** в реальном времени + панель размышлений.
3. **Файловые инструменты** — модель может читать, создавать и искать файлы в выбранной рабочей папке.
4. **Фоновая работа** — на Windows сворачивается в трей и присылает уведомление, когда модель ответила; на телефоне — виброотклик.
5. **Imagine** — генерация фото/видео: запускаются все доступные провайдеры, побеждает первый успешный ответ.

\`\`\`ts
// Пример: так выглядит вызов из интерфейса
const reply = await bajlbes.chat({
  model: "${model}",
  effort: "${effort}",
  workspace: ${workspace ? `"${workspace}"` : "null"},
});
\`\`\`

> Запустите \`npm run tauri dev\` (или готовую сборку), чтобы подключить настоящий API.

Ваш запрос сохранён в истории: «${prompt.slice(0, 200)}»`;
  return { reasoning, answer };
}

export async function demoChatStream(opts: DemoRunOptions, handlers: DemoRunHandlers, isCancelled: () => boolean): Promise<void> {
  const { reasoning, answer } = composeAnswer(opts);
  handlers.onStatus("thinking");
  await sleep(320);
  if (isCancelled()) return;

  if (reasoning) {
    for (const chunk of reasoning.match(/[\s\S]{1,18}/g) ?? []) {
      if (isCancelled()) return;
      handlers.onReasoning(chunk);
      await sleep(14);
    }
  }
  handlers.onStatus("streaming");
  const tokens = answer.match(/(\s+|[^\s]+\s*)/g) ?? [answer];
  let i = 0;
  for (const token of tokens) {
    if (isCancelled()) return;
    handlers.onDelta(token);
    i += 1;
    if (i % 3 === 0) await sleep(18);
  }
  handlers.onDone(answer, reasoning, "stop");
}

/** Рисует абстрактную «сгенерированную» картинку для демо-режима. */
export function demoImage(prompt: string, aspect: string): string {
  const [w, h] = (() => {
    switch (aspect) {
      case "16:9":
        return [1280, 720];
      case "9:16":
        return [720, 1280];
      case "4:3":
        return [1024, 768];
      case "3:4":
        return [768, 1024];
      default:
        return [1024, 1024];
    }
  })();
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  let seed = 7;
  for (let i = 0; i < prompt.length; i++) seed = (seed * 31 + prompt.charCodeAt(i)) % 100000;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
  const bg = ctx.createLinearGradient(0, 0, w, h);
  bg.addColorStop(0, `hsl(${12 + rand() * 20}, 32%, 12%)`);
  bg.addColorStop(1, `hsl(${220 + rand() * 40}, 24%, 8%)`);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 26; i++) {
    const x = rand() * w;
    const y = rand() * h;
    const r = (0.08 + rand() * 0.4) * Math.min(w, h);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    const hue = rand() > 0.5 ? 16 + rand() * 22 : 200 + rand() * 60;
    g.addColorStop(0, `hsla(${hue}, ${55 + rand() * 30}%, ${48 + rand() * 22}%, ${0.10 + rand() * 0.25})`);
    g.addColorStop(1, "hsla(0,0%,0%,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const vig = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.75);
  vig.addColorStop(0, "rgba(0,0,0,0)");
  vig.addColorStop(1, "rgba(0,0,0,0.55)");
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.font = `600 ${Math.round(Math.min(w, h) * 0.026)}px ui-sans-serif, system-ui`;
  ctx.fillText("bAJlbesRoute · Imagine · демо", Math.round(w * 0.05), h - Math.round(h * 0.05));
  return canvas.toDataURL("image/png");
}
