import { isTauri } from "./bridge";

export async function chooseDirectory(title = "Выберите рабочую папку"): Promise<string | null> {
  if (!isTauri()) return null;
  try {
    const { open } = await import("@tauri-apps/plugin-dialog");
    const result = await open({ directory: true, multiple: false, title });
    return typeof result === "string" ? result : null;
  } catch {
    return null;
  }
}

export async function chooseSaveDirectory(): Promise<string | null> {
  return chooseDirectory("Куда сохранить");
}

export function baseName(path: string | null | undefined): string {
  if (!path) return "";
  const parts = path.split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 1] ?? path;
}
