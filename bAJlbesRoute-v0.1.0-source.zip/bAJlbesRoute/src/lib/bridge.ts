import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import type {
  AttachmentPayload,
  BootInfo,
  ChatSnapshot,
  ListedModel,
  MediaResult,
  WorkspaceOverview,
} from "../types";
import { detectWebPlatform } from "./utils";

export function isTauri(): boolean {
  return typeof window !== "undefined" && "__TAURI_INTERNALS__" in (window as unknown as Record<string, unknown>);
}

export async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (!isTauri()) throw new Error("Ядро недоступно: приложение открыто в браузере");
  return invoke<T>(cmd, args);
}

export async function subscribe<T>(event: string, handler: (payload: T) => void): Promise<UnlistenFn> {
  if (!isTauri()) return () => {};
  return listen<T>(event, (e) => handler(e.payload));
}

export async function bootInfo(): Promise<BootInfo> {
  if (isTauri()) {
    try {
      return await call<BootInfo>("boot_info");
    } catch {
      /* fallthrough */
    }
  }
  const platform = detectWebPlatform();
  return {
    platform,
    platformLabel: "Браузер",
    arch: "—",
    osVersion: typeof navigator !== "undefined" ? navigator.userAgent : "",
    appVersion: "0.1.0",
    dataDir: "",
    mediaDir: "",
    isMobile: platform === "android" || platform === "ios",
    deviceName: "Веб-превью",
    webview: "Browser",
    locale: typeof navigator !== "undefined" ? navigator.language : "ru",
  };
}

export async function loadState<T>(): Promise<T | null> {
  if (!isTauri()) {
    try {
      const raw = localStorage.getItem("bajlbesroute.state");
      return raw ? (JSON.parse(raw) as T) : null;
    } catch {
      return null;
    }
  }
  try {
    return await call<T | null>("load_state");
  } catch {
    return null;
  }
}

export async function saveState(value: unknown): Promise<void> {
  if (!isTauri()) {
    try {
      localStorage.setItem("bajlbesroute.state", JSON.stringify(value));
    } catch {
      /* ignore */
    }
    return;
  }
  try {
    await call("save_state", { data: value });
  } catch (err) {
    console.warn("save_state failed", err);
  }
}

export interface ChatStartPayload {
  requestId: string;
  chatId: string;
  provider: { kind: string; baseUrl: string; apiKey: string; headers: Record<string, string> };
  model: string;
  system: string;
  messages: { role: string; text: string; images: string[] }[];
  temperature?: number | null;
  maxTokens?: number | null;
  effort?: string | null;
  tools?: { enabled: boolean; root?: string | null } | null;
  notify?: { enabled: boolean; title: string } | null;
}

export function startChat(payload: ChatStartPayload): Promise<void> {
  return call("start_chat", { req: payload });
}

export function stopChat(requestId: string): Promise<void> {
  return call("stop_chat", { requestId });
}

export function chatSnapshot(requestId: string): Promise<ChatSnapshot | null> {
  return call("get_chat_snapshot", { requestId });
}

export function dropChatSnapshot(requestId: string): Promise<void> {
  return call("drop_chat_snapshot", { requestId });
}

export function listModels(provider: {
  kind: string;
  baseUrl: string;
  apiKey: string;
}): Promise<ListedModel[]> {
  return call("list_models", { provider });
}

export function testProvider(provider: {
  kind: string;
  baseUrl: string;
  apiKey: string;
}): Promise<string> {
  return call("test_provider", { provider });
}

export function workspaceOverview(path: string): Promise<WorkspaceOverview> {
  return call("workspace_overview", { path });
}

export function readAttachment(path: string): Promise<AttachmentPayload> {
  return call("read_attachment", { path });
}

export function setCloseToTray(enabled: boolean): Promise<void> {
  return call("set_close_to_tray", { enabled });
}

export function hideWindow(): Promise<void> {
  return call("hide_window");
}

export function showWindow(): Promise<void> {
  return call("show_window");
}

export function quitApp(): Promise<void> {
  return call("app_quit");
}

export function revealPath(path: string): Promise<void> {
  return call("reveal_path", { path });
}

export function mediaDelete(path: string): Promise<void> {
  return call("media_delete", { path });
}

export function mediaCopy(src: string, dest: string): Promise<string> {
  return call("media_copy", { src, dest });
}

export function mediaDirPath(): Promise<string> {
  return call("media_dir_path");
}

export function allowMediaScope(): Promise<void> {
  return call("allow_media_scope");
}

export interface ImagineStartPayload {
  id: string;
  mode: "image" | "video";
  prompt: string;
  image?: string | null;
  aspect?: string | null;
  providers: Record<string, unknown>;
  workspace?: string | null;
}

export function imagineGenerate(payload: ImagineStartPayload): Promise<MediaResult> {
  return call("imagine_generate", { req: payload });
}

export function imagineCancel(id: string): Promise<void> {
  return call("imagine_cancel", { id });
}
