import { convertFileSrc } from "@tauri-apps/api/core";
import { isTauri } from "./bridge";

/** Безопасный URL для локального файла (asset-протокол Tauri). */
export function assetUrl(path?: string | null, fallback?: string | null): string | undefined {
  if (path && isTauri()) {
    try {
      return convertFileSrc(path);
    } catch {
      /* ignore */
    }
  }
  return fallback ?? undefined;
}
