import type { BootInfo, Chat, Effort, Message, ModelInfo, ProviderConfig, Settings, WorkspaceOverview } from "../types";
import { EFFORT_LABEL } from "./catalog";

export interface PromptContext {
  boot: BootInfo | null;
  settings: Settings;
  chat: Chat;
  model?: ModelInfo | null;
  provider?: ProviderConfig | null;
  effort: Effort;
  workspace?: WorkspaceOverview | null;
}

const APP_IDENTITY = `Ты — AI-ассистент внутри приложения bAJlbesRoute — кроссплатформенного клиента, который работает с собственными API-ключами и endpoint'ами пользователя.`;

function envBlock(boot: BootInfo | null): string {
  if (!boot) return "Окружение: неизвестно.";
  const lines = [
    `- Платформа: ${boot.platformLabel} (${boot.platform}), архитектура ${boot.arch}`,
  ];
  if (boot.osVersion) lines.push(`- Версия ОС: ${boot.osVersion}`);
  if (boot.deviceName) lines.push(`- Имя устройства: ${boot.deviceName}`);
  if (boot.webview) lines.push(`- WebView: ${boot.webview}`);
  lines.push(`- Версия приложения: ${boot.appVersion}`);
  return lines.join("\n");
}

export function buildSystemPrompt(ctx: PromptContext): string {
  const { boot, settings, chat, model, provider, effort, workspace } = ctx;
  const now = new Date();
  const parts: string[] = [APP_IDENTITY, ""];

  parts.push("## Кто ты сейчас");
  if (model) {
    parts.push(
      `- Модель: ${model.label} (\`${model.id}\`)`,
      provider ? `- Провайдер: ${provider.name} (${provider.baseUrl})` : "",
      `- Режим усилий (reasoning): ${EFFORT_LABEL[effort]}${effort === "off" ? " — не рассуждай долго, отвечай сразу" : ""}`,
      model.vision ? "- Зрение: поддерживается (пользователь может прикреплять изображения)" : "- Зрение: не поддерживается",
      model.reasoning ? "- Рассуждения: модель поддерживает внутренние размышления" : "",
    );
  } else {
    parts.push("- Модель не выбрана или недоступна.");
  }
  parts.push(
    "Если пользователь спросит, кто ты и какая модель — назови именно эти модель и провайдера. Не утверждай, что ты продукт OpenAI, Anthropic или иной компании.",
    "",
  );

  parts.push("## Окружение пользователя");
  parts.push(envBlock(boot));
  parts.push(
    `- Текущее локальное время пользователя: ${now.toLocaleString("ru-RU", {
      dateStyle: "full",
      timeStyle: "short",
    })}`,
    "",
  );

  parts.push("## Рабочая папка и файлы");
  if (workspace && workspace.exists && settings.toolsEnabled) {
    const top = workspace.entries.slice(0, 12).join(", ") || "пусто";
    parts.push(
      `Рабочая папка: \`${chat.workspace}\``,
      `Файлов: ${workspace.files}, объём: ${(workspace.size / 1024 / 1024).toFixed(1)} МБ. Верхний уровень: ${top}`,
      "Тебе доступны инструменты: list_dir, read_file, write_file, append_file, create_dir, move_path, delete_path, file_info, search_files.",
      "Правила:",
      "- Все пути передавай относительными от рабочей папки (например `notes/todo.md`), выход за её пределы запрещён.",
      "- Прежде чем менять незнакомый файл — прочитай его.",
      "- Не удаляй файлы без явной просьбы пользователя.",
      "- Если пользователь просит «создай/сохрани/измени файл» — используй инструменты, а не просто показывай текст.",
      "- После работы с файлами коротко отчитайся: что сделано и в каких путях.",
    );
  } else if (workspace && workspace.exists) {
    parts.push(`Рабочая папка: \`${chat.workspace}\`. Инструменты файлов сейчас отключены в настройках приложения — если задача требует работы с файлами, попроси пользователя включить «Инструменты файлов».`);
  } else {
    parts.push(
      "Рабочая папка не выбрана, поэтому инструменты файлов недоступны. Если пользователь просит работать с файлами — предложи выбрать папку в Настройках приложения.",
    );
  }
  parts.push("");

  parts.push("## Стиль ответов");
  parts.push(
    "- Отвечай на языке пользователя; по умолчанию — русский.",
    "- Используй Markdown: заголовки, списки, таблицы, блоки кода с указанием языка.",
    "- Будь конкретным и структурированным; не выдумывай факты — если не знаешь, скажи прямо.",
    "- Не извиняйся без причины и не добавляй лишнюю «воду».",
    "- Для длинных задач сначала кратко поясни план, затем выполняй.",
  );

  if (settings.systemPromptExtra.trim()) {
    parts.push("", "## Дополнительные инструкции пользователя", settings.systemPromptExtra.trim());
  }

  return parts.filter((p) => p !== "").join("\n");
}

export interface ApiMessage {
  role: string;
  text: string;
  images: string[];
}

/** Преобразует историю чата в сообщения для API (с вложениями и без UI-мусора). */
export function toApiMessages(messages: Message[], limit = 60): ApiMessage[] {
  const usable = messages.filter((m) => {
    if (m.pending) return false;
    if (m.error && !m.text.trim()) return false;
    if (m.role === "assistant" && !m.text.trim()) return false;
    return true;
  });
  const trimmed = usable.slice(-limit);
  return trimmed.map((m) => {
    let text = m.text;
    const images: string[] = [];
    for (const a of m.attachments ?? []) {
      if (a.kind === "image" && a.dataUrl) {
        images.push(a.dataUrl);
      } else if (a.text) {
        text += `\n\n--- Файл: ${a.name} ---\n\`\`\`\n${a.text}\n\`\`\``;
      } else {
        text += `\n\n[Вложение: ${a.name} (${a.mime})]`;
      }
    }
    return { role: m.role, text, images };
  });
}
