import type { ImagineSettings, ProviderConfig, Settings } from "../types";
import { providerFromPreset, presetByKey } from "./catalog";

function provider(key: string, enabled = true): ProviderConfig {
  const preset = presetByKey(key)!;
  const p = providerFromPreset(preset);
  p.enabled = enabled;
  return p;
}

export function defaultImagine(): ImagineSettings {
  return {
    openaiModel: "gpt-image-1",
    fal: "",
    replicate: "",
    together: "",
    stability: "",
    pollinations: true,
    googleKey: "",
    useProviderKeyForGoogle: true,
    replicateT2V: "wan-video/wan-2.2-t2v-fast",
    replicateI2V: "wan-video/wan-2.2-i2v-fast",
    customImages: [],
    aspect: "1:1",
  };
}

export function defaultSettings(): Settings {
  return {
    accent: "coral",
    providers: [
      provider("openai"),
      provider("anthropic"),
      provider("google"),
      provider("openrouter"),
      provider("deepseek"),
      provider("groq"),
      provider("xai"),
      provider("mistral"),
      provider("ollama", false),
      provider("lmstudio", false),
      provider("custom", false),
    ],
    systemPromptExtra: "",
    sendOnEnter: true,
    showReasoning: true,
    animations: true,
    haptics: true,
    notifications: true,
    closeToTray: true,
    workspace: null,
    toolsEnabled: true,
    fontSize: "md",
    defaultEffort: "medium",
    maxTokens: null,
    temperature: 0.7,
    imagine: defaultImagine(),
    onboarded: false,
  };
}
