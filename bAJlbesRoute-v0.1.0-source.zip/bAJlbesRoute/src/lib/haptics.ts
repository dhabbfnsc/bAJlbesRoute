import { isTauri } from "./bridge";

export type HapticStyle = "light" | "medium" | "heavy" | "success" | "warning" | "error" | "select";

let enabled = true;
let lastAt = 0;

export function setHapticsEnabled(value: boolean): void {
  enabled = value;
}

/** Тактильная отдача. На десктопе тихо ничего не делает. */
export async function haptic(style: HapticStyle = "light"): Promise<void> {
  if (!enabled) return;
  const now = Date.now();
  if (now - lastAt < 28) return;
  lastAt = now;

  if (isTauri()) {
    try {
      const haptics = await import("@tauri-apps/plugin-haptics");
      if (style === "select") {
        await haptics.selectionFeedback();
      } else if (style === "success" || style === "warning" || style === "error") {
        await haptics.notificationFeedback(style);
      } else {
        await haptics.impactFeedback(style);
      }
    } catch {
      /* плагин доступен только на мобильных */
    }
    return;
  }

  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try {
      navigator.vibrate(style === "select" ? 8 : style === "error" ? 40 : 14);
    } catch {
      /* ignore */
    }
  }
}

export const tap = () => haptic("light");
export const choose = () => haptic("select");
export const succeed = () => haptic("success");
export const fail = () => haptic("error");
