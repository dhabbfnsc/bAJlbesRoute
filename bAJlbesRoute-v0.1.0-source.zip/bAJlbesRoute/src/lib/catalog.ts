import type { Effort, ModelInfo, ProviderConfig, ProviderKind } from "../types";
import { prettyModelName, uid } from "./utils";

export interface PresetModel {
  id: string;
  label?: string;
  reasoning?: boolean;
  vision?: boolean;
  tools?: boolean;
  context?: number;
}

export interface ProviderPreset {
  key: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string;
  hint?: string;
  docs?: string;
  models: PresetModel[];
  needsKey?: boolean;
}

/**
 * Пресеты провайдеров. Список моделей — стартовый: актуальный список всегда
 * подтягивается кнопкой «Обновить список» (GET /models у провайдера).
 */
export const PROVIDER_PRESETS: ProviderPreset[] = [
  {
    key: "openai",
    name: "OpenAI",
    kind: "openai",
    baseUrl: "https://api.openai.com/v1",
    docs: "https://platform.openai.com/api-keys",
    models: [
      { id: "gpt-5.1", reasoning: true, vision: true, tools: true, context: 400000 },
      { id: "gpt-5", reasoning: true, vision: true, tools: true, context: 400000 },
      { id: "gpt-5-mini", reasoning: true, vision: true, tools: true, context: 400000 },
      { id: "gpt-4.1", vision: true, tools: true, context: 1047576 },
      { id: "o4-mini", reasoning: true, vision: true, tools: true, context: 200000 },
    ],
  },
  {
    key: "anthropic",
    name: "Anthropic",
    kind: "anthropic",
    baseUrl: "https://api.anthropic.com/v1",
    docs: "https://console.anthropic.com/settings/keys",
    models: [
      { id: "claude-sonnet-4-5-20250929", label: "Claude Sonnet 4.5", reasoning: true, vision: true, tools: true, context: 200000 },
      { id: "claude-opus-4-1-20250805", label: "Claude Opus 4.1", reasoning: true, vision: true, tools: true, context: 200000 },
      { id: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5", reasoning: true, vision: true, tools: true, context: 200000 },
    ],
  },
  {
    key: "google",
    name: "Google Gemini",
    kind: "openai",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    hint: "OpenAI-совместимый шлюз Gemini",
    docs: "https://aistudio.google.com/apikey",
    models: [
      { id: "gemini-2.5-pro", reasoning: true, vision: true, tools: true, context: 1048576 },
      { id: "gemini-2.5-flash", reasoning: true, vision: true, tools: true, context: 1048576 },
      { id: "gemini-2.5-flash-lite", vision: true, tools: true, context: 1048576 },
    ],
  },
  {
    key: "openrouter",
    name: "OpenRouter",
    kind: "openai",
    baseUrl: "https://openrouter.ai/api/v1",
    hint: "Сотни моделей в одном ключе",
    docs: "https://openrouter.ai/keys",
    models: [
      { id: "anthropic/claude-sonnet-4.5", label: "Claude Sonnet 4.5", reasoning: true, vision: true, tools: true, context: 200000 },
      { id: "openai/gpt-5", reasoning: true, vision: true, tools: true, context: 400000 },
      { id: "google/gemini-2.5-pro", reasoning: true, vision: true, tools: true, context: 1048576 },
      { id: "deepseek/deepseek-chat", tools: true, context: 163840 },
      { id: "x-ai/grok-4", reasoning: true, vision: true, tools: true, context: 256000 },
    ],
  },
  {
    key: "deepseek",
    name: "DeepSeek",
    kind: "openai",
    baseUrl: "https://api.deepseek.com/v1",
    docs: "https://platform.deepseek.com/api_keys",
    models: [
      { id: "deepseek-chat", tools: true, context: 128000 },
      { id: "deepseek-reasoner", reasoning: true, tools: true, context: 128000 },
    ],
  },
  {
    key: "groq",
    name: "Groq",
    kind: "openai",
    baseUrl: "https://api.groq.com/openai/v1",
    docs: "https://console.groq.com/keys",
    models: [
      { id: "moonshotai/kimi-k2-instruct", tools: true, context: 131072 },
      { id: "llama-3.3-70b-versatile", tools: true, context: 131072 },
    ],
  },
  {
    key: "xai",
    name: "xAI Grok",
    kind: "openai",
    baseUrl: "https://api.x.ai/v1",
    docs: "https://console.x.ai",
    models: [
      { id: "grok-4", reasoning: true, vision: true, tools: true, context: 256000 },
      { id: "grok-3-mini", reasoning: true, tools: true, context: 131072 },
    ],
  },
  {
    key: "mistral",
    name: "Mistral",
    kind: "openai",
    baseUrl: "https://api.mistral.ai/v1",
    docs: "https://console.mistral.ai/api-keys",
    models: [
      { id: "mistral-large-latest", tools: true, context: 131072 },
      { id: "codestral-latest", tools: true, context: 256000 },
    ],
  },
  {
    key: "ollama",
    name: "Ollama (локально)",
    kind: "openai",
    baseUrl: "http://127.0.0.1:11434/v1",
    hint: "Локальный сервер на этом устройстве",
    models: [],
    needsKey: false,
  },
  {
    key: "lmstudio",
    name: "LM Studio (локально)",
    kind: "openai",
    baseUrl: "http://127.0.0.1:1234/v1",
    hint: "Локальный сервер на этом устройстве",
    models: [],
    needsKey: false,
  },
  {
    key: "custom",
    name: "Свой endpoint",
    kind: "openai",
    baseUrl: "",
    hint: "Любой OpenAI-совместимый или Anthropic API",
    models: [],
    needsKey: false,
  },
];

export function presetByKey(key?: string): ProviderPreset | undefined {
  return PROVIDER_PRESETS.find((p) => p.key === key);
}

export function providerFromPreset(preset: ProviderPreset): ProviderConfig {
  return {
    id: uid("prov"),
    name: preset.name,
    kind: preset.kind,
    baseUrl: preset.baseUrl,
    apiKey: "",
    enabled: true,
    preset: preset.key,
    models: preset.models.map((m) => ({
      id: m.id,
      label: m.label ?? m.id,
      providerId: "",
      reasoning: m.reasoning,
      vision: m.vision,
      tools: m.tools,
      context: m.context,
    })),
  };
}

/** Грубая эвристика возможностей по имени модели (для найденных через /models). */
export function inferModelFlags(id: string): Pick<ModelInfo, "reasoning" | "vision" | "tools" | "context"> {
  const m = id.toLowerCase();
  const reasoning =
    /(^|\/)(o1|o3|o4|gpt-5|gpt-6)|reason|think|deepseek-r|qwq|grok-4|gemini-2\.5-(pro|flash)|claude-(opus|sonnet)-4|magistral|kimi-k2-thinking/.test(m);
  const vision =
    /gpt-4|gpt-5|o3|o4|vision|claude-3|claude-4|claude-(sonnet|opus|haiku)-4|gemini|grok-(2|3|4)|qwen.*vl|llama.*vision|pixtral|mistral-large|glm-4.*v/.test(m);
  const tools = !/embed|whisper|tts|dall-e|image|audio|moderation/.test(m);
  return { reasoning, vision, tools };
}

export function toModelInfo(id: string, providerId: string, label?: string | null, context?: number | null): ModelInfo {
  const flags = inferModelFlags(id);
  return {
    id,
    label: label && label.trim() ? label : prettyModelName(id),
    providerId,
    context: context ?? flags.context,
    reasoning: flags.reasoning,
    vision: flags.vision,
    tools: flags.tools,
  };
}

export const EFFORT_LABEL: Record<Effort, string> = {
  off: "Выкл",
  low: "Низкое",
  medium: "Среднее",
  high: "Высокое",
};

export const EFFORT_HINT: Record<Effort, string> = {
  off: "Без рассуждений — быстрый ответ",
  low: "Короткое обдумывание",
  medium: "Сбалансированное качество и скорость",
  high: "Максимальное качество, дольше и дороже",
};

export const ACCENTS: { id: "coral" | "sage" | "sky" | "violet"; label: string; color: string }[] = [
  { id: "coral", label: "Коралл", color: "#d97757" },
  { id: "sage", label: "Шалфей", color: "#819e70" },
  { id: "sky", label: "Небо", color: "#6e98be" },
  { id: "violet", label: "Лаванда", color: "#9b82c4" },
];
