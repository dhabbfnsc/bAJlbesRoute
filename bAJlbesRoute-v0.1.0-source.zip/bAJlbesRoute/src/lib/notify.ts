import { isTauri } from "./bridge";

let prepared = false;
let allowed = false;

export async function ensureNotificationPermission(): Promise<boolean> {
  if (prepared) return allowed;
  prepared = true;
  if (isTauri()) {
    try {
      const plugin = await import("@tauri-apps/plugin-notification");
      let granted = await plugin.isPermissionGranted();
      if (!granted) {
        granted = (await plugin.requestPermission()) === "granted";
      }
      allowed = granted;
    } catch {
      allowed = false;
    }
    return allowed;
  }
  if (typeof Notification !== "undefined") {
    if (Notification.permission === "granted") {
      allowed = true;
    } else if (Notification.permission !== "denied") {
      try {
        allowed = (await Notification.requestPermission()) === "granted";
      } catch {
        allowed = false;
      }
    }
  }
  return allowed;
}

export async function notifyNow(title: string, body: string): Promise<void> {
  if (isTauri()) {
    try {
      const { call } = await import("./bridge");
      await call("notify", { title, body });
    } catch (err) {
      console.warn("notify failed", err);
    }
    return;
  }
  try {
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      new Notification(title, { body, silent: false });
    }
  } catch {
    /* ignore */
  }
}
