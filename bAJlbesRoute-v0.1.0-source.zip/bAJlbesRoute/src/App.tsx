import { useEffect, useState } from "react";
import { selectActiveChat, useStore } from "./store/store";
import { Sidebar } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { MessageList } from "./components/MessageList";
import { Composer } from "./components/Composer";
import { ModelPicker } from "./components/ModelPicker";
import { SettingsPanel, type SettingsTab } from "./components/Settings";
import { ImaginePanel } from "./components/ImaginePanel";
import { Onboarding } from "./components/Onboarding";
import { Toasts } from "./components/Toasts";
import { Logo, Wordmark } from "./components/ui";

function Splash() {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-4 bg-bg">
      <div className="animate-pulseSoft">
        <Logo size={46} />
      </div>
      <Wordmark className="text-[15px] opacity-80" />
      <div className="h-0.5 w-24 overflow-hidden rounded-full bg-line">
        <div className="h-full w-1/2 animate-shimmer rounded-full bg-accent/70" />
      </div>
    </div>
  );
}

export default function App() {
  const ready = useStore((s) => s.ready);
  const init = useStore((s) => s.init);
  const settings = useStore((s) => s.settings);
  const onboarded = settings.onboarded;

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<SettingsTab>("general");
  const [imagineOpen, setImagineOpen] = useState(false);
  const [modelPickerOpen, setModelPickerOpen] = useState(false);

  useEffect(() => {
    void init();
  }, [init]);

  useEffect(() => {
    document.documentElement.dataset.accent = settings.accent;
  }, [settings.accent]);

  useEffect(() => {
    document.documentElement.dataset.font = settings.fontSize;
  }, [settings.fontSize]);

  useEffect(() => {
    document.body.classList.toggle("no-anim", !settings.animations);
  }, [settings.animations]);

  const openSettings = (tab?: string) => {
    setSettingsTab((tab as SettingsTab) ?? "general");
    setSettingsOpen(true);
  };

  if (!ready) return <Splash />;

  return (
    <div className="relative flex h-full w-full overflow-hidden bg-bg">
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-70">
        <div
          className="absolute -left-40 -top-40 h-[420px] w-[420px] rounded-full blur-[120px]"
          style={{ background: "rgb(var(--accent-glow) / 0.10)" }}
        />
        <div
          className="absolute -bottom-56 right-[-10%] h-[480px] w-[480px] rounded-full blur-[140px]"
          style={{ background: "rgb(var(--accent-glow) / 0.07)" }}
        />
      </div>

      <Sidebar onOpenSettings={openSettings} onOpenImagine={() => setImagineOpen(true)} />

      <main className="flex min-w-0 flex-1 flex-col">
        <TopBar onOpenModelPicker={() => setModelPickerOpen(true)} onOpenSettings={openSettings} />
        <ChatScreen
          onOpenModelPicker={() => setModelPickerOpen(true)}
          onOpenSettings={openSettings}
        />
      </main>

      <ModelPicker
        open={modelPickerOpen}
        onClose={() => setModelPickerOpen(false)}
        onOpenSettings={openSettings}
      />
      <SettingsPanel open={settingsOpen} onClose={() => setSettingsOpen(false)} initialTab={settingsTab} />
      <ImaginePanel
        open={imagineOpen}
        onClose={() => setImagineOpen(false)}
        onOpenSettings={(tab) => {
          setImagineOpen(false);
          openSettings(tab ?? "imagine");
        }}
      />
      {!onboarded && <Onboarding />}
      <Toasts />
    </div>
  );
}

function ChatScreen({
  onOpenModelPicker,
  onOpenSettings,
}: {
  onOpenModelPicker: () => void;
  onOpenSettings: (tab?: string) => void;
}) {
  const chat = useStore(selectActiveChat);
  const run = useStore((s) => (chat ? s.runs[chat.id] : undefined));
  const [draft, setDraft] = useState("");

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <MessageList chat={chat} run={run} onSuggestion={setDraft} />
      <Composer
        draft={draft}
        onDraftChange={setDraft}
        onOpenModelPicker={onOpenModelPicker}
        onOpenSettings={onOpenSettings}
      />
    </div>
  );
}
