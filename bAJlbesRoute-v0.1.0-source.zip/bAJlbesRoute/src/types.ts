export type Effort = "off" | "low" | "medium" | "high";
export type ProviderKind = "openai" | "anthropic";
export type Platform = "windows" | "macos" | "linux" | "android" | "ios" | "web";

export interface ModelInfo {
  id: string;
  label: string;
  providerId: string;
  context?: number;
  reasoning?: boolean;
  vision?: boolean;
  tools?: boolean;
}

export interface ProviderConfig {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string;
  apiKey: string;
  enabled: boolean;
  preset?: string;
  models: ModelInfo[];
  lastSync?: number;
}

export interface Attachment {
  id: string;
  name: string;
  mime: string;
  size: number;
  kind: "image" | "file" | "audio" | "video";
  dataUrl?: string;
  text?: string;
  path?: string;
}

export interface ToolTrace {
  id: string;
  name: string;
  args: string;
  result?: string;
  ok?: boolean;
  status: string;
}

export interface Usage {
  promptTokens?: number | null;
  completionTokens?: number | null;
  totalTokens?: number | null;
}

export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  reasoning?: string;
  attachments?: Attachment[];
  createdAt: number;
  modelId?: string;
  providerId?: string;
  providerName?: string;
  error?: string;
  stopped?: boolean;
  usage?: Usage;
  tools?: ToolTrace[];
  pending?: boolean;
  requestId?: string;
}

export interface Chat {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  model?: { providerId: string; modelId: string } | null;
  effort?: Effort;
  workspace?: string | null;
  pinned?: boolean;
}

export interface MediaItem {
  id: string;
  kind: "image" | "video";
  prompt: string;
  provider: string;
  path: string;
  mime: string;
  createdAt: number;
  aspect?: string;
  dataUrl?: string;
}

export interface CustomImageEndpoint {
  name: string;
  baseUrl: string;
  apiKey: string;
  model: string;
}

export interface ImagineSettings {
  openaiModel: string;
  fal: string;
  replicate: string;
  together: string;
  stability: string;
  pollinations: boolean;
  googleKey: string;
  useProviderKeyForGoogle: boolean;
  replicateT2V: string;
  replicateI2V: string;
  customImages: CustomImageEndpoint[];
  aspect: string;
}

export interface Settings {
  accent: "coral" | "sage" | "sky" | "violet";
  providers: ProviderConfig[];
  systemPromptExtra: string;
  sendOnEnter: boolean;
  showReasoning: boolean;
  animations: boolean;
  haptics: boolean;
  notifications: boolean;
  closeToTray: boolean;
  workspace: string | null;
  toolsEnabled: boolean;
  fontSize: "sm" | "md" | "lg";
  defaultEffort: Effort;
  maxTokens: number | null;
  temperature: number;
  imagine: ImagineSettings;
  onboarded: boolean;
}

export interface BootInfo {
  platform: Platform;
  platformLabel: string;
  arch: string;
  osVersion: string;
  appVersion: string;
  dataDir: string;
  mediaDir: string;
  isMobile: boolean;
  deviceName: string;
  webview: string;
  locale: string;
}

export interface ListedModel {
  id: string;
  label?: string | null;
  context?: number | null;
}

export interface WorkspaceOverview {
  exists: boolean;
  files: number;
  size: number;
  entries: string[];
}

export interface AttachmentPayload {
  name: string;
  mime: string;
  size: number;
  dataUrl?: string | null;
  text?: string | null;
}

export interface MediaResult {
  path: string;
  mime: string;
  kind: "image" | "video";
  provider: string;
  dataUrl?: string | null;
  attempts: { provider: string; ok: boolean; error?: string | null; ms: number }[];
}

export interface ChatSnapshot {
  requestId: string;
  chatId: string;
  text: string;
  reasoning: string;
  status: string;
  error?: string | null;
  tools: ToolTrace[];
  usage?: Usage | null;
  finished: boolean;
  startedAt: number;
  updatedAt: number;
}

export type ChatEvent =
  | { type: "status"; status: string }
  | { type: "delta"; text: string }
  | { type: "reasoning"; text: string }
  | { type: "tool"; id: string; name: string; args: string }
  | { type: "toolResult"; id: string; ok: boolean; result: string }
  | { type: "usage"; usage: Usage }
  | { type: "done"; text: string; reasoning: string; usage?: Usage | null; finish: string }
  | { type: "stopped"; text: string; reasoning: string }
  | { type: "error"; message: string };

export interface ChatEnvelope {
  requestId: string;
  chatId: string;
  event: ChatEvent;
}

export interface ImagineEvent {
  id: string;
  type: string;
  provider?: string | null;
  message?: string | null;
  path?: string | null;
}

export interface RunState {
  requestId: string;
  chatId: string;
  assistantId: string;
  text: string;
  reasoning: string;
  status: string;
  tools: ToolTrace[];
  startedAt: number;
  error?: string;
}
