import { create } from "zustand";
import type {
  Attachment,
  BootInfo,
  Chat,
  ChatEnvelope,
  ChatEvent,
  Effort,
  ImagineEvent,
  ImagineSettings,
  MediaItem,
  Message,
  ProviderConfig,
  RunState,
  Settings,
  ToolTrace,
} from "../types";
import {
  chatSnapshot,
  dropChatSnapshot,
  imagineCancel as imagineCancelCmd,
  imagineGenerate as imagineGenerateCmd,
  isTauri,
  loadState,
  saveState,
  startChat,
  stopChat,
  subscribe,
  workspaceOverview,
  type ChatStartPayload,
} from "../lib/bridge";
import { defaultImagine, defaultSettings } from "../lib/defaults";
import { presetByKey, providerFromPreset, toModelInfo } from "../lib/catalog";
import { buildSystemPrompt, toApiMessages } from "../lib/prompt";
import { demoChatStream, demoImage } from "../lib/demo";
import { setHapticsEnabled, succeed, fail } from "../lib/haptics";
import { ensureNotificationPermission, notifyNow } from "../lib/notify";
import { bootInfo as fetchBoot, setCloseToTray } from "../lib/bridge";
import { truncate, uid } from "../lib/utils";

export interface Toast {
  id: string;
  text: string;
  kind: "info" | "ok" | "err";
}

export interface ImagineLog {
  id: string;
  at: number;
  level: "info" | "ok" | "warn" | "err";
  text: string;
}

export interface ImagineInput {
  mode: "image" | "video";
  prompt: string;
  image?: string | null;
  aspect?: string | null;
}

interface PersistShape {
  version: number;
  settings: Settings;
  chats: Chat[];
  activeChatId: string | null;
  currentModel: { providerId: string; modelId: string } | null;
  currentEffort: Effort;
  imagineItems: MediaItem[];
}

export interface AppStore {
  ready: boolean;
  boot: BootInfo | null;
  settings: Settings;
  chats: Chat[];
  activeChatId: string | null;
  currentModel: { providerId: string; modelId: string } | null;
  currentEffort: Effort;
  runs: Record<string, RunState>;
  imagineItems: MediaItem[];
  imagineRunning: boolean;
  imagineJobId: string | null;
  imagineLogs: ImagineLog[];
  imagineError: string | null;
  imagineResult: MediaItem | null;
  sidebarOpen: boolean;
  toasts: Toast[];

  init(): Promise<void>;
  newChat(): string;
  selectChat(id: string | null): void;
  deleteChat(id: string): void;
  renameChat(id: string, title: string): void;
  togglePin(id: string): void;
  clearAllChats(): void;
  patchChat(id: string, patch: Partial<Chat>): void;

  setModel(providerId: string | null, modelId: string | null): void;
  setEffort(effort: Effort): void;

  addProvider(presetKey: string): string | null;
  updateProvider(id: string, patch: Partial<ProviderConfig>): void;
  removeProvider(id: string): void;
  syncModels(id: string): Promise<{ ok: boolean; message: string }>;
  addManualModel(providerId: string, modelId: string): void;
  removeModel(providerId: string, modelId: string): void;

  patchSettings(patch: Partial<Settings>): void;
  patchImagine(patch: Partial<ImagineSettings>): void;
  setWorkspace(path: string | null): Promise<void>;

  send(text: string, attachments?: Attachment[]): Promise<void>;
  stop(chatId: string): Promise<void>;
  regenerate(): Promise<void>;
  deleteMessage(chatId: string, messageId: string): void;
  reconcileRuns(): Promise<void>;

  imagineGenerate(input: ImagineInput): Promise<void>;
  imagineCancel(): void;
  imagineDelete(id: string): void;
  imagineClear(): void;

  toggleSidebar(open?: boolean): void;
  toast(text: string, kind?: Toast["kind"]): void;
  dismissToast(id: string): void;
}

export function selectActiveChat(state: AppStore): Chat | null {
  return state.chats.find((c) => c.id === state.activeChatId) ?? null;
}

export function selectCurrentProvider(state: AppStore): ProviderConfig | null {
  if (!state.currentModel) return null;
  return state.settings.providers.find((p) => p.id === state.currentModel!.providerId) ?? null;
}

export function selectCurrentModelInfo(state: AppStore) {
  const provider = selectCurrentProvider(state);
  if (!provider || !state.currentModel) return null;
  return provider.models.find((m) => m.id === state.currentModel!.modelId) ?? null;
}

export function providerNeedsKey(provider: ProviderConfig): boolean {
  const preset = presetByKey(provider.preset);
  if (preset?.needsKey === false) return false;
  const url = provider.baseUrl.toLowerCase();
  if (url.includes("127.0.0.1") || url.includes("localhost")) return false;
  return true;
}

function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "Новый чат";
  return truncate(clean, 52);
}

function messageTitle(provider: ProviderConfig, modelId: string, withProvider: boolean): string {
  const model = provider.models.find((m) => m.id === modelId);
  const label = model?.label || modelId;
  return withProvider ? `${label} · ${provider.name}` : label;
}

let initStarted = false;

export const useStore = create<AppStore>()((set, get) => {
  function patchMessage(chatId: string, messageId: string, patch: Partial<Message>): void {
    set((state) => ({
      chats: state.chats.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              updatedAt: Date.now(),
              messages: chat.messages.map((m) => (m.id === messageId ? { ...m, ...patch } : m)),
            }
          : chat,
      ),
    }));
  }

  function setRun(chatId: string, patch: Partial<RunState> | null): void {
    set((state) => {
      const runs = { ...state.runs };
      if (patch === null) {
        delete runs[chatId];
      } else if (runs[chatId]) {
        runs[chatId] = { ...runs[chatId], ...patch };
      }
      return { runs };
    });
  }

  function applyChatEvent(env: ChatEnvelope): void {
    const state = get();
    const run = state.runs[env.chatId];
    if (!run || run.requestId !== env.requestId) return;
    const ev: ChatEvent = env.event;
    switch (ev.type) {
      case "status":
        setRun(env.chatId, { status: ev.status });
        break;
      case "delta":
        setRun(env.chatId, { text: (get().runs[env.chatId]?.text ?? "") + ev.text });
        break;
      case "reasoning":
        setRun(env.chatId, { reasoning: (get().runs[env.chatId]?.reasoning ?? "") + ev.text });
        break;
      case "tool": {
        const tools = [...(get().runs[env.chatId]?.tools ?? [])];
        tools.push({ id: ev.id, name: ev.name, args: ev.args, status: "running" });
        setRun(env.chatId, { tools, status: "tools" });
        break;
      }
      case "toolResult": {
        const tools = (get().runs[env.chatId]?.tools ?? []).map((t) =>
          t.id === ev.id ? { ...t, ok: ev.ok, result: ev.result, status: ev.ok ? "ok" : "error" } : t,
        );
        setRun(env.chatId, { tools });
        break;
      }
      case "usage":
        break;
      case "done": {
        const current = get().runs[env.chatId];
        patchMessage(env.chatId, current?.assistantId ?? "", {
          pending: false,
          text: ev.text,
          reasoning: ev.reasoning,
          usage: ev.usage ?? undefined,
          tools: current?.tools,
        });
        setRun(env.chatId, null);
        dropChatSnapshot(env.requestId).catch(() => {});
        succeed();
        if (state.settings.notifications && !isTauri()) {
          notifyNow("bAJlbesRoute — модель ответила", truncate(ev.text, 180));
        }
        break;
      }
      case "stopped": {
        const current = get().runs[env.chatId];
        patchMessage(env.chatId, current?.assistantId ?? "", {
          pending: false,
          stopped: true,
          text: ev.text || current?.text || "",
          reasoning: ev.reasoning || current?.reasoning || "",
          tools: current?.tools,
        });
        setRun(env.chatId, null);
        dropChatSnapshot(env.requestId).catch(() => {});
        break;
      }
      case "error": {
        const current = get().runs[env.chatId];
        patchMessage(env.chatId, current?.assistantId ?? "", {
          pending: false,
          error: ev.message,
          text: current?.text ?? "",
          reasoning: current?.reasoning ?? "",
          tools: current?.tools,
        });
        setRun(env.chatId, null);
        dropChatSnapshot(env.requestId).catch(() => {});
        fail();
        get().toast(truncate(ev.message, 220), "err");
        break;
      }
    }
  }

  function applyImagineEvent(ev: ImagineEvent): void {
    const level: ImagineLog["level"] =
      ev.type === "fail" ? "err" : ev.type === "success" || ev.type === "done" ? "ok" : "info";
    const prefix = ev.provider ? `${ev.provider}: ` : "";
    const text = `${prefix}${ev.message ?? (ev.type === "start" ? "старт" : ev.type)}`;
    set((state) => ({
      imagineLogs: [...state.imagineLogs, { id: uid("log"), at: Date.now(), level, text }].slice(-80),
    }));
  }

  async function runChat(chatId: string, assistantId: string, requestId: string, payload: ChatStartPayload): Promise<void> {
    if (!isTauri()) {
      const model = get().currentModel;
      const provider = selectCurrentProvider(get());
      let cancelled = false;
      const chat = get().chats.find((c) => c.id === chatId);
      void demoChatStream(
        {
          prompt: payload.messages[payload.messages.length - 1]?.text ?? "",
          model: model?.modelId ?? "demo",
          provider: provider?.name ?? "Demo",
          effort: get().currentEffort,
          workspace: chat?.workspace ?? null,
        },
        {
          onStatus: (status) => setRun(chatId, { status }),
          onDelta: (text) => setRun(chatId, { text: (get().runs[chatId]?.text ?? "") + text }),
          onReasoning: (text) => setRun(chatId, { reasoning: (get().runs[chatId]?.reasoning ?? "") + text }),
          onDone: (text, reasoning) => {
            if (cancelled) return;
            patchMessage(chatId, assistantId, { pending: false, text, reasoning });
            setRun(chatId, null);
          },
          onError: (message) => {
            if (cancelled) return;
            patchMessage(chatId, assistantId, { pending: false, error: message });
            setRun(chatId, null);
          },
        },
        () => cancelled,
      );
      const stopWatcher = setInterval(() => {
        if (!get().runs[chatId]) {
          cancelled = true;
          clearInterval(stopWatcher);
        }
      }, 400);
      return;
    }
    try {
      await startChat(payload);
    } catch (err) {
      patchMessage(chatId, assistantId, {
        pending: false,
        error: err instanceof Error ? err.message : String(err),
      });
      setRun(chatId, null);
      fail();
      get().toast("Не удалось запустить запрос", "err");
    }
    void requestId;
  }

  return {
    ready: false,
    boot: null,
    settings: defaultSettings(),
    chats: [],
    activeChatId: null,
    currentModel: null,
    currentEffort: "medium",
    runs: {},
    imagineItems: [],
    imagineRunning: false,
    imagineJobId: null,
    imagineLogs: [],
    imagineError: null,
    imagineResult: null,
    sidebarOpen: false,
    toasts: [],

    async init() {
      if (get().ready || initStarted) return;
      initStarted = true;
      const [boot, saved] = await Promise.all([
        fetchBoot().catch(() => null),
        loadState<PersistShape>().catch(() => null),
      ]);
      let settings = defaultSettings();
      let chats: Chat[] = [];
      let activeChatId: string | null = null;
      let currentModel: { providerId: string; modelId: string } | null = null;
      let currentEffort: Effort = "medium";
      let imagineItems: MediaItem[] = [];

      if (saved && saved.version === 1) {
        const base = defaultSettings();
        settings = {
          ...base,
          ...saved.settings,
          imagine: { ...defaultImagine(), ...(saved.settings?.imagine ?? {}) },
          providers: saved.settings?.providers?.length ? saved.settings.providers : base.providers,
        };
        chats = (saved.chats ?? []).map((chat) => ({
          ...chat,
          messages: (chat.messages ?? []).map((m) =>
            m.pending ? { ...m, pending: false, error: m.error ?? "Запрос был прерван" } : m,
          ),
        }));
        activeChatId = saved.activeChatId ?? null;
        currentModel = saved.currentModel ?? null;
        currentEffort = saved.currentEffort ?? settings.defaultEffort;
        imagineItems = saved.imagineItems ?? [];
      }

      if (!activeChatId && chats.length) activeChatId = chats[0].id;

      set({
        boot,
        settings,
        chats,
        activeChatId,
        currentModel,
        currentEffort,
        imagineItems,
        ready: true,
      });

      const modelValid =
        currentModel &&
        settings.providers.some(
          (p) => p.id === currentModel!.providerId && p.models.some((m) => m.id === currentModel!.modelId),
        );
      if (!modelValid) {
        const enabled = settings.providers.filter((p) => p.enabled && p.models.length);
        const withKey = enabled.find((p) => p.apiKey.trim() || !providerNeedsKey(p));
        const pick = withKey ?? enabled[0];
        if (pick) {
          set({ currentModel: { providerId: pick.id, modelId: pick.models[0].id } });
        }
      }

      setHapticsEnabled(settings.haptics);
      if (isTauri()) {
        setCloseToTray(settings.closeToTray).catch(() => {});
        import("../lib/bridge")
          .then((m) => m.allowMediaScope().catch(() => {}))
          .catch(() => {});
      }

      void subscribe<ChatEnvelope>("chat:event", (payload) => {
        if (payload && payload.chatId && payload.event) applyChatEvent(payload);
      });
      void subscribe<ImagineEvent>("imagine:event", (payload) => {
        if (payload) applyImagineEvent(payload);
      });

      if (typeof document !== "undefined") {
        document.addEventListener("visibilitychange", () => {
          if (!document.hidden) void get().reconcileRuns();
        });
      }

      let saveTimer: number | undefined;
      useStore.subscribe((state) => {
        if (!state.ready) return;
        window.clearTimeout(saveTimer);
        saveTimer = window.setTimeout(() => {
          const payload: PersistShape = {
            version: 1,
            settings: state.settings,
            chats: state.chats,
            activeChatId: state.activeChatId,
            currentModel: state.currentModel,
            currentEffort: state.currentEffort,
            imagineItems: state.imagineItems.slice(0, 160).map((item) =>
              item.path ? { ...item, dataUrl: undefined } : item,
            ),
          };
          void saveState(payload);
        }, 450) as unknown as number;
      });

      // при возвращении в окно — сверить состояние фоновых запусков
      setTimeout(() => void get().reconcileRuns(), 1200);
    },

    newChat() {
      const chat: Chat = {
        id: uid("chat"),
        title: "Новый чат",
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        model: get().currentModel,
        effort: get().currentEffort,
        workspace: get().settings.workspace,
      };
      set((state) => ({ chats: [chat, ...state.chats], activeChatId: chat.id, sidebarOpen: false }));
      return chat.id;
    },

    selectChat(id) {
      set({ activeChatId: id, sidebarOpen: false });
    },

    deleteChat(id) {
      const run = get().runs[id];
      if (run) void stopChat(run.requestId).catch(() => {});
      set((state) => {
        const chats = state.chats.filter((c) => c.id !== id);
        const runs = { ...state.runs };
        delete runs[id];
        return {
          chats,
          runs,
          activeChatId: state.activeChatId === id ? chats[0]?.id ?? null : state.activeChatId,
        };
      });
    },

    renameChat(id, title) {
      set((state) => ({
        chats: state.chats.map((c) => (c.id === id ? { ...c, title: title.trim() || c.title } : c)),
      }));
    },

    togglePin(id) {
      set((state) => ({
        chats: state.chats.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c)),
      }));
    },

    clearAllChats() {
      Object.values(get().runs).forEach((run) => void stopChat(run.requestId).catch(() => {}));
      set({ chats: [], runs: {}, activeChatId: null });
    },

    patchChat(id, patch) {
      set((state) => ({ chats: state.chats.map((c) => (c.id === id ? { ...c, ...patch } : c)) }));
    },

    setModel(providerId, modelId) {
      const currentModel = providerId && modelId ? { providerId, modelId } : null;
      const chat = selectActiveChat(get());
      set((state) => ({
        currentModel,
        chats: chat
          ? state.chats.map((c) => (c.id === chat.id ? { ...c, model: currentModel } : c))
          : state.chats,
      }));
    },

    setEffort(effort) {
      const chat = selectActiveChat(get());
      set((state) => ({
        currentEffort: effort,
        chats: chat ? state.chats.map((c) => (c.id === chat.id ? { ...c, effort } : c)) : state.chats,
      }));
    },

    addProvider(presetKey) {
      const preset = presetByKey(presetKey);
      if (!preset) return null;
      const existing = get().settings.providers.find((p) => p.preset === presetKey);
      if (existing) {
        get().toast(`${preset.name} уже добавлен`, "info");
        return existing.id;
      }
      const provider = providerFromPreset(preset);
      set((state) => ({
        settings: { ...state.settings, providers: [...state.settings.providers, provider] },
      }));
      return provider.id;
    },

    updateProvider(id, patch) {
      set((state) => ({
        settings: {
          ...state.settings,
          providers: state.settings.providers.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        },
      }));
    },

    removeProvider(id) {
      set((state) => ({
        settings: {
          ...state.settings,
          providers: state.settings.providers.filter((p) => p.id !== id),
        },
        currentModel:
          state.currentModel?.providerId === id ? null : state.currentModel,
      }));
    },

    async syncModels(id) {
      const provider = get().settings.providers.find((p) => p.id === id);
      if (!provider) return { ok: false, message: "Провайдер не найден" };
      if (!provider.baseUrl.trim()) return { ok: false, message: "Укажите Base URL" };
      try {
        const { listModels } = await import("../lib/bridge");
        const listed = await listModels({
          kind: provider.kind,
          baseUrl: provider.baseUrl,
          apiKey: provider.apiKey,
        });
        if (!listed.length) return { ok: false, message: "Провайдер не вернул моделей" };
        const { toModelInfo } = await import("../lib/catalog");
        const models = listed.map((m) => toModelInfo(m.id, provider.id, m.label, m.context));
        get().updateProvider(id, { models, lastSync: Date.now() });
        const current = get().currentModel;
        if (current && current.providerId === id && !models.some((m) => m.id === current.modelId)) {
          set({ currentModel: { providerId: id, modelId: models[0].id } });
        }
        return { ok: true, message: `Загружено моделей: ${models.length}` };
      } catch (err) {
        return { ok: false, message: err instanceof Error ? err.message : String(err) };
      }
    },

    addManualModel(providerId, modelId) {
      const id = modelId.trim();
      if (!id) return;
      set((state) => ({
        settings: {
          ...state.settings,
          providers: state.settings.providers.map((p) => {
            if (p.id !== providerId) return p;
            if (p.models.some((m) => m.id === id)) return p;
            return { ...p, models: [toModelInfo(id, p.id), ...p.models] };
          }),
        },
      }));
    },

    removeModel(providerId, modelId) {
      set((state) => ({
        settings: {
          ...state.settings,
          providers: state.settings.providers.map((p) =>
            p.id === providerId ? { ...p, models: p.models.filter((m) => m.id !== modelId) } : p,
          ),
        },
      }));
    },

    patchSettings(patch) {
      set((state) => ({ settings: { ...state.settings, ...patch } }));
      if (patch.haptics !== undefined) setHapticsEnabled(patch.haptics);
      if (patch.closeToTray !== undefined && isTauri()) {
        setCloseToTray(patch.closeToTray).catch(() => {});
      }
      if (patch.notifications) void ensureNotificationPermission();
    },

    patchImagine(patch) {
      set((state) => ({ settings: { ...state.settings, imagine: { ...state.settings.imagine, ...patch } } }));
    },

    async setWorkspace(path) {
      set((state) => ({
        settings: { ...state.settings, workspace: path },
        chats: state.chats.map((c) => (c.id === state.activeChatId ? { ...c, workspace: path } : c)),
      }));
    },

    async send(text, attachments = []) {
      const trimmed = text.trim();
      if (!trimmed && !attachments.length) return;
      const state = get();
      let chat = selectActiveChat(state);
      if (!chat) {
        get().newChat();
        chat = selectActiveChat(get())!;
      }
      const provider = selectCurrentProvider(state);
      const modelInfo = selectCurrentModelInfo(state);
      if (!provider || !modelInfo) {
        get().toast("Сначала выберите модель", "err");
        return;
      }
      if (isTauri() && providerNeedsKey(provider) && !provider.apiKey.trim()) {
        get().toast(`Добавьте API-ключ для ${provider.name} в настройках`, "err");
        return;
      }
      if (state.runs[chat.id]) {
        get().toast("Дождитесь ответа или остановите генерацию", "info");
        return;
      }

      const now = Date.now();
      const userMessage: Message = {
        id: uid("msg"),
        role: "user",
        text: trimmed,
        attachments: attachments.length ? attachments : undefined,
        createdAt: now,
      };
      const requestId = uid("req");
      const assistantMessage: Message = {
        id: uid("msg"),
        role: "assistant",
        text: "",
        createdAt: now + 1,
        modelId: modelInfo.id,
        providerId: provider.id,
        providerName: provider.name,
        pending: true,
        requestId,
      };
      const nextMessages = [...chat.messages, userMessage, assistantMessage];
      const isFirst = chat.messages.length === 0;
      set((s) => ({
        chats: s.chats.map((c) =>
          c.id === chat!.id
            ? {
                ...c,
                title: isFirst ? titleFrom(trimmed || "Вложение") : c.title,
                messages: nextMessages,
                updatedAt: now,
                model: { providerId: provider.id, modelId: modelInfo.id },
                effort: s.currentEffort,
                workspace: s.settings.workspace,
              }
            : c,
        ),
        runs: {
          ...s.runs,
          [chat!.id]: {
            requestId,
            chatId: chat!.id,
            assistantId: assistantMessage.id,
            text: "",
            reasoning: "",
            status: "starting",
            tools: [],
            startedAt: now,
          },
        },
      }));

      const workspace = get().settings.workspace;
      let overview = null;
      if (workspace && isTauri()) {
        overview = await workspaceOverview(workspace).catch(() => null);
      }
      const system = buildSystemPrompt({
        boot: get().boot,
        settings: get().settings,
        chat: { ...chat, workspace },
        model: modelInfo,
        provider,
        effort: get().currentEffort,
        workspace: overview,
      });
      const payload: ChatStartPayload = {
        requestId,
        chatId: chat.id,
        provider: {
          kind: provider.kind,
          baseUrl: provider.baseUrl,
          apiKey: provider.apiKey,
          headers: {},
        },
        model: modelInfo.id,
        system,
        messages: toApiMessages([...chat.messages, userMessage]),
        temperature: get().settings.temperature ?? null,
        maxTokens: get().settings.maxTokens ?? null,
        effort: get().currentEffort,
        tools: { enabled: get().settings.toolsEnabled && !!workspace, root: workspace },
        notify: {
          enabled: get().settings.notifications,
          title: messageTitle(provider, modelInfo.id, true),
        },
      };
      await runChat(chat.id, assistantMessage.id, requestId, payload);
    },

    async stop(chatId) {
      const run = get().runs[chatId];
      if (!run) return;
      if (isTauri()) {
        await stopChat(run.requestId).catch(() => {});
      } else {
        const chat = get().chats.find((c) => c.id === chatId);
        const message = chat?.messages.find((m) => m.id === run.assistantId);
        patchMessage(chatId, run.assistantId, {
          pending: false,
          stopped: true,
          text: run.text || message?.text || "",
          reasoning: run.reasoning,
        });
        setRun(chatId, null);
      }
    },

    async regenerate() {
      const chat = selectActiveChat(get());
      if (!chat || get().runs[chat.id]) return;
      let lastUserIndex = -1;
      for (let i = chat.messages.length - 1; i >= 0; i--) {
        if (chat.messages[i].role === "user") {
          lastUserIndex = i;
          break;
        }
      }
      if (lastUserIndex < 0) return;
      const userMessage = chat.messages[lastUserIndex];
      const history = chat.messages.slice(0, lastUserIndex);
      set((state) => ({
        chats: state.chats.map((c) => (c.id === chat.id ? { ...c, messages: history } : c)),
      }));
      await get().send(
        userMessage.text,
        userMessage.attachments,
      );
    },

    deleteMessage(chatId, messageId) {
      set((state) => ({
        chats: state.chats.map((c) =>
          c.id === chatId ? { ...c, messages: c.messages.filter((m) => m.id !== messageId) } : c,
        ),
      }));
    },

    async reconcileRuns() {
      if (!isTauri()) return;
      const runs = get().runs;
      for (const [chatId, run] of Object.entries(runs)) {
        try {
          const snap = await chatSnapshot(run.requestId);
          if (!snap) continue;
          if (snap.finished) {
            if (snap.error) {
              patchMessage(chatId, run.assistantId, {
                pending: false,
                error: snap.error,
                text: snap.text,
                reasoning: snap.reasoning,
                tools: snap.tools,
              });
            } else {
              patchMessage(chatId, run.assistantId, {
                pending: false,
                text: snap.text,
                reasoning: snap.reasoning,
                tools: snap.tools,
                usage: snap.usage ?? undefined,
                stopped: snap.status === "stopped",
              });
            }
            setRun(chatId, null);
            dropChatSnapshot(run.requestId).catch(() => {});
          } else {
            setRun(chatId, {
              text: snap.text,
              reasoning: snap.reasoning,
              status: snap.status,
              tools: snap.tools as ToolTrace[],
            });
          }
        } catch {
          /* ignore */
        }
      }
    },

    async imagineGenerate(input) {
      if (get().imagineRunning) return;
      const prompt = input.prompt.trim();
      if (!prompt && !input.image) {
        get().toast("Опишите, что сгенерировать", "err");
        return;
      }
      const id = uid("imagine");
      const aspect = input.aspect ?? get().settings.imagine.aspect;
      set({
        imagineRunning: true,
        imagineJobId: id,
        imagineLogs: [],
        imagineError: null,
        imagineResult: null,
      });

      if (!isTauri()) {
        set((s) => ({
          imagineLogs: [
            ...s.imagineLogs,
            { id: uid("log"), at: Date.now(), level: "info", text: "Демо-режим: запускаю генерацию в браузере" },
          ],
        }));
        await new Promise((r) => setTimeout(r, 900));
        if (input.mode === "video") {
          set({
            imagineRunning: false,
            imagineJobId: null,
            imagineError: "Видео генерируется только в приложении bAJlbesRoute (нужно нативное ядро).",
          });
          return;
        }
        const dataUrl = demoImage(prompt, aspect);
        const item: MediaItem = {
          id,
          kind: "image",
          prompt,
          provider: "demo",
          path: "",
          mime: "image/png",
          createdAt: Date.now(),
          aspect,
          dataUrl,
        };
        set((s) => ({
          imagineItems: [item, ...s.imagineItems],
          imagineRunning: false,
          imagineJobId: null,
          imagineResult: item,
          imagineLogs: [
            ...s.imagineLogs,
            { id: uid("log"), at: Date.now(), level: "ok", text: "Демо-изображение готово" },
          ],
        }));
        succeed();
        return;
      }

      const s = get();
      const imagine = s.settings.imagine;
      const openaiProvider = s.settings.providers.find((p) => p.preset === "openai" && p.apiKey.trim());
      const googleProvider = s.settings.providers.find((p) => p.preset === "google" && p.apiKey.trim());
      const providers: Record<string, unknown> = {
        openai: openaiProvider
          ? { baseUrl: openaiProvider.baseUrl, apiKey: openaiProvider.apiKey, model: imagine.openaiModel }
          : null,
        google:
          imagine.googleKey.trim() || (imagine.useProviderKeyForGoogle && googleProvider)
            ? {
                baseUrl: googleProvider?.baseUrl ?? "https://generativelanguage.googleapis.com",
                apiKey: imagine.googleKey.trim() || googleProvider?.apiKey || "",
              }
            : null,
        fal: imagine.fal.trim() || null,
        replicate: imagine.replicate.trim() || null,
        together: imagine.together.trim() || null,
        stability: imagine.stability.trim() || null,
        pollinations: imagine.pollinations,
        customImages: imagine.customImages
          .filter((c) => c.baseUrl.trim())
          .map((c) => ({ name: c.name, baseUrl: c.baseUrl, apiKey: c.apiKey, model: c.model })),
        replicateT2VModel: imagine.replicateT2V,
        replicateI2VModel: imagine.replicateI2V,
      };

      try {
        const result = await imagineGenerateCmd({
          id,
          mode: input.mode,
          prompt,
          image: input.image ?? null,
          aspect,
          providers,
          workspace: s.settings.workspace,
        });
        const item: MediaItem = {
          id,
          kind: result.kind,
          prompt,
          provider: result.provider,
          path: result.path,
          mime: result.mime,
          createdAt: Date.now(),
          aspect,
          dataUrl: result.dataUrl ?? undefined,
        };
        set((st) => ({
          imagineItems: [item, ...st.imagineItems],
          imagineRunning: false,
          imagineJobId: null,
          imagineResult: item,
        }));
        succeed();
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        set({ imagineRunning: false, imagineJobId: null, imagineError: message });
        fail();
      }
    },

    imagineCancel() {
      const jobId = get().imagineJobId;
      set({ imagineRunning: false, imagineJobId: null, imagineError: "Генерация отменена" });
      if (jobId && isTauri()) {
        void imagineCancelCmd(jobId).catch(() => {});
      }
    },

    imagineDelete(id) {
      const item = get().imagineItems.find((i) => i.id === id);
      set((state) => ({
        imagineItems: state.imagineItems.filter((i) => i.id !== id),
        imagineResult: state.imagineResult?.id === id ? null : state.imagineResult,
      }));
      if (item?.path && isTauri()) {
        void import("../lib/bridge").then((m) => m.mediaDelete(item.path).catch(() => {}));
      }
    },

    imagineClear() {
      set({ imagineItems: [] });
    },

    toggleSidebar(open) {
      set((state) => ({ sidebarOpen: open ?? !state.sidebarOpen }));
    },

    toast(text, kind = "info") {
      const id = uid("toast");
      set((state) => ({ toasts: [...state.toasts, { id, text, kind }] }));
      window.setTimeout(() => get().dismissToast(id), 4200);
    },

    dismissToast(id) {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    },
  };
});

export { messageTitle };
